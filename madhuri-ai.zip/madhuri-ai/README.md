# Madhuri AI

Your Voice. Your World. Your Intelligent Companion.

A voice-first Android assistant: tap the orb, speak, and Madhuri answers out loud in your language. It can also read images, write and explain code, keep local notes about you, and perform a defined set of phone actions (open apps, alarms, calls, messages) — asking for confirmation before it contacts anyone.

This is a runnable Android Studio project, not a mock-up. Every screen is wired to real state, real Gemini API calls, real speech recognition and real text-to-speech.

---

## What is implemented

| Area | Status |
| --- | --- |
| Voice loop (speech → Gemini → speech), all six orb states | Implemented |
| Voice input that does not need the phone's speech service (app records a WAV, Gemini transcribes it) | Implemented, default engine |
| Natural replies spoken by Gemini's TTS voices (Aoede/Kore/Leda/Zephyr/Sulafat), phone voice as fallback | Implemented |
| Character layer: warm, playful persona, varied openers, mood mirroring, follow-up questions | Implemented |
| Phone speech service as an alternative voice engine | Implemented, switchable in Settings |
| Interrupt speech, stop, repeat last reply | Implemented |
| Streaming replies (SSE from `streamGenerateContent`) | Implemented |
| 21 languages incl. Hindi, Bhojpuri, Sanskrit, Urdu, all major Indian languages | Implemented, with TTS fallback when a voice is missing |
| Automatic language mode (reply in the language used) | Implemented |
| Gemini API key screen: enter, show/hide, test, save, delete, status | Implemented |
| Model selection | Implemented |
| Chat: text, streaming, image questions, regenerate, stop, copy code, Markdown + code blocks | Implemented |
| Phone actions: open app, URL, web/YouTube search, dialer, call, contact lookup, SMS, WhatsApp, alarm, calendar reminder, volume, settings screens, share, camera, gallery | Implemented |
| Confirmation dialog before call / SMS / WhatsApp | Implemented |
| Personal memory: auto-saved notes, manual notes, delete one, clear all, on/off switch | Implemented |
| Chat history: list, open, delete one, delete all | Implemented |
| Settings: voice on/off, continuous conversation, speech rate, persona, theme, privacy, about, delete everything | Implemented |
| Bilingual (English + Hindi) error messages | Implemented |

## What is deliberately not in this build

- **Firebase** (Auth, Realtime Database, Storage, Cloud Functions, FCM). The brief's phase 2 and the cloud memory in phase 8 need a real `google-services.json` from your own Firebase project, which cannot be shipped in a zip. Persistence here is local-first behind repository interfaces (`ChatRepository`, `MemoryRepository`, `SettingsRepository`), so adding Firebase means reimplementing those three classes and adding the `com.google.gms.google-services` plugin — no screen has to change.
- **Gemini Live API / native-audio streaming** (`gemini-3.8-live`, WebSocket `BidiGenerateContent`). This build uses the documented Android stack from your brief: `SpeechRecognizer` → `generateContent` → `TextToSpeech`. Sub-second native audio is the next slice and would replace `SpeechRecognizerManager` + `SpeechSynthesizer` with a single streaming client.
- **Signed release APK / Play upload.** Needs your keystore and Play account. `README` steps below explain the build.
- **Accessibility-service based "control any app".** Not used: it violates Play policy for a general assistant and your own security section. Actions go through public intents only.

## Screens

1. **Home** — animated orb (idle / listening / processing / speaking / interrupted / error), status line, live partial transcript, last reply card, typed input fallback, six quick-action cards.
2. **Chat** — streaming bubbles, Markdown with copyable code blocks, image attach (scaled to 1024 px, JPEG 80), regenerate, stop.
3. **History** — every saved conversation with preview, timestamp, delete.
4. **Settings** — Gemini key, model, language picker (21 languages), voice, continuous conversation, speech speed, personality, memory manager, theme, privacy, about, data deletion.

## Stack

- Kotlin 2.4.21, Jetpack Compose (BOM 2026.09.00, Material 3 1.4.0), Navigation Compose 2.10.2
- AGP 9.3.3 with **built-in Kotlin** (no `org.jetbrains.kotlin.android` plugin — AGP 9 compiles Kotlin itself), Gradle 9.6.0, JDK 17
- `compileSdk 37`, `targetSdk 36`, `minSdk 26` (Android 8.0+)
- Lifecycle 2.11.0, Activity Compose 1.13.0, DataStore Preferences 1.3.0
- Architecture: MVVM + repository, `StateFlow` UI state, one `AppContainer` for manual DI
- No networking library: Gemini is called with `HttpURLConnection` + `org.json`, so there is no Retrofit/OkHttp version to keep in sync

## Open and run

1. Unzip.
2. Android Studio → **File → Open** → select the `madhuri-ai` folder.
3. Let Gradle sync. Android Studio reads `gradle/wrapper/gradle-wrapper.properties` and downloads Gradle 9.6.0. If it asks to create the wrapper, accept; or run once: `gradle wrapper --gradle-version 9.6.0`.
4. Run the `app` configuration on a device or emulator with Android 8.0+ and Google speech services (a Google Play image on the emulator).
5. First run: open Settings, paste a Gemini API key from [Google AI Studio](https://aistudio.google.com/apikey), tap **Test**, then **Save**.

If sync fails, run `./gradlew :app:assembleDebug --stacktrace` and read the first error.

### Optional: bake the key in for your own testing

Put it in `local.properties` (git-ignored, never committed):

```
sdk.dir=/path/to/Android/sdk
GEMINI_API_KEY=your_key_here
```

`app/build.gradle.kts` injects it as `BuildConfig.GEMINI_API_KEY` and it is used as the default until the user saves a key in-app. For a public release, do not ship a key this way — proxy Gemini through a small backend and keep the key server-side.

## Permissions

| Permission | Why |
| --- | --- |
| `INTERNET`, `ACCESS_NETWORK_STATE` | Gemini requests |
| `RECORD_AUDIO` | Speech recognition, only while you have started listening |
| `CALL_PHONE` | Place a call after you confirm; without it Madhuri opens the dialer |
| `READ_CONTACTS` | Look up "call Mom" by name |
| `SEND_SMS` | Pre-filled SMS draft |
| `MODIFY_AUDIO_SETTINGS`, `VIBRATE` | Volume control and feedback |

`<queries>` in the manifest lists the apps Madhuri can open by name. No `QUERY_ALL_PACKAGES`, no accessibility service, no background recording.

## Files worth reading first

- `data/ConversationEngine.kt` — one request/response cycle, streaming, action extraction
- `data/PromptBuilder.kt` — persona, language rules, the action + memory protocol
- `data/GeminiClient.kt` — SSE parsing and error mapping
- `ui/home/HomeViewModel.kt` — the voice state machine
- `actions/DeviceActionHandler.kt` — every permitted device action

## Build verification (what was actually run)

The Kotlin in this project has been compiled against the real toolchain, not just eyeballed:

- JDK 17.0.21 (Temurin), Gradle 9.6.0, AGP 9.3.3, Kotlin 2.4.21, Android SDK Platform 37.0, Build Tools 36.0.0
- `gradle :app:compileDebugKotlin` → **BUILD SUCCESSFUL**, zero warnings or errors in `app/src/main`
- One real bug was found and fixed by that compile: `NavigationBarItem` is a `RowScope` extension, so the bottom-bar item composable is now declared `private fun RowScope.BottomItem(...)`

What was **not** run: `assembleDebug` never finished. Packaging needs D8 to dex the whole Compose/AndroidX dependency set, and the build machine used here has 2 CPU cores and a 300-second command ceiling, which is not enough for that step. Everything up to and including Kotlin compilation, resource linking (`processDebugResources`), manifest merging and R class generation does succeed, so the source is sound; the APK step is a matter of CPU time on a normal machine.

### Getting an APK without a local setup

`.github/workflows/build-apk.yml` builds a debug APK on GitHub Actions: push this folder to a GitHub repo, open **Actions → Build Madhuri AI APK → Run workflow**, and download the `madhuri-ai-debug-apk` artifact. Add a repository secret named `GEMINI_API_KEY` if you want the key baked into `BuildConfig`; leave it unset to ship without a key and let users paste their own.

Locally, `./gradlew :app:assembleDebug` (or `gradle :app:assembleDebug` once you have Gradle 9.6.0) produces `app/build/outputs/apk/debug/app-debug.apk` in a few minutes on any normal laptop.

## Next steps I would take

1. Firebase Auth + Realtime Database behind the existing repositories (the brief's phases 2 and 8).
2. Gemini Live API for true streaming audio and barge-in.
3. Room instead of JSON files once history grows past a few hundred sessions.
4. Signed release: `keytool` keystore → `signingConfigs` in `app/build.gradle.kts` → `./gradlew :app:bundleRelease` → Play Console internal testing.

## Sources used for versions and APIs

- AGP release notes: https://developer.android.com/build/releases/agp-9-3-0-release-notes and https://developer.android.com/build/releases/agp-9-5-0-release-notes
- Built-in Kotlin migration: https://developer.android.com/build/migrate-to-built-in-kotlin
- Compose BOM and compiler setup: https://developer.android.com/develop/ui/compose/bom and https://developer.android.com/develop/ui/compose/setup-compose-dependencies-and-compiler
- Kotlin releases and KGP/AGP compatibility: https://kotlinlang.org/docs/releases.html and https://kotlinlang.org/docs/gradle-configure-project.html
- AndroidX versions: https://developer.android.com/jetpack/androidx/versions
- Gemini models and REST: https://ai.google.dev/api and https://aistudio.google.com/docs/models
