import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
}

// The Gemini API key never lives in source control. Put it in local.properties
// (which is git-ignored) as GEMINI_API_KEY=... and it is injected into
// BuildConfig for the first-run default. Users can also enter a key in-app.
val localProperties = Properties().apply {
    val file = rootProject.file("local.properties")
    if (file.exists()) {
        file.inputStream().use { load(it) }
    }
}
val geminiApiKey: String = localProperties.getProperty("GEMINI_API_KEY") ?: ""

android {
    namespace = "com.codemaster.madhuri"
    compileSdk {
        version = release(37)
    }

    defaultConfig {
        applicationId = "com.codemaster.madhuri"
        minSdk = 26
        targetSdk = 36
        versionCode = 56
        versionName = "2.17.1"

        buildConfigField("String", "GEMINI_API_KEY", "\"$geminiApiKey\"")
    }

    // One fixed keystore for every build, so a new APK installs over the old one
    // instead of failing with "package conflicts with an existing package".
    // This is a debug-grade key that ships with the project on purpose.
    signingConfigs {
        create("stable") {
            storeFile = rootProject.file("keystore/madhuri-debug.p12")
            storePassword = "madhuri123"
            keyAlias = "madhuri"
            keyPassword = "madhuri123"
            storeType = "PKCS12"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("stable")
        }
        release {
            signingConfig = signingConfigs.getByName("stable")
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.datastore.preferences)
    implementation(libs.okhttp)
    implementation(libs.androidx.navigation.compose)

    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.foundation)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.core)

    debugImplementation(libs.androidx.compose.ui.tooling)
}
