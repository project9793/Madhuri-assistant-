package com.codemaster.madhuri.ui.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.codemaster.madhuri.AppContainer
import com.codemaster.madhuri.data.ChatRepository
import com.codemaster.madhuri.data.ConversationEngine
import com.codemaster.madhuri.data.EngineEvent
import com.codemaster.madhuri.model.AssistantError
import com.codemaster.madhuri.model.ChatMessage
import com.codemaster.madhuri.model.ChatSession
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * Text chat: streaming replies, image questions, regenerate, stop and delete.
 * Every finished turn is written to [ChatRepository] so History can list it.
 */
class ChatViewModel(
    private val chatRepository: ChatRepository,
    private val conversationEngine: ConversationEngine,
    private val fileRecorder: com.codemaster.madhuri.voice.FileRecorder,
    private val geminiClient: com.codemaster.madhuri.data.GeminiClient,
    private val settingsRepository: com.codemaster.madhuri.data.SettingsRepository
) : ViewModel() {

    data class UiState(
        val sessionId: String? = null,
        val title: String = "New chat",
        val messages: List<ChatMessage> = emptyList(),
        val streamingText: String = "",
        val isStreaming: Boolean = false,
        val error: AssistantError? = null,
        val errorDetail: String? = null,
        val attachmentBase64: String? = null,
        val attachmentMimeType: String? = null,
        val dictating: Boolean = false,
        val dictatedText: String? = null,
        val dictationStatus: String? = null,
        val attachmentLabel: String? = null
    )

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    private var session: ChatSession? = null
    private var streamJob: Job? = null

    fun openSession(id: String?) {
        if (id == null || id == "new" || id == session?.id) return
        viewModelScope.launch {
            val loaded = chatRepository.load(id) ?: return@launch
            session = loaded
            _uiState.update {
                it.copy(
                    sessionId = loaded.id,
                    title = loaded.title,
                    messages = loaded.messages,
                    streamingText = "",
                    isStreaming = false
                )
            }
        }
    }

    /** Mic button: record, transcribe, drop the text into the composer. */
    fun toggleDictation() {
        if (_uiState.value.dictating) {
            fileRecorder.stop()
            return
        }
        fileRecorder.listener = object : com.codemaster.madhuri.voice.FileRecorder.Listener {
            override fun onLevel(level: Float) = Unit

            override fun onError(message: String) {
                _uiState.update {
                    it.copy(dictating = false, dictationStatus = null, errorDetail = message)
                }
            }

            override fun onFinished(recording: com.codemaster.madhuri.voice.FileRecorder.Recording?) {
                if (recording == null) {
                    _uiState.update { it.copy(dictating = false, dictationStatus = null) }
                    return
                }
                viewModelScope.launch {
                    _uiState.update { it.copy(dictationStatus = "Transcribing…") }
                    val settings = settingsRepository.current()
                    val base64 = android.util.Base64.encodeToString(
                        recording.bytes,
                        android.util.Base64.NO_WRAP
                    )
                    var heard: String? = null

                    if (settings.apiKey.isNotBlank()) {
                        heard = geminiClient.transcribe(
                            "gemini-3.5-flash-lite",
                            settings.apiKey,
                            base64,
                            recording.mimeType
                        ).getOrNull()
                    }
                    if (heard.isNullOrBlank() && com.codemaster.madhuri.data.GroqClient.isGroqKey(settings.grokKey)) {
                        heard = com.codemaster.madhuri.data.GroqClient.transcribe(
                            settings.grokKey,
                            recording.bytes,
                            settings.language.tag,
                            "clip.m4a",
                            recording.mimeType
                        ).getOrNull()
                    }

                    _uiState.update {
                        it.copy(
                            dictating = false,
                            dictationStatus = null,
                            dictatedText = heard
                                ?.trim()
                                ?.takeIf { text ->
                                    text.isNotBlank() &&
                                        !text.equals("NONE", ignoreCase = true) &&
                                        !text.equals("null", ignoreCase = true)
                                },
                            errorDetail = if (heard.isNullOrBlank()) {
                                "dictation: mic level ${"%.2f".format(recording.peakLevel)} — nothing was transcribed"
                            } else {
                                it.errorDetail
                            }
                        )
                    }
                }
            }
        }
        _uiState.update { it.copy(dictating = true, dictationStatus = "Listening…", dictatedText = null) }
        fileRecorder.start()
    }

    fun clearDictatedText() {
        _uiState.update { it.copy(dictatedText = null) }
    }

    fun newChat() {
        streamJob?.cancel()
        session = null
        _uiState.update {
            it.copy(
                sessionId = null,
                title = "New chat",
                messages = emptyList(),
                streamingText = "",
                isStreaming = false,
                error = null
            )
        }
    }

    fun attachImage(base64: String, mimeType: String, label: String) {
        _uiState.update {
            it.copy(attachmentBase64 = base64, attachmentMimeType = mimeType, attachmentLabel = label)
        }
    }

    fun clearAttachment() {
        _uiState.update {
            it.copy(attachmentBase64 = null, attachmentMimeType = null, attachmentLabel = null)
        }
    }

    fun send(text: String) {
        val state = _uiState.value
        if (text.isBlank() && state.attachmentBase64 == null) return
        dispatch(
            text = text,
            imageBase64 = state.attachmentBase64,
            imageMimeType = state.attachmentMimeType
        )
        clearAttachment()
    }

    /** Drops the last assistant turn and asks again with the same user message. */
    fun regenerate() {
        val current = session ?: return
        val messages = current.messages
        val lastUserIndex = messages.indexOfLast { it.role == ChatMessage.Role.USER }
        if (lastUserIndex == -1) return
        val lastUser = messages[lastUserIndex]
        val trimmed = messages.take(lastUserIndex)
        val updated = current.copy(messages = trimmed, updatedAt = System.currentTimeMillis())
        session = updated
        _uiState.update { it.copy(messages = trimmed) }
        dispatch(lastUser.text, lastUser.imageBase64, lastUser.imageMimeType)
    }

    fun stopGeneration() {
        streamJob?.cancel()
        val partial = _uiState.value.streamingText
        val current = session
        if (current != null && partial.isNotBlank()) {
            val message = ChatMessage(role = ChatMessage.Role.ASSISTANT, text = partial)
            val updated = current.copy(
                messages = current.messages + message,
                updatedAt = System.currentTimeMillis()
            )
            session = updated
            _uiState.update {
                it.copy(
                    messages = updated.messages,
                    streamingText = "",
                    isStreaming = false
                )
            }
            viewModelScope.launch { chatRepository.save(updated) }
        } else {
            _uiState.update { it.copy(streamingText = "", isStreaming = false) }
        }
    }

    fun dismissError() {
        _uiState.update { it.copy(error = null, errorDetail = null) }
    }

    private fun dispatch(text: String, imageBase64: String?, imageMimeType: String?) {
        val current = session ?: ChatSession(
            title = text.take(40).ifBlank { "Image question" }
        )
        val history = current.messages
        val userMessage = ChatMessage(
            role = ChatMessage.Role.USER,
            text = text,
            imageBase64 = imageBase64,
            imageMimeType = imageMimeType
        )
        val updated = current.copy(
            messages = history + userMessage,
            updatedAt = System.currentTimeMillis()
        )
        session = updated
        _uiState.update {
            it.copy(
                sessionId = updated.id,
                title = updated.title,
                messages = updated.messages,
                streamingText = "",
                isStreaming = true,
                error = null
            )
        }

        streamJob = viewModelScope.launch {
            val builder = StringBuilder()
            conversationEngine.stream(history, text, imageBase64, imageMimeType).collect { event ->
                when (event) {
                    is EngineEvent.Token -> {
                        builder.append(event.text)
                        _uiState.update { it.copy(streamingText = builder.toString()) }
                    }

                    is EngineEvent.Failed -> {
                        _uiState.update {
                            it.copy(
                                isStreaming = false,
                                streamingText = "",
                                error = event.error,
                                errorDetail = event.detail
                            )
                        }
                    }

                    is EngineEvent.Completed -> {
                        val reply = event.text.ifBlank { builder.toString() }.trim()
                        val target = session ?: return@collect
                        val message = ChatMessage(role = ChatMessage.Role.ASSISTANT, text = reply)
                        val saved = target.copy(
                            messages = target.messages + message,
                            updatedAt = System.currentTimeMillis()
                        )
                        session = saved
                        chatRepository.save(saved)
                        _uiState.update {
                            it.copy(
                                messages = saved.messages,
                                streamingText = "",
                                isStreaming = false
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onCleared() {
        streamJob?.cancel()
        super.onCleared()
    }

    companion object {
        fun factory(container: AppContainer): ViewModelProvider.Factory = viewModelFactory {
            initializer {
                ChatViewModel(
                    chatRepository = container.chatRepository,
                    conversationEngine = container.conversationEngine,
                    fileRecorder = container.chatRecorder,
                    geminiClient = container.geminiClient,
                    settingsRepository = container.settingsRepository
                )
            }
        }
    }
}
