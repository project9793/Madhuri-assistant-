package com.codemaster.madhuri.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.codemaster.madhuri.model.VoiceState
import com.codemaster.madhuri.ui.theme.CyanSecondary
import com.codemaster.madhuri.ui.theme.ErrorRed
import com.codemaster.madhuri.ui.theme.PinkTertiary
import com.codemaster.madhuri.ui.theme.SuccessGreen
import com.codemaster.madhuri.ui.theme.VioletDeep
import com.codemaster.madhuri.ui.theme.VioletPrimary

/**
 * The animated orb that carries the whole voice loop. Each [VoiceState] has its
 * own colour pair and speed, so the user can tell listening from thinking from
 * speaking without reading any text.
 */
@Composable
fun AiOrb(
    state: VoiceState,
    modifier: Modifier = Modifier,
    level: Float = 0f,
    onClick: () -> Unit = {}
) {
    val transition = rememberInfiniteTransition(label = "orb")

    val pulse by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (state) {
                    VoiceState.LISTENING -> 900
                    VoiceState.SPEAKING -> 1200
                    VoiceState.PROCESSING -> 700
                    else -> 2600
                },
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val spin by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (state == VoiceState.PROCESSING) 2200 else 9000,
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "spin"
    )

    // While recording, the orb follows the microphone so the user can see that
    // their voice is actually being picked up.
    val intensity = if (state == VoiceState.LISTENING) (level * 3f).coerceIn(0f, 1f) else 0f

    val colors: List<Color> = when (state) {
        VoiceState.IDLE -> listOf(VioletPrimary, CyanSecondary)
        VoiceState.LISTENING -> listOf(CyanSecondary, VioletPrimary)
        VoiceState.PROCESSING -> listOf(PinkTertiary, VioletDeep)
        VoiceState.SPEAKING -> listOf(SuccessGreen, CyanSecondary)
        VoiceState.INTERRUPTED -> listOf(Color(0xFFFFC857), PinkTertiary)
        VoiceState.ERROR -> listOf(ErrorRed, PinkTertiary)
    }

    Box(
        modifier = modifier
            .size(264.dp)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val radius = size.minDimension / 2f
            val center = Offset(size.width / 2f, size.height / 2f)

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        colors[0].copy(alpha = 0.34f),
                        colors[1].copy(alpha = 0.10f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = radius
                ),
                radius = radius,
                center = center
            )

            drawCircle(
                color = colors[0].copy(alpha = 0.35f),
                radius = radius * (0.74f + 0.05f * pulse),
                center = center,
                style = Stroke(width = 3f)
            )

            drawCircle(
                brush = Brush.linearGradient(
                    colors = colors,
                    start = Offset(center.x - radius * 0.5f, center.y - radius * 0.5f),
                    end = Offset(center.x + radius * 0.5f, center.y + radius * 0.5f)
                ),
                radius = radius * (0.44f + 0.05f * pulse + 0.10f * intensity),
                center = center
            )

            if (intensity > 0.02f) {
                drawCircle(
                    color = colors[0].copy(alpha = 0.18f + 0.30f * intensity),
                    radius = radius * (0.78f + 0.20f * intensity),
                    center = center,
                    style = Stroke(width = 4f)
                )
            }

            drawCircle(
                color = Color.White.copy(alpha = 0.22f),
                radius = radius * 0.20f,
                center = Offset(center.x - radius * 0.16f, center.y - radius * 0.20f)
            )

            rotate(degrees = spin, pivot = center) {
                drawArc(
                    color = colors[1].copy(alpha = 0.9f),
                    startAngle = 0f,
                    sweepAngle = 64f,
                    useCenter = false,
                    topLeft = Offset(center.x - radius * 0.62f, center.y - radius * 0.62f),
                    size = Size(radius * 1.24f, radius * 1.24f),
                    style = Stroke(width = 6f, cap = StrokeCap.Round)
                )
                drawArc(
                    color = colors[0].copy(alpha = 0.7f),
                    startAngle = 180f,
                    sweepAngle = 34f,
                    useCenter = false,
                    topLeft = Offset(center.x - radius * 0.50f, center.y - radius * 0.50f),
                    size = Size(radius * 1.0f, radius * 1.0f),
                    style = Stroke(width = 4f, cap = StrokeCap.Round)
                )
            }
        }
    }
}
