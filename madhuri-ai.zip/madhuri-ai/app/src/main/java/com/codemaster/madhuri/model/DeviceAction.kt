package com.codemaster.madhuri.model

import org.json.JSONObject

/**
 * A permitted Android action the assistant asked for. The model returns one of
 * these as JSON inside an `<<ACTION>>` block; the app decides whether to run it,
 * ask for confirmation first, or refuse it.
 */
data class DeviceAction(
    val type: String,
    val app: String? = null,
    val url: String? = null,
    val query: String? = null,
    val number: String? = null,
    val name: String? = null,
    val message: String? = null,
    val hour: Int? = null,
    val minute: Int? = null,
    val label: String? = null,
    val percent: Int? = null,
    val screen: String? = null,
    val text: String? = null
) {
    /** Short line shown in the confirmation dialog. */
    fun describe(): String = when (type) {
        "open_app" -> "Open ${app ?: "an app"}"
        "open_url" -> "Open ${url ?: "a link"}"
        "search_web" -> "Search Google for \"${query ?: ""}\""
        "search_youtube" -> "Search YouTube for \"${query ?: ""}\""
        "dial" -> "Open the dialer with ${number ?: "a number"}"
        "call" -> "Call ${number ?: name ?: "a contact"}"
        "call_contact" -> "Call ${name ?: "a contact"}"
        "sms" -> "Text ${number ?: name ?: "a contact"}"
        "whatsapp" -> "WhatsApp ${number ?: name ?: "a contact"}"
        "set_alarm" -> "Set an alarm for ${formatTime()}"
        "set_reminder" -> "Add \"${label ?: text ?: "a reminder"}\" to the calendar"
        "set_volume" -> "Set volume to ${percent ?: 50}%"
        "open_settings" -> "Open ${screen ?: "settings"}"
        "share_text" -> "Share text"
        "open_tab" -> "Open ${name ?: "settings"}"
        "set_name" -> "Rename me to ${name ?: "the new name"}"
        "set_voice" -> "Change my voice to ${name ?: text ?: "the chosen one"}"
        "set_personality" -> "Become ${name ?: "that personality"}"
        "set_language" -> "Talk in ${name ?: "that language"}"
        "open_camera" -> "Open the camera"
        "open_gallery" -> "Open the gallery"
        else -> "Run $type"
    }

    private fun formatTime(): String {
        val h = hour ?: 0
        val m = minute ?: 0
        return String.format("%02d:%02d", h, m)
    }

    companion object {
        fun fromJson(json: JSONObject): DeviceAction = DeviceAction(
            type = json.optString("type").ifBlank { json.optString("action") }.lowercase(),
            app = json.optStringOrNull("app"),
            url = json.optStringOrNull("url"),
            query = json.optStringOrNull("query"),
            number = json.optStringOrNull("number"),
            name = json.optStringOrNull("name") ?: json.optStringOrNull("contact"),
            message = json.optStringOrNull("message") ?: json.optStringOrNull("body"),
            hour = json.optIntOrNull("hour"),
            minute = json.optIntOrNull("minute"),
            label = json.optStringOrNull("label"),
            percent = json.optIntOrNull("percent") ?: json.optIntOrNull("level"),
            screen = json.optStringOrNull("screen"),
            text = json.optStringOrNull("text")
        )
    }
}

private fun JSONObject.optStringOrNull(key: String): String? {
    if (!has(key) || isNull(key)) return null
    val value = optString(key)
    return value.ifBlank { null }
}

private fun JSONObject.optIntOrNull(key: String): Int? {
    if (!has(key) || isNull(key)) return null
    return optInt(key, -1).takeIf { it >= 0 }
}
