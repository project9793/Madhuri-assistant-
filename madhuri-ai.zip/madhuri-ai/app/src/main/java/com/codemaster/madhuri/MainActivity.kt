package com.codemaster.madhuri

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.codemaster.madhuri.ui.navigation.AppRoot
import com.codemaster.madhuri.ui.theme.MadhuriTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // Launched from the assistant gesture? Go straight into listening.
        val launchedAsAssistant = intent?.action == Intent.ACTION_ASSIST

        setContent {
            MadhuriTheme {
                AppRoot(startListening = launchedAsAssistant)
            }
        }
    }
}
