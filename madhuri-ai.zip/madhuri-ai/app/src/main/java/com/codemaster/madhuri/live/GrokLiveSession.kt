package com.codemaster.madhuri.live

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import android.util.Base64
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/**
 * xAI's speech-to-speech session. The protocol follows the OpenAI Realtime
 * shape: a session.update first, input_audio_buffer.append for microphone
 * frames, and response.output_audio.delta for the spoken reply.
 *
 * Reuses [LiveVoiceSession.Listener] so the rest of the app does not care which
 * engine is talking.
 */
class GrokLiveSession(private val context: Context) {

    var listener: LiveVoiceSession.Listener? = null

    private val mainHandler = Handler(Looper.getMainLooper())
    private var client: OkHttpClient? = null
    private var socket: WebSocket? = null
    private var recorder: AudioRecord? = null
    private var player: AudioTrack? = null
    private var micThread: Thread? = null

    @Volatile private var running = false
    @Volatile private var ready = false

    val isRunning: Boolean get() = running

    fun start(apiKey: String, systemPrompt: String, voice: String, languageHint: String?) {
        stop()
        running = true
        ready = false

        val httpClient = OkHttpClient.Builder()
            .pingInterval(20, TimeUnit.SECONDS)
            .readTimeout(0, TimeUnit.MILLISECONDS)
            .build()
        client = httpClient

        val request = Request.Builder()
            .url(ENDPOINT)
            .header("Authorization", "Bearer $apiKey")
            .build()

        socket = httpClient.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(sessionUpdate(systemPrompt, voice, languageHint).toString())
                ready = true
                startMicrophone()
                mainHandler.post { listener?.onReady() }
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                handleEvent(text)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (!running) return
                running = false
                stopAudio()
                mainHandler.post { listener?.onError(t.message ?: "grok connection failed") }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (!running) return
                running = false
                stopAudio()
                mainHandler.post { listener?.onClosed(reason.ifBlank { "closed" }) }
            }
        })
    }

    fun stop() {
        running = false
        ready = false
        runCatching { socket?.close(1000, "bye") }
        socket = null
        client?.dispatcher?.executorService?.shutdown()
        client = null
        stopAudio()
    }

    private fun sessionUpdate(
        systemPrompt: String,
        voice: String,
        languageHint: String?
    ): JSONObject {
        val audio = JSONObject().apply {
            put(
                "input",
                JSONObject().apply {
                    put("format", JSONObject().put("type", "audio/pcm").put("rate", INPUT_RATE))
                    if (!languageHint.isNullOrBlank()) {
                        put("transcription", JSONObject().put("language_hint", languageHint))
                    }
                }
            )
            put("output", JSONObject().put("format", JSONObject().put("type", "audio/pcm").put("rate", OUTPUT_RATE)))
        }
        val session = JSONObject().apply {
            put("voice", voice)
            put("instructions", systemPrompt)
            put("turn_detection", JSONObject().put("type", "server_vad"))
            put("audio", audio)
        }
        return JSONObject().put("type", "session.update").put("session", session)
    }

    private fun handleEvent(text: String) {
        val event = runCatching { JSONObject(text) }.getOrNull() ?: return
        when (val type = event.optString("type")) {
            "response.output_audio.delta", "response.audio.delta" -> {
                val payload = event.optString("delta")
                if (payload.isNotBlank()) {
                    runCatching { playPcm(Base64.decode(payload, Base64.NO_WRAP)) }
                }
            }

            "response.output_audio_transcript.delta", "response.audio_transcript.delta" -> {
                val spoken = event.optString("delta")
                if (spoken.isNotBlank()) {
                    mainHandler.post { listener?.onModelTranscript(spoken) }
                }
            }

            "conversation.item.input_audio_transcription.completed",
            "conversation.item.input_audio_transcription.delta" -> {
                val spoken = event.optString("transcript").ifBlank { event.optString("delta") }
                if (spoken.isNotBlank()) {
                    mainHandler.post { listener?.onUserTranscript(spoken) }
                }
            }

            "input_audio_buffer.speech_started" -> {
                clearPlayback()
                mainHandler.post { listener?.onInterrupted() }
            }

            "response.done" -> mainHandler.post { listener?.onTurnComplete() }

            "error" -> {
                val message = event.optJSONObject("error")?.optString("message") ?: "grok error"
                running = false
                stopAudio()
                mainHandler.post { listener?.onError(message) }
            }

            else -> if (type.isEmpty()) return
        }
    }

    private fun startMicrophone() {
        if (!running) return
        val minBuffer = AudioRecord.getMinBufferSize(
            INPUT_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuffer <= 0) {
            mainHandler.post { listener?.onError("microphone is not available") }
            return
        }
        val record = runCatching {
            AudioRecord(
                MediaRecorder.AudioSource.MIC,
                INPUT_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuffer, CHUNK_BYTES * 4)
            )
        }.getOrNull()
        if (record == null || record.state != AudioRecord.STATE_INITIALIZED) {
            mainHandler.post { listener?.onError("microphone is not available") }
            return
        }
        recorder = record
        record.startRecording()

        micThread = thread(name = "madhuri-grok-mic", isDaemon = true) {
            val buffer = ByteArray(CHUNK_BYTES)
            while (running && ready) {
                val read = record.read(buffer, 0, buffer.size)
                if (read > 0) {
                    val chunk = if (read == buffer.size) buffer else buffer.copyOf(read)
                    val message = JSONObject().apply {
                        put("type", "input_audio_buffer.append")
                        put("audio", Base64.encodeToString(chunk, Base64.NO_WRAP))
                    }
                    runCatching { socket?.send(message.toString()) }
                }
            }
            runCatching { record.stop() }
            runCatching { record.release() }
        }
    }

    private fun playPcm(pcm: ByteArray) {
        if (!running) return
        val track = player ?: createPlayer() ?: return
        runCatching { track.write(pcm, 0, pcm.size) }
    }

    private fun createPlayer(): AudioTrack? {
        val minBuffer = AudioTrack.getMinBufferSize(
            OUTPUT_RATE,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val track = runCatching {
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(OUTPUT_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minBuffer, OUTPUT_RATE / 2))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
        }.getOrNull()
        if (track == null) {
            mainHandler.post { listener?.onError("audio output is not available") }
            return null
        }
        track.play()
        player = track
        return track
    }

    private fun clearPlayback() {
        val track = player ?: return
        runCatching { track.pause() }
        runCatching { track.flush() }
        runCatching { track.play() }
    }

    private fun stopAudio() {
        running = false
        ready = false
        runCatching { recorder?.stop() }
        runCatching { recorder?.release() }
        recorder = null
        micThread = null
        runCatching { player?.pause() }
        runCatching { player?.flush() }
        runCatching { player?.release() }
        player = null
    }

    companion object {
        const val MODEL = "grok-voice-latest"
        const val DEFAULT_VOICE = "eve"
        const val ENDPOINT = "wss://api.x.ai/v1/realtime?model=$MODEL"
        private const val INPUT_RATE = 16_000
        private const val OUTPUT_RATE = 24_000
        private const val CHUNK_BYTES = INPUT_RATE / 10 * 2
    }
}
