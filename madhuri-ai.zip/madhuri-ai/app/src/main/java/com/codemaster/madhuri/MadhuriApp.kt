package com.codemaster.madhuri

import android.app.Application
import android.content.Context
import com.codemaster.madhuri.actions.DeviceActionHandler
import com.codemaster.madhuri.data.ChatRepository
import com.codemaster.madhuri.data.ConversationEngine
import com.codemaster.madhuri.data.GeminiClient
import com.codemaster.madhuri.data.MemoryRepository
import com.codemaster.madhuri.data.OpenRouterClient
import com.codemaster.madhuri.data.SettingsRepository
import com.codemaster.madhuri.voice.AudioRecorder
import com.codemaster.madhuri.voice.FileRecorder
import com.codemaster.madhuri.live.GrokLiveSession
import com.codemaster.madhuri.live.LiveVoiceSession
import com.codemaster.madhuri.voice.GeminiSpeaker
import com.codemaster.madhuri.voice.SpeechRecognizerManager
import com.codemaster.madhuri.voice.SpeechSynthesizer

class MadhuriApp : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}

/**
 * Manual dependency graph. One instance per process; ViewModels receive what they
 * need through their factories, so nothing reaches for a global from inside UI.
 */
class AppContainer(application: Application) {

    val appContext: Context = application.applicationContext

    val settingsRepository = SettingsRepository(appContext)
    val chatRepository = ChatRepository(appContext)
    val memoryRepository = MemoryRepository(appContext)
    val geminiClient = GeminiClient()
    val openRouterClient = OpenRouterClient()
    val conversationEngine = ConversationEngine(geminiClient, openRouterClient, settingsRepository, memoryRepository)
    val speechRecognizer = SpeechRecognizerManager(appContext)
    val speechSynthesizer = SpeechSynthesizer(appContext)
    val audioRecorder = AudioRecorder(appContext)
    val fileRecorder = FileRecorder(appContext)
    val chatRecorder = FileRecorder(appContext)
    val geminiSpeaker = GeminiSpeaker(appContext)
    val liveSession = LiveVoiceSession(appContext)
    val grokSession = GrokLiveSession(appContext)
    val deviceActions = DeviceActionHandler(appContext)
}

val Context.appContainer: AppContainer
    get() = (applicationContext as MadhuriApp).container
