package com.codemaster.madhuri.voice

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Base64
import androidx.core.content.ContextCompat
import java.io.File
import kotlin.concurrent.thread

/**
 * Speech capture.
 *
 * This deliberately uses MediaRecorder rather than raw AudioRecord: on several
 * phones AudioRecord hands back near-silent buffers while every recorder app on
 * the same device works fine. MediaRecorder goes through the same audio path the
 * system recorder uses, and its maxAmplitude gives us a real level meter.
 */
class AudioRecorder(private val context: Context) {

    data class Clip(
        val wavBase64: String,
        val durationMs: Long,
        val peakLevel: Float,
        val mimeType: String = "audio/mp4",
        val fileName: String = "clip.m4a",
        val rawBytes: ByteArray = ByteArray(0)
    )

    interface Listener {
        fun onLevel(level: Float)
        fun onFinished(clip: Clip?)
        fun onError(message: String)
    }

    var listener: Listener? = null

    /** How much silence ends the recording; set from Settings. */
    var silenceMs: Long = SILENCE_MS

    private val mainHandler = Handler(Looper.getMainLooper())
    private var recorder: MediaRecorder? = null
    private var output: File? = null
    private var meter: Thread? = null
    private var startedAt = 0L
    private var peak = 0f
    private var running = false
    private var spokeAtLeastOnce = false
    private var silentMs = 0L

    fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    fun start() {
        if (running) return
        if (!hasPermission()) {
            listener?.onError("Microphone permission is needed to record.")
            return
        }

        val file = File(context.cacheDir, "madhuri-${System.currentTimeMillis()}.m4a")
        val media = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(context)
        } else {
            @Suppress("DEPRECATION")
            MediaRecorder()
        }
        try {
            media.setAudioSource(MediaRecorder.AudioSource.MIC)
            media.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            media.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            media.setAudioChannels(1)
            media.setAudioSamplingRate(44_100)
            media.setAudioEncodingBitRate(96_000)
            media.setOutputFile(file.absolutePath)
            media.prepare()
            media.start()
        } catch (e: Exception) {
            runCatching { media.release() }
            file.delete()
            listener?.onError("Could not open the microphone: ${e.message ?: "unknown"}")
            return
        }

        recorder = media
        output = file
        running = true
        startedAt = System.currentTimeMillis()
        peak = 0f
        spokeAtLeastOnce = false
        silentMs = 0L

        meter = thread(name = "madhuri-meter", isDaemon = true) {
            while (running) {
                val amplitude = runCatching { media.maxAmplitude }.getOrDefault(0)
                val level = (amplitude / 32767f).coerceIn(0f, 1f)
                if (level > peak) peak = level
                mainHandler.post { listener?.onLevel(level) }

                val elapsed = System.currentTimeMillis() - startedAt
                if (level > SPEECH_THRESHOLD) {
                    spokeAtLeastOnce = true
                    silentMs = 0
                } else if (spokeAtLeastOnce) {
                    silentMs += TICK_MS
                }

                val longEnough = elapsed >= MIN_SPEECH_MS
                if (elapsed >= MAX_MS || (longEnough && spokeAtLeastOnce && silentMs >= silenceMs)) {
                    mainHandler.post { stop() }
                    return@thread
                }
                Thread.sleep(TICK_MS)
            }
        }
    }

    fun stop() {
        if (!running) return
        running = false
        val media = recorder
        recorder = null
        val file = output
        output = null
        val duration = System.currentTimeMillis() - startedAt

        val stopped = runCatching {
            media?.stop()
            media?.release()
            true
        }.getOrDefault(false)

        if (!stopped || file == null || !file.exists() || file.length() < 1_000) {
            runCatching { media?.release() }
            file?.delete()
            listener?.onFinished(null)
            return
        }

        val bytes = runCatching { file.readBytes() }.getOrNull()
        file.delete()
        if (bytes == null) {
            listener?.onFinished(null)
            return
        }
        listener?.onFinished(
            Clip(
                wavBase64 = Base64.encodeToString(bytes, Base64.NO_WRAP),
                durationMs = duration,
                peakLevel = peak,
                rawBytes = bytes
            )
        )
    }

    fun cancel() {
        running = false
        runCatching { recorder?.stop() }
        runCatching { recorder?.release() }
        recorder = null
        output?.delete()
        output = null
    }

    private companion object {
        const val MAX_MS = 30_000L
        const val MIN_SPEECH_MS = 900L
        const val SILENCE_MS = 2_000L
        const val SPEECH_THRESHOLD = 0.02f
        const val TICK_MS = 120L
    }
}
