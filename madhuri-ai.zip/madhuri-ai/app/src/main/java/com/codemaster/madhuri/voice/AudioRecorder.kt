package com.codemaster.madhuri.voice

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import android.util.Base64
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.max

/**
 * Records a short utterance straight from the microphone and hands back a WAV
 * clip, so voice input never depends on the phone's speech-recognition service.
 * Recording stops by itself after a pause, and never runs longer than [MAX_MS].
 */
class AudioRecorder(private val context: Context) {

    data class Clip(val wavBase64: String, val durationMs: Long, val peakLevel: Float)

    interface Listener {
        fun onLevel(level: Float)
        fun onFinished(clip: Clip?)
        fun onError(message: String)
    }

    var listener: Listener? = null

    /** How much silence ends the recording; set from Settings. */
    var silenceMs: Long = SILENCE_MS

    private val mainHandler = Handler(Looper.getMainLooper())
    private var record: AudioRecord? = null
    @Volatile private var running = false
    @Volatile private var deliverClip = true
    private var worker: Thread? = null
    private var startedAt = 0L

    val isRecording: Boolean get() = running

    fun hasPermission(): Boolean = ContextCompat.checkSelfPermission(
        context,
        android.Manifest.permission.RECORD_AUDIO
    ) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    fun start() {
        if (running) return
        if (!hasPermission()) {
            listener?.onError("Microphone permission is needed to record.")
            return
        }
        val minBuffer = AudioRecord.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuffer <= 0) {
            listener?.onError("This phone cannot record audio.")
            return
        }
        val recorder = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                max(minBuffer, SAMPLE_RATE / 2)
            )
        } catch (e: Exception) {
            listener?.onError("Could not open the microphone: ${e.message ?: "unknown"}")
            return
        }
        if (recorder.state != AudioRecord.STATE_INITIALIZED) {
            recorder.release()
            listener?.onError("The microphone is busy. Close other apps and try again.")
            return
        }
        record = recorder
        running = true
        deliverClip = true
        startedAt = System.currentTimeMillis()
        recorder.startRecording()

        worker = thread(name = "madhuri-recorder", isDaemon = true) {
            val pcm = ByteArrayOutputStream()
            val buffer = ByteArray(4096)
            var silentMs = 0L
            var spokeAtLeastOnce = false
            var finished = false
            var maxLevel = 0f
            while (running) {
                val read = recorder.read(buffer, 0, buffer.size)
                if (read <= 0) continue
                pcm.write(buffer, 0, read)
                val level = peakLevel(buffer, read)
                if (level > maxLevel) maxLevel = level
                mainHandler.post { listener?.onLevel(level) }
                val chunkMs = (read / 2) * 1000L / SAMPLE_RATE
                if (level > SPEECH_THRESHOLD) {
                    spokeAtLeastOnce = true
                    silentMs = 0
                } else if (spokeAtLeastOnce) {
                    silentMs += chunkMs
                }
                val elapsed = System.currentTimeMillis() - startedAt
                val longEnough = elapsed >= MIN_SPEECH_MS
                if (elapsed >= MAX_MS ||
                    (longEnough && spokeAtLeastOnce && silentMs >= silenceMs)
                ) {
                    running = false
                    finished = true
                    finish(pcm.toByteArray(), maxLevel)
                }
            }
            // The user tapped stop (or cancel released the mic) while we were
            // still looping: hand the clip over here so the UI never hangs.
            if (!finished && deliverClip) {
                finish(pcm.toByteArray(), maxLevel)
            }
        }
    }

    /** User tapped stop: whatever has been captured so far is used. */
    fun stop() {
        if (!running) {
            // Nothing was being recorded; make sure the UI is not stuck.
            mainHandler.post { listener?.onFinished(null) }
            return
        }
        running = false
        val recorder = record
        try {
            recorder?.stop()
        } catch (e: IllegalStateException) {
            // stop() throws if nothing was captured; the clip below is still valid.
        }
        recorder?.release()
        record = null
        // The worker thread finishes the clip once it leaves its loop.
    }

    fun cancel() {
        running = false
        deliverClip = false
        val recorder = record
        try {
            recorder?.stop()
        } catch (e: IllegalStateException) {
            // already stopped
        }
        recorder?.release()
        record = null
        worker = null
    }

    private fun finish(pcm: ByteArray, maxLevel: Float) {
        val recorder = record
        try {
            recorder?.stop()
        } catch (e: IllegalStateException) {
            // already stopped
        }
        recorder?.release()
        record = null
        val durationMs = System.currentTimeMillis() - startedAt
        // Keep anything above a third of a second: a quiet recording is still
        // worth sending, Gemini can often make it out.
        if (pcm.size < SAMPLE_RATE / 4) {
            mainHandler.post { listener?.onFinished(null) }
            return
        }
        val wav = wrapAsWav(pcm)
        val clip = Clip(
            wavBase64 = Base64.encodeToString(wav, Base64.NO_WRAP),
            durationMs = durationMs,
            peakLevel = maxLevel
        )
        mainHandler.post { listener?.onFinished(clip) }
    }

    private fun peakLevel(buffer: ByteArray, length: Int): Float {
        val shorts = ByteBuffer.wrap(buffer, 0, length).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        var peak = 0
        while (shorts.hasRemaining()) {
            peak = max(peak, abs(shorts.get().toInt()))
        }
        return peak / 32768f
    }

    private fun wrapAsWav(pcm: ByteArray): ByteArray {
        val header = ByteArray(44)
        val totalLength = pcm.size + 36
        val byteRate = SAMPLE_RATE * 2
        fun putAscii(offset: Int, value: String) {
            value.toByteArray(Charsets.US_ASCII).copyInto(header, offset)
        }
        fun putInt(offset: Int, value: Int) {
            ByteBuffer.wrap(header, offset, 4).order(ByteOrder.LITTLE_ENDIAN).putInt(value)
        }
        fun putShort(offset: Int, value: Int) {
            ByteBuffer.wrap(header, offset, 2).order(ByteOrder.LITTLE_ENDIAN).putShort(value.toShort())
        }
        putAscii(0, "RIFF")
        putInt(4, totalLength)
        putAscii(8, "WAVE")
        putAscii(12, "fmt ")
        putInt(16, 16)
        putShort(20, 1)
        putShort(22, 1)
        putInt(24, SAMPLE_RATE)
        putInt(28, byteRate)
        putShort(32, 2)
        putShort(34, 16)
        putAscii(36, "data")
        putInt(40, pcm.size)
        val out = ByteArrayOutputStream(header.size + pcm.size)
        out.write(header)
        out.write(pcm)
        return out.toByteArray()
    }

    private companion object {
        const val SAMPLE_RATE = 8_000
        const val MAX_MS = 12_000L
        const val MIN_SPEECH_MS = 1_200L
        const val SILENCE_MS = 2_200L
        const val SPEECH_THRESHOLD = 0.018f
    }
}
