package com.codemaster.madhuri.ui.chat

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.codemaster.madhuri.appContainer
import com.codemaster.madhuri.model.ChatMessage
import com.codemaster.madhuri.ui.components.MarkdownText
import com.codemaster.madhuri.util.ImageLoader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    preset: String,
    sessionId: String,
    onBack: () -> Unit,
    viewModel: ChatViewModel = viewModel(
        factory = ChatViewModel.factory(LocalContext.current.appContainer)
    )
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    var input by remember(preset) {
        mutableStateOf(ChatPresets.promptFor(preset))
    }

    LaunchedEffect(sessionId) {
        if (sessionId != "new") viewModel.openSession(sessionId)
    }

    val imagePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                ImageLoader.toBase64Jpeg(context, uri)
            }
            if (result != null) {
                viewModel.attachImage(result.first, result.second, "Photo attached")
            }
        }
    }

    LaunchedEffect(state.messages.size, state.streamingText.length) {
        val total = state.messages.size + if (state.streamingText.isNotEmpty()) 1 else 0
        if (total > 0) listState.animateScrollToItem(total - 1)
    }

    // Speech becomes text in the composer, ready to edit before sending.
    LaunchedEffect(state.dictatedText) {
        val spoken = state.dictatedText
        if (!spoken.isNullOrBlank()) {
            input = if (input.isBlank()) spoken else input + " " + spoken
            viewModel.clearDictatedText()
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        // The whole screen (composer included) rides above the keyboard.
        modifier = Modifier
            .fillMaxSize()
            .imePadding(),
        topBar = {
            TopAppBar(
                title = { Text(state.title, maxLines = 1) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = viewModel::newChat) {
                        Icon(Icons.Filled.Add, contentDescription = "New chat")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            ChatComposer(
                input = input,
                onInputChange = { input = it },
                attachmentLabel = state.attachmentLabel,
                isStreaming = state.isStreaming,
                onClearAttachment = viewModel::clearAttachment,
                onAttach = {
                    imagePicker.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                onSend = {
                    viewModel.send(input)
                    input = ""
                },
                onStop = viewModel::stopGeneration,
                dictating = state.dictating,
                dictationStatus = state.dictationStatus,
                onDictate = viewModel::toggleDictation
            )
        }
    ) { padding ->
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (state.messages.isEmpty() && !state.isStreaming) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 40.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Ask anything",
                            style = MaterialTheme.typography.headlineSmall
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = "Text, code, images, or a phone action. Madhuri answers in your language.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            items(state.messages, key = { it.id }) { message ->
                MessageBubble(message)
            }

            if (state.isStreaming) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (state.streamingText.isBlank()) {
                            CircularProgressIndicator(modifier = Modifier.width(20.dp))
                            Spacer(Modifier.width(10.dp))
                            Text("Thinking…", style = MaterialTheme.typography.bodyMedium)
                        } else {
                            Surface(
                                shape = RoundedCornerShape(18.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
                            ) {
                                Box(Modifier.padding(12.dp)) {
                                    MarkdownText(state.streamingText)
                                }
                            }
                        }
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    if (state.messages.count { it.role == ChatMessage.Role.ASSISTANT } > 0 && !state.isStreaming) {
                        TextButton(onClick = viewModel::regenerate) {
                            Icon(Icons.Filled.Refresh, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text("Regenerate")
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }

    state.error?.let { error ->
        AlertDialog(
            onDismissRequest = viewModel::dismissError,
            title = { Text("Something went wrong") },
            text = {
                Column {
                    Text(error.bilingual)
                    state.errorDetail?.let { detail ->
                        Spacer(Modifier.height(10.dp))
                        Text(
                            text = detail,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = viewModel::dismissError) { Text("OK") }
            }
        )
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    val isUser = message.role == ChatMessage.Role.USER
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            shape = RoundedCornerShape(
                topStart = 18.dp,
                topEnd = 18.dp,
                bottomStart = if (isUser) 18.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 18.dp
            ),
            color = if (isUser) {
                MaterialTheme.colorScheme.primary.copy(alpha = 0.85f)
            } else {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.75f)
            },
            modifier = Modifier.fillMaxWidth(0.92f)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                if (message.imageBase64 != null) {
                    AssistChip(onClick = {}, label = { Text("Image attached") })
                    Spacer(Modifier.height(6.dp))
                }
                if (isUser) {
                    Text(
                        text = message.text,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                } else {
                    MarkdownText(message.text)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ChatComposer(
    input: String,
    onInputChange: (String) -> Unit,
    attachmentLabel: String?,
    isStreaming: Boolean,
    onClearAttachment: () -> Unit,
    onAttach: () -> Unit,
    onSend: () -> Unit,
    onStop: () -> Unit,
    dictating: Boolean = false,
    dictationStatus: String? = null,
    onDictate: () -> Unit = {}
) {
    Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 3.dp) {
        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            if (dictating || dictationStatus != null) {
                Text(
                    text = dictationStatus ?: "Listening…",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 8.dp, bottom = 4.dp)
                )
            }
            if (attachmentLabel != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AssistChip(onClick = onClearAttachment, label = { Text("$attachmentLabel · remove") })
                }
            }
            Row(verticalAlignment = Alignment.Bottom) {
                IconButton(onClick = onAttach) {
                    Icon(Icons.Filled.Add, contentDescription = "Attach image")
                }
                IconButton(onClick = onDictate) {
                    Icon(
                        imageVector = if (dictating) Icons.Filled.Close else Icons.Filled.Mic,
                        contentDescription = if (dictating) "Stop dictating" else "Dictate",
                        tint = if (dictating) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                OutlinedTextField(
                    value = input,
                    onValueChange = onInputChange,
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Message Madhuri…") },
                    shape = RoundedCornerShape(20.dp),
                    maxLines = 5
                )
                if (isStreaming) {
                    TextButton(onClick = onStop) { Text("Stop") }
                } else {
                    IconButton(onClick = onSend) {
                        Icon(Icons.Filled.Send, contentDescription = "Send")
                    }
                }
            }
        }
    }
}

/** Seed prompts used by the home screen's quick action cards. */
object ChatPresets {
    fun promptFor(preset: String): String = when (preset) {
        "coding" ->
            "Help me build an Android app. Ask me what I'm building, then give complete, runnable Kotlin code."

        "website" ->
            "Create a complete responsive website with HTML, CSS and JavaScript. Ask me for the topic first."

        "phone" ->
            "What can you control on my phone? Show me examples like opening YouTube, setting an alarm, or calling someone."

        "image" ->
            "I'll attach a photo — tell me what you see and answer my question about it."

        else -> ""
    }
}
