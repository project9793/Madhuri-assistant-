package com.codemaster.madhuri.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class WeatherInfo(
    val temperature: Int,
    val description: String,
    val emoji: String
)

/**
 * Live weather from Open-Meteo, which needs no API key. One small request per
 * refresh; nothing is stored.
 */
object WeatherRepository {

    suspend fun current(latitude: Double, longitude: Double): WeatherInfo? =
        withContext(Dispatchers.IO) {
            val url = URL(
                "https://api.open-meteo.com/v1/forecast" +
                    "?latitude=$latitude&longitude=$longitude" +
                    "&current=temperature_2m,weather_code&timezone=auto"
            )
            var connection: HttpURLConnection? = null
            try {
                connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 12_000
                    readTimeout = 15_000
                }
                if (connection.responseCode !in 200..299) return@withContext null
                val body = connection.inputStream.bufferedReader().use { it.readText() }
                val current = JSONObject(body).optJSONObject("current") ?: return@withContext null
                val temp = current.optDouble("temperature_2m", Double.NaN)
                if (temp.isNaN()) return@withContext null
                val code = current.optInt("weather_code", -1)
                val (text, emoji) = describe(code)
                WeatherInfo(temperature = Math.round(temp).toInt(), description = text, emoji = emoji)
            } catch (e: IOException) {
                null
            } catch (e: Exception) {
                null
            } finally {
                connection?.disconnect()
            }
        }

    /** WMO weather codes, as used by Open-Meteo. */
    private fun describe(code: Int): Pair<String, String> = when (code) {
        0 -> "Clear sky" to "☀️"
        1 -> "Mostly clear" to "🌤️"
        2 -> "Partly cloudy" to "⛅"
        3 -> "Overcast" to "☁️"
        45, 48 -> "Fog" to "🌫️"
        51, 53, 55, 56, 57 -> "Drizzle" to "🌦️"
        61, 63, 65, 66, 67 -> "Rain" to "🌧️"
        71, 73, 75, 77 -> "Snow" to "🌨️"
        80, 81, 82 -> "Rain showers" to "🌦️"
        85, 86 -> "Snow showers" to "🌨️"
        95 -> "Thunderstorm" to "⛈️"
        96, 99 -> "Thunderstorm with hail" to "⛈️"
        else -> "Weather" to "🌡️"
    }
}
