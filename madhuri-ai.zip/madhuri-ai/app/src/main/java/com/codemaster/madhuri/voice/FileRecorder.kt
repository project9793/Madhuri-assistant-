package com.codemaster.madhuri.voice

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.Looper
import java.io.File
import kotlin.concurrent.thread

/**
 * Records speech with MediaRecorder — the same path every phone recorder app
 * uses, so it works on devices where raw AudioRecord comes back silent.
 *
 * Output is AAC in an .m4a container, which both Gemini and Groq Whisper accept.
 */
class FileRecorder(private val context: Context) {

    interface Listener {
        fun onLevel(level: Float)
        fun onFinished(recording: Recording?)
        fun onError(message: String)
    }

    data class Recording(
        val file: File,
        val bytes: ByteArray,
        val mimeType: String,
        val durationMs: Long,
        val peakLevel: Float
    )

    var listener: Listener? = null
    var maxDurationMs: Long = MAX_MS

    /** Ends the take after this much silence once the user has spoken. */
    var silenceMs: Long = 2_000L

    private val mainHandler = Handler(Looper.getMainLooper())
    private var recorder: MediaRecorder? = null
    private var output: File? = null
    private var meterThread: Thread? = null
    private var startedAt = 0L
    private var peak = 0f
    private var running = false
    private var spokeAtLeastOnce = false
    private var silentMs = 0L
    private var noiseFloor = 0f
    private var noiseSamples = 0
    private var noiseSum = 0f

    val isRecording: Boolean get() = running

    fun start() {
        // A stale session must never block a fresh one.
        if (running) stop()
        val file = File(context.cacheDir, "madhuri-${System.currentTimeMillis()}.m4a")
        val media = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(context)
        } else {
            @Suppress("DEPRECATION")
            MediaRecorder()
        }
        try {
            // VOICE_RECOGNITION is louder on most phones; MIC is the fallback.
            val source = runCatching {
                media.setAudioSource(MediaRecorder.AudioSource.VOICE_RECOGNITION)
                MediaRecorder.AudioSource.VOICE_RECOGNITION
            }.getOrElse {
                media.setAudioSource(MediaRecorder.AudioSource.MIC)
                MediaRecorder.AudioSource.MIC
            }
            media.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            media.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            media.setAudioChannels(1)
            media.setAudioSamplingRate(44_100)
            media.setAudioEncodingBitRate(96_000)
            media.setOutputFile(file.absolutePath)
            media.prepare()
            media.start()
        } catch (e: Exception) {
            runCatching { media.release() }
            listener?.onError("Could not start recording: ${e.message ?: "unknown"}")
            return
        }

        recorder = media
        output = file
        running = true
        startedAt = System.currentTimeMillis()
        peak = 0f
        spokeAtLeastOnce = false
        silentMs = 0L
        noiseFloor = 0f
        noiseSamples = 0
        noiseSum = 0f

        meterThread = thread(name = "madhuri-meter", isDaemon = true) {
            while (running) {
                val amplitude = runCatching { media.maxAmplitude }.getOrDefault(0)
                // maxAmplitude is 0..32767
                val level = (amplitude / 32767f).coerceIn(0f, 1f)
                if (level > peak) peak = level
                mainHandler.post { listener?.onLevel(level) }

                // Learn the room noise in the first moments, then treat anything
                // clearly above it as speech. A fixed threshold never ends on
                // phones whose idle level sits at 0.05-0.07.
                if (noiseSamples < 5) {
                    noiseSum += level
                    noiseSamples += 1
                    if (noiseSamples == 5) {
                        noiseFloor = noiseSum / 5f
                    }
                }
                val threshold = maxOf(SPEECH_THRESHOLD, noiseFloor * 2.2f)

                if (level > threshold) {
                    spokeAtLeastOnce = true
                    silentMs = 0
                } else if (spokeAtLeastOnce) {
                    silentMs += TICK_MS
                }

                val elapsed = System.currentTimeMillis() - startedAt
                val shouldStop = elapsed >= maxDurationMs ||
                    (spokeAtLeastOnce && elapsed > 700 && silentMs >= silenceMs) ||
                    // Quiet phones never cross the threshold; still send what we have.
                    (!spokeAtLeastOnce && elapsed >= NO_SPEECH_TIMEOUT_MS)
                if (shouldStop) {
                    mainHandler.post { stop() }
                    return@thread
                }
                Thread.sleep(TICK_MS)
            }
        }
    }

    fun stop() {
        if (!running) return
        running = false
        val media = recorder
        recorder = null
        val file = output
        output = null
        val duration = System.currentTimeMillis() - startedAt

        val stopped = runCatching {
            media?.stop()
            media?.release()
            true
        }.getOrDefault(false)
        if (!stopped) {
            runCatching { media?.release() }
            file?.delete()
            listener?.onFinished(null)
            return
        }

        if (file == null || !file.exists() || file.length() < 1_000) {
            file?.delete()
            listener?.onFinished(null)
            return
        }
        val bytes = runCatching { file.readBytes() }.getOrNull()
        if (bytes == null) {
            listener?.onFinished(null)
            return
        }
        listener?.onFinished(
            Recording(
                file = file,
                bytes = bytes,
                mimeType = "audio/mp4",
                durationMs = duration,
                peakLevel = peak
            )
        )
    }

    fun cancel() {
        running = false
        runCatching { recorder?.stop() }
        runCatching { recorder?.release() }
        recorder = null
        output?.delete()
        output = null
    }

    companion object {
        private const val MAX_MS = 30_000L
        private const val TICK_MS = 120L
        private const val SPEECH_THRESHOLD = 0.015f
        private const val NO_SPEECH_TIMEOUT_MS = 5_000L
    }
}
