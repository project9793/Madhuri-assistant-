package com.codemaster.madhuri.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

/**
 * Microphone glyph drawn with the Canvas API. It avoids pulling in the
 * material-icons-extended artifact (a multi-megabyte dependency) just for one
 * icon.
 */
@Composable
fun MicGlyph(
    tint: Color,
    modifier: Modifier = Modifier,
    isListening: Boolean = false
) {
    Canvas(modifier = modifier.size(28.dp)) {
        val width = size.width
        val height = size.height
        val stroke = width * 0.09f
        val capsuleTop = if (isListening) height * 0.06f else height * 0.10f
        val capsuleHeight = if (isListening) height * 0.50f else height * 0.44f

        drawRoundRect(
            color = tint,
            topLeft = Offset(width * 0.36f, capsuleTop),
            size = Size(width * 0.28f, capsuleHeight),
            cornerRadius = CornerRadius(width * 0.14f, width * 0.14f),
            style = Stroke(width = stroke)
        )
        drawArc(
            color = tint,
            startAngle = 0f,
            sweepAngle = 180f,
            useCenter = false,
            topLeft = Offset(width * 0.22f, height * 0.30f),
            size = Size(width * 0.56f, height * 0.42f),
            style = Stroke(width = stroke, cap = StrokeCap.Round)
        )
        drawLine(
            color = tint,
            start = Offset(width * 0.5f, height * 0.72f),
            end = Offset(width * 0.5f, height * 0.88f),
            strokeWidth = stroke,
            cap = StrokeCap.Round
        )
        drawLine(
            color = tint,
            start = Offset(width * 0.34f, height * 0.88f),
            end = Offset(width * 0.66f, height * 0.88f),
            strokeWidth = stroke,
            cap = StrokeCap.Round
        )
    }
}
