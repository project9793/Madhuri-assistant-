package com.codemaster.madhuri.ui.theme

import androidx.compose.ui.graphics.Color

val VioletPrimary = Color(0xFFA78BFA)
val VioletDeep = Color(0xFF7C4DFF)
val CyanSecondary = Color(0xFF3DE1FF)
val PinkTertiary = Color(0xFFFF7AD9)

val NightBackground = Color(0xFF0B0718)
val NightSurface = Color(0xFF150F2B)
val NightSurfaceHigh = Color(0xFF1F1738)
val NightOutline = Color(0xFF3A2E5C)

val DayBackground = Color(0xFFF6F3FF)
val DaySurface = Color(0xFFFFFFFF)
val DaySurfaceHigh = Color(0xFFEDE7FF)
val DayOutline = Color(0xFFD6CCF5)

val ErrorRed = Color(0xFFFF6B81)
val SuccessGreen = Color(0xFF4ADE80)
