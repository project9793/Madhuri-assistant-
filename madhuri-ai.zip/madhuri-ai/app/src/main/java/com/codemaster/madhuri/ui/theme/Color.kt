package com.codemaster.madhuri.ui.theme

import androidx.compose.ui.graphics.Color

// ---- Accents: hot pink on near-black, the "latest" look ----
val AccentPink = Color(0xFFFF2D78)
val AccentPinkDeep = Color(0xFFE01E63)
val AccentPinkSoft = Color(0xFFFF6EA8)
val AccentViolet = Color(0xFFA855F7)
val AccentCyan = Color(0xFF4ED8FF)

val SuccessGreen = Color(0xFF3DDC84)
val WarningAmber = Color(0xFFFFC857)
val ErrorRed = Color(0xFFFF5470)

// ---- Night surfaces: almost black, barely separated ----
val NightBackground = Color(0xFF08070B)
val NightSurface = Color(0xFF121116)
val NightSurfaceHigh = Color(0xFF1A1820)
val NightOutline = Color(0xFF2A2833)
val NightTextSecondary = Color(0xFF9A97A6)

// ---- Day surfaces ----
val DayBackground = Color(0xFFFDF7F9)
val DaySurface = Color(0xFFFFFFFF)
val DaySurfaceHigh = Color(0xFFF7EDF1)
val DayOutline = Color(0xFFEBD3DC)
val DayTextSecondary = Color(0xFF6F6672)

/**
 * Names kept from the first release so the existing components keep compiling;
 * the palette behind them is now the pink-on-black one.
 */
val VioletPrimary = AccentPink
val VioletDeep = AccentPinkDeep
val CyanSecondary = AccentCyan
val PinkTertiary = AccentPinkSoft
