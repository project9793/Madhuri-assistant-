package com.codemaster.madhuri.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

private val base = Typography()

val MadhuriTypography = Typography(
    displaySmall = base.displaySmall.copy(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 0.sp
    ),
    headlineMedium = base.headlineMedium.copy(
        fontWeight = FontWeight.SemiBold
    ),
    headlineSmall = base.headlineSmall.copy(
        fontWeight = FontWeight.SemiBold
    ),
    titleLarge = base.titleLarge.copy(
        fontWeight = FontWeight.SemiBold
    ),
    titleMedium = base.titleMedium.copy(
        fontWeight = FontWeight.Medium
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 24.sp,
        letterSpacing = 0.2.sp
    ),
    bodyMedium = base.bodyMedium.copy(
        fontSize = 14.sp,
        lineHeight = 21.sp
    ),
    labelLarge = base.labelLarge.copy(
        fontWeight = FontWeight.Medium,
        letterSpacing = 0.4.sp
    )
)
