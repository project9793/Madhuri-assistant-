package com.codemaster.madhuri.data

import android.content.Context
import com.codemaster.madhuri.model.MemoryEntry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File

/**
 * Optional personal memory. Every entry is user-visible and user-deletable in
 * Settings; nothing is captured unless memory is switched on.
 */
class MemoryRepository(private val context: Context) {

    private val file: File
        get() = File(context.filesDir, "memory.json")

    suspend fun all(): List<MemoryEntry> = withContext(Dispatchers.IO) { read() }

    suspend fun add(content: String): MemoryEntry = withContext(Dispatchers.IO) {
        val entry = MemoryEntry(content = content.trim())
        val current = read().toMutableList()
        current.add(0, entry)
        write(current)
        entry
    }

    suspend fun delete(id: String) = withContext(Dispatchers.IO) {
        write(read().filterNot { it.id == id })
        Unit
    }

    suspend fun clear() = withContext(Dispatchers.IO) {
        if (file.exists()) file.delete()
        Unit
    }

    /** Used by the settings screen to show how much context is stored. */
    fun sizeBytes(): Long = if (file.exists()) file.length() else 0L

    private fun read(): List<MemoryEntry> {
        if (!file.exists()) return emptyList()
        return runCatching {
            val array = JSONArray(file.readText())
            (0 until array.length()).mapNotNull { index ->
                array.optJSONObject(index)?.let(MemoryEntry::fromJson)
            }
        }.getOrDefault(emptyList())
    }

    private fun write(entries: List<MemoryEntry>) {
        val array = JSONArray()
        entries.forEach { array.put(it.toJson()) }
        file.writeText(array.toString())
    }
}
