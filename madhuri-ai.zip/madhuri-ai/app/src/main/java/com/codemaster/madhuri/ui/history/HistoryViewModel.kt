package com.codemaster.madhuri.ui.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.codemaster.madhuri.AppContainer
import com.codemaster.madhuri.data.ChatRepository
import com.codemaster.madhuri.model.ChatSession
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class HistoryViewModel(private val chatRepository: ChatRepository) : ViewModel() {

    data class UiState(
        val sessions: List<ChatSession> = emptyList(),
        val loading: Boolean = true
    )

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            val sessions = chatRepository.listSessions()
            _uiState.update { it.copy(sessions = sessions, loading = false) }
        }
    }

    fun delete(id: String) {
        viewModelScope.launch {
            chatRepository.delete(id)
            refresh()
        }
    }

    fun clearAll() {
        viewModelScope.launch {
            chatRepository.deleteAll()
            refresh()
        }
    }

    companion object {
        fun factory(container: AppContainer): ViewModelProvider.Factory = viewModelFactory {
            initializer { HistoryViewModel(container.chatRepository) }
        }
    }
}
