package com.codemaster.madhuri.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.codemaster.madhuri.AppContainer
import com.codemaster.madhuri.data.ChatRepository
import com.codemaster.madhuri.data.GeminiClient
import com.codemaster.madhuri.data.MemoryRepository
import com.codemaster.madhuri.data.SettingsRepository
import com.codemaster.madhuri.model.AppSettings
import com.codemaster.madhuri.model.AssistantError
import com.codemaster.madhuri.model.Language
import com.codemaster.madhuri.model.MemoryEntry
import com.codemaster.madhuri.voice.GeminiSpeaker
import com.codemaster.madhuri.voice.SpeechSynthesizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val settingsRepository: SettingsRepository,
    private val memoryRepository: MemoryRepository,
    private val chatRepository: ChatRepository,
    private val geminiClient: GeminiClient,
    private val speechSynthesizer: SpeechSynthesizer,
    private val geminiSpeaker: GeminiSpeaker
) : ViewModel() {

    data class UiState(
        val settings: AppSettings = AppSettings(),
        val keyDraft: String = "",
        val keyStatus: String? = null,
        val testing: Boolean = false,
        val memoryEntries: List<MemoryEntry> = emptyList(),
        val memoryDraft: String = "",
        val memoryNotice: String? = null,
        val error: AssistantError? = null
    )

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            settingsRepository.settings.collect { latest ->
                _uiState.update { current ->
                    current.copy(
                        settings = latest,
                        // Only prefill the field when it has not been touched.
                        keyDraft = if (current.keyDraft.isEmpty()) latest.apiKey else current.keyDraft
                    )
                }
            }
        }
        refreshMemory()
    }

    fun onKeyDraftChange(value: String) {
        _uiState.update { it.copy(keyDraft = value, keyStatus = null) }
    }

    fun saveKey() {
        val draft = _uiState.value.keyDraft.trim()
        if (draft.isEmpty()) {
            _uiState.update { it.copy(keyStatus = "Paste a key first.") }
            return
        }
        viewModelScope.launch {
            settingsRepository.saveApiKey(draft)
            _uiState.update { it.copy(keyStatus = "Key saved on this device.") }
        }
    }

    fun testKey() {
        val draft = _uiState.value.keyDraft.trim().ifBlank { _uiState.value.settings.apiKey }
        if (draft.isEmpty()) {
            _uiState.update { it.copy(keyStatus = "Paste a key first.") }
            return
        }
        _uiState.update { it.copy(testing = true, keyStatus = null) }
        viewModelScope.launch {
            val failure = geminiClient.testKey(draft)
            _uiState.update {
                it.copy(
                    testing = false,
                    keyStatus = if (failure == null) {
                        "Key works — Gemini is reachable."
                    } else {
                        failure.english
                    }
                )
            }
        }
    }

    fun deleteKey() {
        viewModelScope.launch {
            settingsRepository.deleteApiKey()
            _uiState.update { it.copy(keyDraft = "", keyStatus = "Key removed from this device.") }
        }
    }

    fun setModel(model: String) = updateSettings { it.copy(model = model) }

    fun setLanguage(language: Language) = updateSettings { it.copy(languageTag = language.tag) }

    fun setVoiceEnabled(enabled: Boolean) = updateSettings { it.copy(voiceEnabled = enabled) }

    fun setContinuousConversation(enabled: Boolean) =
        updateSettings { it.copy(continuousConversation = enabled) }

    fun setVoiceEngine(engine: String) = updateSettings { it.copy(voiceEngine = engine) }

    fun setMemoryEnabled(enabled: Boolean) = updateSettings { it.copy(memoryEnabled = enabled) }

    fun setPersona(persona: String) = updateSettings { it.copy(persona = persona) }

    fun setSpeechRate(rate: Float) = updateSettings { it.copy(speechRate = rate) }

    fun setThemeMode(mode: String) = updateSettings { it.copy(themeMode = mode) }

    fun testVoice() {
        val settings = _uiState.value.settings
        val sample = "Namaste, main Madhuri hoon. Aap kaise hain?"
        if (settings.speechEngine == AppSettings.SPEECH_GEMINI) {
            viewModelScope.launch {
                val ttsModel = if (settings.model.contains("lite")) {
                    "gemini-3.8-flash-lite-tts"
                } else {
                    "gemini-3.8-flash-tts"
                }
                geminiClient.synthesize(ttsModel, settings.apiKey, sample, settings.voiceName)
                    .onSuccess { audio -> geminiSpeaker.playPcm(audio.pcm, audio.sampleRate) }
                    .onFailure {
                        _uiState.update {
                            it.copy(keyStatus = "Gemini voice unavailable, using the phone voice instead.")
                        }
                        speechSynthesizer.speak(sample, settings.language.speechTag, settings.speechRate)
                    }
            }
        } else {
            speechSynthesizer.speak(sample, settings.language.speechTag, settings.speechRate)
        }
    }

    fun setSpeechEngine(engine: String) = updateSettings { it.copy(speechEngine = engine) }

    fun setVoiceName(name: String) = updateSettings { it.copy(voiceName = name) }

    fun onMemoryDraftChange(value: String) {
        _uiState.update { it.copy(memoryDraft = value) }
    }

    fun addMemory() {
        val content = _uiState.value.memoryDraft.trim()
        if (content.isEmpty()) {
            _uiState.update { it.copy(memoryNotice = "Type a note first") }
            return
        }
        // Show the note straight away, then persist it. If writing to disk
        // fails the row is removed again and the user is told.
        val optimistic = MemoryEntry(content = content)
        _uiState.update {
            it.copy(
                memoryDraft = "",
                memoryEntries = listOf(optimistic) + it.memoryEntries,
                memoryNotice = "Saved to memory"
            )
        }
        viewModelScope.launch {
            runCatching { memoryRepository.add(content) }
                .onFailure { failure ->
                    _uiState.update { state ->
                        state.copy(
                            memoryEntries = state.memoryEntries.filterNot { it.id == optimistic.id },
                            memoryNotice = "Could not save: ${failure.message ?: "storage error"}"
                        )
                    }
                }
        }
    }

    fun dismissMemoryNotice() {
        _uiState.update { it.copy(memoryNotice = null) }
    }

    fun deleteMemory(id: String) {
        _uiState.update { state ->
            state.copy(memoryEntries = state.memoryEntries.filterNot { it.id == id })
        }
        viewModelScope.launch {
            runCatching { memoryRepository.delete(id) }
            refreshMemory()
        }
    }

    fun clearMemory() {
        viewModelScope.launch {
            memoryRepository.clear()
            refreshMemory()
        }
    }

    fun deleteAllChats() {
        viewModelScope.launch { chatRepository.deleteAll() }
    }

    fun deleteEverything() {
        viewModelScope.launch {
            chatRepository.deleteAll()
            memoryRepository.clear()
            settingsRepository.deleteApiKey()
            _uiState.update {
                it.copy(keyDraft = "", keyStatus = "All Madhuri data removed from this device.")
            }
            refreshMemory()
        }
    }

    fun dismissError() {
        _uiState.update { it.copy(error = null) }
    }

    private fun refreshMemory() {
        viewModelScope.launch {
            val entries = memoryRepository.all()
            _uiState.update { it.copy(memoryEntries = entries) }
        }
    }

    private fun updateSettings(transform: (AppSettings) -> AppSettings) {
        viewModelScope.launch { settingsRepository.update(transform) }
    }

    companion object {
        fun factory(container: AppContainer): ViewModelProvider.Factory = viewModelFactory {
            initializer {
                SettingsViewModel(
                    settingsRepository = container.settingsRepository,
                    memoryRepository = container.memoryRepository,
                    chatRepository = container.chatRepository,
                    geminiClient = container.geminiClient,
                    speechSynthesizer = container.speechSynthesizer,
                    geminiSpeaker = container.geminiSpeaker
                )
            }
        }
    }
}
