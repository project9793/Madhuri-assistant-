package com.codemaster.madhuri.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withTimeoutOrNull
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.codemaster.madhuri.AppContainer
import com.codemaster.madhuri.data.ChatRepository
import com.codemaster.madhuri.data.GeminiClient
import com.codemaster.madhuri.data.MemoryRepository
import com.codemaster.madhuri.data.SettingsRepository
import com.codemaster.madhuri.model.AppSettings
import com.codemaster.madhuri.model.AssistantError
import com.codemaster.madhuri.model.Language
import com.codemaster.madhuri.model.MemoryEntry
import com.codemaster.madhuri.voice.GeminiSpeaker
import com.codemaster.madhuri.voice.SpeechSynthesizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val appContext: android.content.Context,
    private val settingsRepository: SettingsRepository,
    private val memoryRepository: MemoryRepository,
    private val chatRepository: ChatRepository,
    private val geminiClient: GeminiClient,
    private val speechSynthesizer: SpeechSynthesizer,
    private val geminiSpeaker: GeminiSpeaker,
    private val openRouterClient: com.codemaster.madhuri.data.OpenRouterClient,
    private val audioRecorder: com.codemaster.madhuri.voice.AudioRecorder,
    private val conversationEngine: com.codemaster.madhuri.data.ConversationEngine
) : ViewModel() {

    data class UiState(
        val settings: AppSettings = AppSettings(),
        val keyDraft: String = "",
        val keyStatus: String? = null,
        val openRouterKeyDraft: String = "",
        val grokKeyDraft: String = "",
        val grokStatus: String? = null,
        val testingGrok: Boolean = false,
        val testLines: List<String> = emptyList(),
        val testRunning: Boolean = false,
        val openRouterStatus: String? = null,
        val testingOpenRouter: Boolean = false,
        val testing: Boolean = false,
        val memoryEntries: List<MemoryEntry> = emptyList(),
        val memoryDraft: String = "",
        val memoryNotice: String? = null,
        val error: AssistantError? = null
    )

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            settingsRepository.settings.collect { latest ->
                _uiState.update { current ->
                    current.copy(
                        settings = latest,
                        // Only prefill the field when it has not been touched.
                        keyDraft = if (current.keyDraft.isEmpty()) latest.apiKey else current.keyDraft,
                    openRouterKeyDraft = if (current.openRouterKeyDraft.isEmpty()) {
                        latest.openRouterKey
                    } else {
                        current.openRouterKeyDraft
                    },
                    grokKeyDraft = if (current.grokKeyDraft.isEmpty()) {
                        latest.grokKey
                    } else {
                        current.grokKeyDraft
                    }
                    )
                }
            }
        }
        refreshMemory()
    }

    fun onKeyDraftChange(value: String) {
        _uiState.update { it.copy(keyDraft = value, keyStatus = null) }
    }

    fun saveKey() {
        val draft = _uiState.value.keyDraft.trim()
        if (draft.isEmpty()) {
            _uiState.update { it.copy(keyStatus = "Paste a key first.") }
            return
        }
        viewModelScope.launch {
            settingsRepository.saveApiKey(draft)
            _uiState.update { it.copy(keyStatus = "Key saved on this device.") }
        }
    }

    fun testKey() {
        val draft = _uiState.value.keyDraft.trim().ifBlank { _uiState.value.settings.apiKey }
        if (draft.isEmpty()) {
            _uiState.update { it.copy(keyStatus = "Paste a key first.") }
            return
        }
        _uiState.update { it.copy(testing = true, keyStatus = null) }
        viewModelScope.launch {
            val failure = geminiClient.testKey(draft)
            _uiState.update {
                it.copy(
                    testing = false,
                    keyStatus = if (failure == null) {
                        "Key works — Gemini is reachable."
                    } else {
                        failure.english
                    }
                )
            }
        }
    }

    fun deleteKey() {
        viewModelScope.launch {
            settingsRepository.deleteApiKey()
            _uiState.update { it.copy(keyDraft = "", keyStatus = "Key removed from this device.") }
        }
    }

    fun setModel(model: String) = updateSettings { it.copy(model = model) }

    fun setLanguage(language: Language) = updateSettings { it.copy(languageTag = language.tag) }

    fun setVoiceEnabled(enabled: Boolean) = updateSettings { it.copy(voiceEnabled = enabled) }

    fun setContinuousConversation(enabled: Boolean) =
        updateSettings { it.copy(continuousConversation = enabled) }

    fun setVoiceEngine(engine: String) = updateSettings { it.copy(voiceEngine = engine) }

    fun setMemoryEnabled(enabled: Boolean) = updateSettings { it.copy(memoryEnabled = enabled) }

    fun setPersona(persona: String) = updateSettings { it.copy(persona = persona) }

    fun setSpeechRate(rate: Float) = updateSettings { it.copy(speechRate = rate) }

    fun setThemeMode(mode: String) = updateSettings { it.copy(themeMode = mode) }

    fun testVoice() {
        val settings = _uiState.value.settings
        val sample = "Namaste, main Madhuri hoon. Aap kaise hain?"
        if (settings.speechEngine == AppSettings.SPEECH_GEMINI) {
            viewModelScope.launch {
                val ttsModel = if (settings.model.contains("lite")) {
                    "gemini-3.8-flash-lite-tts"
                } else {
                    "gemini-3.8-flash-tts"
                }
                geminiClient.synthesize(ttsModel, settings.apiKey, sample, settings.voiceName, settings.language)
                    .onSuccess { audio -> geminiSpeaker.playAudio(audio.data, audio.mimeType) }
                    .onFailure {
                        _uiState.update {
                            it.copy(keyStatus = "Gemini voice unavailable, using the phone voice instead.")
                        }
                        speechSynthesizer.speak(sample, settings.language.speechTag, settings.speechRate)
                    }
            }
        } else {
            speechSynthesizer.speak(sample, settings.language.speechTag, settings.speechRate)
        }
    }

    /**
     * Picks a voice and speaks a one-line sample in it straight away, so the choice
     * is heard before leaving the list.
     */
    fun previewVoice(name: String) {
        val settings = _uiState.value.settings
        val sample = "Namaste, main Madhuri hoon. Aap kaise hain?"
        updateSettings { it.copy(voiceName = name) }
        if (settings.speechEngine == AppSettings.SPEECH_GEMINI) {
            if (settings.apiKey.isBlank()) {
                _uiState.update {
                    it.copy(keyStatus = "Add a Gemini key to hear the Gemini voices — the phone voice is used until then.")
                }
                speechSynthesizer.speak(sample, settings.language.speechTag, settings.speechRate)
                return
            }
            viewModelScope.launch {
                val ttsModel = if (settings.model.contains("lite")) {
                    "gemini-3.8-flash-lite-tts"
                } else {
                    "gemini-3.8-flash-tts"
                }
                geminiClient.synthesize(ttsModel, settings.apiKey, sample, name, settings.language)
                    .onSuccess { audio -> geminiSpeaker.playAudio(audio.data, audio.mimeType) }
                    .onFailure {
                        _uiState.update {
                            it.copy(keyStatus = "Gemini voice unavailable, using the phone voice instead.")
                        }
                        speechSynthesizer.speak(sample, settings.language.speechTag, settings.speechRate)
                    }
            }
        } else {
            speechSynthesizer.speak(sample, settings.language.speechTag, settings.speechRate)
        }
    }

    fun setSpeechEngine(engine: String) = updateSettings { it.copy(speechEngine = engine) }

    fun setThinking(mode: String) = updateSettings { it.copy(thinking = mode) }

    fun setTemperature(value: Float) = updateSettings { it.copy(temperature = value) }

    fun setMaxTokens(value: Int) = updateSettings { it.copy(maxTokens = value) }

    fun setMemoryTurns(value: Int) = updateSettings { it.copy(memoryTurns = value) }

    fun setInterruptEnabled(enabled: Boolean) = updateSettings { it.copy(interruptEnabled = enabled) }

    fun setWebSearchEnabled(enabled: Boolean) = updateSettings { it.copy(webSearchEnabled = enabled) }

    fun setLiveVoice(enabled: Boolean) = updateSettings { it.copy(liveVoice = enabled) }

    fun setChatProvider(provider: String) = updateSettings { it.copy(chatProvider = provider) }

    fun setLiveEngine(engine: String) = updateSettings { it.copy(liveEngine = engine) }

    /** One request per turn: the phone listens and speaks, only the reply costs quota. */
    fun setSaveQuota(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.update {
                if (enabled) {
                    it.copy(
                        saveQuota = true,
                        speechEngine = AppSettings.SPEECH_ANDROID,
                        voiceEngine = AppSettings.ENGINE_ANDROID,
                        liveVoice = false
                    )
                } else {
                    it.copy(
                        saveQuota = false,
                        speechEngine = AppSettings.SPEECH_GEMINI,
                        voiceEngine = AppSettings.ENGINE_GEMINI
                    )
                }
            }
        }
    }

    /**
     * Walks the whole voice loop once and reports every step, so a failure can be
     * seen instead of guessed at.
     */
    fun runVoiceTest() {
        if (_uiState.value.testRunning) return
        _uiState.update { it.copy(testRunning = true, testLines = emptyList()) }

        fun log(line: String) {
            _uiState.update { it.copy(testLines = it.testLines + line) }
        }

        viewModelScope.launch {
            val settings = settingsRepository.current()

            val micOk = androidx.core.content.ContextCompat.checkSelfPermission(
                appContext,
                android.Manifest.permission.RECORD_AUDIO
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
            log(if (micOk) "OK  · microphone permission" else "FAIL · microphone permission — allow it in the Permissions tab")
            if (!micOk) {
                _uiState.update { it.copy(testRunning = false) }
                return@launch
            }

            log("OK  · keys: Gemini " + (if (settings.apiKey.isNotBlank()) "set" else "missing") +
                ", OpenRouter " + (if (settings.openRouterKey.isNotBlank()) "set" else "missing") +
                ", xAI " + (if (settings.grokKey.isNotBlank()) "set" else "missing"))

            // ---- record ----
            val inputs = runCatching {
                val manager = appContext.getSystemService(android.media.AudioManager::class.java)
                manager.getDevices(android.media.AudioManager.GET_DEVICES_INPUTS)
                    .joinToString(", ") { it.productName?.toString() ?: "mic" }
            }.getOrNull()
            if (!inputs.isNullOrBlank()) log("OK  · microphones: $inputs")
            log("…   recording, speak now (stops on silence)")
            val clip = withTimeoutOrNull(15_000) {
                kotlin.coroutines.suspendCoroutine<com.codemaster.madhuri.voice.AudioRecorder.Clip?> { cont ->
                    audioRecorder.listener =
                        object : com.codemaster.madhuri.voice.AudioRecorder.Listener {
                            override fun onLevel(level: Float) = Unit

                            override fun onError(message: String) {
                                audioRecorder.listener = null
                                cont.resumeWith(Result.success(null))
                            }

                            override fun onFinished(clip: com.codemaster.madhuri.voice.AudioRecorder.Clip?) {
                                audioRecorder.listener = null
                                cont.resumeWith(Result.success(clip))
                            }
                        }
                    audioRecorder.start()
                }
            }
            if (clip == null) {
                log("FAIL · recording — nothing captured (mic busy, or blocked by the phone)")
            } else {
                val level = "%.3f".format(clip.peakLevel)
                if (clip.peakLevel < 0.02f) {
                    log("FAIL · recorded ${clip.durationMs / 1000}s but mic level is $level — the phone sent no sound")
                    log("     check: headset/bluetooth connected? another app holding the mic? mic hole covered?")
                } else {
                    log("OK  · recorded ${clip.durationMs / 1000}s, mic level $level")
                }

                // ---- transcribe ----
                if (settings.apiKey.isBlank()) {
                    log("SKIP · transcription — no Gemini key")
                } else {
                    val result = geminiClient.transcribe(
                        "gemini-3.5-flash-lite",
                        settings.apiKey,
                        clip.wavBase64,
                        clip.mimeType
                    )
                    result.onSuccess { text ->
                        log(
                            if (text.isBlank() || text.equals("NONE", true)) {
                                "FAIL · transcription — Gemini heard nothing in the clip"
                            } else {
                                "OK  · transcription: \"${text.take(70)}\""
                            }
                        )
                    }.onFailure { failure ->
                        val detail = (failure as? com.codemaster.madhuri.data.GeminiException)?.detail
                        log("FAIL · transcription — ${detail ?: failure.message}")
                    }
                }
            }

            // ---- reply ----
            val event = withTimeoutOrNull(45_000) {
                conversationEngine.stream(emptyList(), "Say hi to me in one short line.")
                    .firstOrNull { it is com.codemaster.madhuri.data.EngineEvent.Completed || it is com.codemaster.madhuri.data.EngineEvent.Failed }
            }
            when (event) {
                is com.codemaster.madhuri.data.EngineEvent.Completed ->
                    log("OK  · reply: \"${event.text.take(70)}\"")
                is com.codemaster.madhuri.data.EngineEvent.Failed ->
                    log("FAIL · reply — ${event.error.name} ${event.detail ?: ""}".trim())
                null -> log("FAIL · reply — nothing came back in 45 seconds")
                else -> Unit
            }

            // ---- speak ----
            if (settings.speechEngine == AppSettings.SPEECH_GEMINI && settings.apiKey.isNotBlank()) {
                val audio = geminiClient.synthesize(
                    "gemini-3.8-flash-lite-tts",
                    settings.apiKey,
                    "Namaste, main Madhuri hoon.",
                    settings.voiceName,
                    settings.language
                ).getOrNull()
                log(
                    if (audio != null) "OK  · Gemini voice ready (${audio.mimeType})"
                    else "FAIL · Gemini voice — fell back to the phone voice"
                )
            } else {
                log("OK  · using the phone voice (no Gemini quota needed)")
            }

            _uiState.update { it.copy(testRunning = false) }
        }
    }


    fun onGrokKeyChange(value: String) {
        _uiState.update { it.copy(grokKeyDraft = value) }
    }

    fun setGrokModel(model: String) {
        viewModelScope.launch { settingsRepository.update { it.copy(grokModel = model.trim()) } }
    }

    fun setGrokVoice(voice: String) {
        viewModelScope.launch { settingsRepository.update { it.copy(grokVoice = voice.trim()) } }
    }

    fun saveGrokKey() {
        val draft = _uiState.value.grokKeyDraft.trim()
        if (draft.isEmpty()) {
            _uiState.update { it.copy(grokStatus = "Paste a key first") }
            return
        }
        viewModelScope.launch {
            settingsRepository.update { it.copy(grokKey = draft) }
            _uiState.update { it.copy(grokStatus = "Key saved") }
        }
    }

    fun deleteGrokKey() {
        viewModelScope.launch {
            settingsRepository.update { it.copy(grokKey = "") }
            _uiState.update { it.copy(grokKeyDraft = "", grokStatus = "Key removed") }
        }
    }

    fun testGrokKey() {
        val draft = _uiState.value.grokKeyDraft.trim().ifBlank { _uiState.value.settings.grokKey }
        if (draft.isEmpty()) {
            _uiState.update { it.copy(grokStatus = "Paste a key first") }
            return
        }
        _uiState.update { it.copy(testingGrok = true, grokStatus = null) }
        viewModelScope.launch {
            val isGroq = com.codemaster.madhuri.data.GroqClient.isGroqKey(draft)
            if (isGroq) {
                val models = com.codemaster.madhuri.data.GroqClient.listChatModels(draft)
                if (models.isEmpty()) {
                    _uiState.update {
                        it.copy(testingGrok = false, grokStatus = "Groq rejected that key.")
                    }
                    return@launch
                }
                val best = com.codemaster.madhuri.data.GroqClient.resolveChatModel(draft, null)
                settingsRepository.update { it.copy(grokModel = "") }
                _uiState.update {
                    it.copy(
                        testingGrok = false,
                        grokStatus = "Groq key works. Chat models: " +
                            models.take(3).joinToString(", ") +
                            " — using $best"
                    )
                }
                return@launch
            }
            val ok = xaiKeyWorks(draft)
            _uiState.update {
                it.copy(
                    testingGrok = false,
                    grokStatus = if (ok) {
                        "Key works — Grok voice is ready."
                    } else {
                        "xAI rejected that key, or there is no credit on it."
                    }
                )
            }
        }
    }

    private suspend fun xaiKeyWorks(apiKey: String): Boolean =
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            var connection: java.net.HttpURLConnection? = null
            try {
                connection = (java.net.URL("https://api.x.ai/v1/models")
                    .openConnection() as java.net.HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 15_000
                    readTimeout = 20_000
                    setRequestProperty("Authorization", "Bearer $apiKey")
                }
                connection.responseCode in 200..299
            } catch (e: Exception) {
                false
            } finally {
                connection?.disconnect()
            }
        }

    fun onOpenRouterKeyChange(value: String) {
        _uiState.update { it.copy(openRouterKeyDraft = value) }
    }

    fun setOpenRouterModel(model: String) {
        viewModelScope.launch {
            settingsRepository.update { it.copy(openRouterModel = model.trim()) }
            _uiState.update { it.copy(openRouterStatus = "Model saved") }
        }
    }

    fun saveOpenRouterKey() {
        val draft = _uiState.value.openRouterKeyDraft.trim()
        if (draft.isEmpty()) {
            _uiState.update { it.copy(openRouterStatus = "Paste a key first") }
            return
        }
        viewModelScope.launch {
            settingsRepository.update { it.copy(openRouterKey = draft) }
            _uiState.update { it.copy(openRouterStatus = "Key saved") }
        }
    }

    fun deleteOpenRouterKey() {
        viewModelScope.launch {
            settingsRepository.update { it.copy(openRouterKey = "") }
            _uiState.update { it.copy(openRouterKeyDraft = "", openRouterStatus = "Key removed") }
        }
    }

    fun testOpenRouterKey() {
        val draft = _uiState.value.openRouterKeyDraft.trim()
            .ifBlank { _uiState.value.settings.openRouterKey }
        if (draft.isEmpty()) {
            _uiState.update { it.copy(openRouterStatus = "Paste a key first") }
            return
        }
        _uiState.update { it.copy(testingOpenRouter = true, openRouterStatus = null) }
        viewModelScope.launch {
            val count = openRouterClient.testKey(draft)
            _uiState.update {
                it.copy(
                    testingOpenRouter = false,
                    openRouterStatus = if (count == null) {
                        "That key was rejected by OpenRouter."
                    } else {
                        "Key works — $count models available."
                    }
                )
            }
        }
    }

    fun setEndOfSpeechSensitivity(mode: String) =
        updateSettings { it.copy(endOfSpeechSensitivity = mode) }

    /** Puts every preference back to its default, keeping the API key and profile. */
    fun resetToDefaults() {
        viewModelScope.launch {
            val current = settingsRepository.current()
            settingsRepository.update {
                AppSettings(
                    apiKey = current.apiKey,
                    userName = current.userName,
                    userEmail = current.userEmail,
                    avatarPath = current.avatarPath
                )
            }
            _uiState.update { it.copy(keyStatus = "Settings reset to defaults") }
        }
    }

    fun setUserName(name: String) = updateSettings { it.copy(userName = name.trim()) }

    fun setUserEmail(email: String) = updateSettings { it.copy(userEmail = email.trim()) }

    /** Copies the picked image into app storage so the avatar survives restarts. */
    fun setAvatarFromUri(uri: android.net.Uri) {
        val context = appContext
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val target = java.io.File(context.filesDir, "profile_avatar.jpg")
            val saved = runCatching {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    target.outputStream().use { output -> input.copyTo(output) }
                }
                target.exists()
            }.getOrDefault(false)
            if (saved) {
                settingsRepository.update { it.copy(avatarPath = target.absolutePath) }
            }
        }
    }

    fun setVoiceName(name: String) = updateSettings { it.copy(voiceName = name) }

    fun onMemoryDraftChange(value: String) {
        _uiState.update { it.copy(memoryDraft = value) }
    }

    fun addMemory() {
        val content = _uiState.value.memoryDraft.trim()
        if (content.isEmpty()) {
            _uiState.update { it.copy(memoryNotice = "Type a note first") }
            return
        }
        // Show the note straight away, then persist it. If writing to disk
        // fails the row is removed again and the user is told.
        val optimistic = MemoryEntry(content = content)
        _uiState.update {
            it.copy(
                memoryDraft = "",
                memoryEntries = listOf(optimistic) + it.memoryEntries,
                memoryNotice = "Saved to memory"
            )
        }
        viewModelScope.launch {
            runCatching { memoryRepository.add(content) }
                .onFailure { failure ->
                    _uiState.update { state ->
                        state.copy(
                            memoryEntries = state.memoryEntries.filterNot { it.id == optimistic.id },
                            memoryNotice = "Could not save: ${failure.message ?: "storage error"}"
                        )
                    }
                }
        }
    }

    fun dismissMemoryNotice() {
        _uiState.update { it.copy(memoryNotice = null) }
    }

    fun deleteMemory(id: String) {
        _uiState.update { state ->
            state.copy(memoryEntries = state.memoryEntries.filterNot { it.id == id })
        }
        viewModelScope.launch {
            runCatching { memoryRepository.delete(id) }
            refreshMemory()
        }
    }

    fun clearMemory() {
        viewModelScope.launch {
            memoryRepository.clear()
            refreshMemory()
        }
    }

    fun deleteAllChats() {
        viewModelScope.launch { chatRepository.deleteAll() }
    }

    fun deleteEverything() {
        viewModelScope.launch {
            chatRepository.deleteAll()
            memoryRepository.clear()
            settingsRepository.deleteApiKey()
            _uiState.update {
                it.copy(keyDraft = "", keyStatus = "All Madhuri data removed from this device.")
            }
            refreshMemory()
        }
    }

    fun dismissError() {
        _uiState.update { it.copy(error = null) }
    }

    private fun refreshMemory() {
        viewModelScope.launch {
            val entries = memoryRepository.all()
            _uiState.update { it.copy(memoryEntries = entries) }
        }
    }

    private fun updateSettings(transform: (AppSettings) -> AppSettings) {
        viewModelScope.launch { settingsRepository.update(transform) }
    }

    companion object {
        fun factory(container: AppContainer): ViewModelProvider.Factory = viewModelFactory {
            initializer {
                SettingsViewModel(
                    appContext = container.appContext,
                    settingsRepository = container.settingsRepository,
                    memoryRepository = container.memoryRepository,
                    chatRepository = container.chatRepository,
                    geminiClient = container.geminiClient,
                    speechSynthesizer = container.speechSynthesizer,
                    geminiSpeaker = container.geminiSpeaker,
                    openRouterClient = container.openRouterClient,
                    audioRecorder = container.audioRecorder,
                    conversationEngine = container.conversationEngine
                )
            }
        }
    }
}
