package com.codemaster.madhuri.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.codemaster.madhuri.model.AppSettings
import com.codemaster.madhuri.ui.theme.PinkTertiary
import com.codemaster.madhuri.ui.theme.VioletPrimary

/**
 * Full-height "Choose Voice" sheet: every prebuilt Gemini voice in one list, the
 * one in use marked with a star, and a one-line preview the moment a voice is tapped.
 */
@Composable
internal fun ChooseVoiceDialog(
    currentVoice: String,
    speechEngine: String,
    onEngineChange: (String) -> Unit,
    onPick: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    val voices = remember(query) {
        val needle = query.trim()
        if (needle.isEmpty()) {
            AppSettings.VOICES
        } else {
            AppSettings.VOICES.filter { it.contains(needle, ignoreCase = true) }
        }
    }
    val sheetColor = Color(0xFF14121B)
    val muted = Color(0xFF9A94AD)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.88f),
            shape = RoundedCornerShape(28.dp),
            color = sheetColor
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 18.dp, end = 12.dp, top = 20.dp, bottom = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(RoundedCornerShape(15.dp))
                            .background(PinkTertiary.copy(alpha = 0.16f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("\uD83C\uDFA4", fontSize = 20.sp)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Choose Voice",
                            color = Color.White,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Select Madhuri's speaking voice",
                            color = muted,
                            fontSize = 13.sp
                        )
                    }
                }

                Row(
                    modifier = Modifier.padding(horizontal = 18.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    EngineChip(
                        label = "Gemini natural",
                        selected = speechEngine == AppSettings.SPEECH_GEMINI
                    ) { onEngineChange(AppSettings.SPEECH_GEMINI) }
                    EngineChip(
                        label = "Phone voice",
                        selected = speechEngine == AppSettings.SPEECH_ANDROID
                    ) { onEngineChange(AppSettings.SPEECH_ANDROID) }
                }

                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 18.dp, end = 18.dp, top = 12.dp),
                    singleLine = true,
                    label = { Text("Search voices", fontSize = 13.sp) },
                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = 14.sp)
                )

                HorizontalDivider(
                    modifier = Modifier.padding(top = 12.dp),
                    color = Color.White.copy(alpha = 0.08f)
                )

                LazyColumn(modifier = Modifier.weight(1f)) {
                    items(voices) { voice ->
                        val selected = voice == currentVoice
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onPick(voice) }
                                .padding(horizontal = 18.dp, vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(13.dp))
                                    .background(
                                        if (selected) PinkTertiary.copy(alpha = 0.22f)
                                        else Color.White.copy(alpha = 0.06f)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("\uD83C\uDFA4", fontSize = 16.sp)
                            }
                            Spacer(Modifier.width(14.dp))
                            Text(
                                text = voice,
                                color = if (selected) PinkTertiary else Color.White,
                                fontSize = 17.sp,
                                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            if (selected) {
                                Box(
                                    modifier = Modifier
                                        .size(22.dp)
                                        .clip(CircleShape)
                                        .background(PinkTertiary),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("\u2605", color = Color.White, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                    if (voices.isEmpty()) {
                        item {
                            Text(
                                text = "No voice matches \"" + query + "\"",
                                color = muted,
                                fontSize = 14.sp,
                                modifier = Modifier.padding(horizontal = 18.dp, vertical = 24.dp)
                            )
                        }
                    }
                }

                HorizontalDivider(color = Color.White.copy(alpha = 0.08f))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = currentVoice,
                        color = PinkTertiary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = { onPick(currentVoice) }) { Text("Preview") }
                    TextButton(onClick = onDismiss) { Text("Done") }
                }
            }
        }
    }
}

@Composable
private fun EngineChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) VioletPrimary.copy(alpha = 0.22f) else Color.Transparent)
            .border(
                width = 1.dp,
                color = if (selected) VioletPrimary else Color.White.copy(alpha = 0.16f),
                shape = RoundedCornerShape(50)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            color = if (selected) Color.White else Color(0xFFB9B3C7),
            fontSize = 12.sp
        )
    }
}
