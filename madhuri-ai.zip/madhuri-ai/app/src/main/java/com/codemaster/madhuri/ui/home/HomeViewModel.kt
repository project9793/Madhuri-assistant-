package com.codemaster.madhuri.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.codemaster.madhuri.AppContainer
import com.codemaster.madhuri.actions.DeviceActionHandler
import com.codemaster.madhuri.data.ChatRepository
import com.codemaster.madhuri.data.ConversationEngine
import com.codemaster.madhuri.data.EngineEvent
import com.codemaster.madhuri.data.SettingsRepository
import com.codemaster.madhuri.model.AppSettings
import com.codemaster.madhuri.model.AssistantError
import com.codemaster.madhuri.model.ChatMessage
import com.codemaster.madhuri.model.ChatSession
import com.codemaster.madhuri.model.DeviceAction
import com.codemaster.madhuri.model.Language
import com.codemaster.madhuri.model.VoiceState
import com.codemaster.madhuri.voice.SpeechRecognizerManager
import com.codemaster.madhuri.voice.SpeechSynthesizer
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * Drives the voice loop: listen → send → stream → speak → (optionally) listen again.
 * Every state the orb renders comes from here.
 */
class HomeViewModel(
    private val settingsRepository: SettingsRepository,
    private val chatRepository: ChatRepository,
    private val conversationEngine: ConversationEngine,
    private val speechRecognizer: SpeechRecognizerManager,
    private val speechSynthesizer: SpeechSynthesizer,
    private val deviceActions: DeviceActionHandler
) : ViewModel() {

    data class UiState(
        val voiceState: VoiceState = VoiceState.IDLE,
        val statusLine: String = "Tap the orb and talk to me",
        val partialTranscript: String = "",
        val conversation: List<ChatMessage> = emptyList(),
        val streamingReply: String = "",
        val pendingAction: DeviceAction? = null,
        val error: AssistantError? = null,
        val errorDetail: String? = null,
        val notice: String? = null,
        val language: Language = Language.AUTO,
        val hasApiKey: Boolean = false,
        val continuous: Boolean = false,
        val micAvailable: Boolean = true,
        val autoFallbackPending: Boolean = false,
        val isStreaming: Boolean = false
    )

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    private var settings = AppSettings()
    private var session: ChatSession? = null
    private var replyJob: Job? = null
    private var lastSpokenReply: String = ""

    private val recognitionListener = object : SpeechRecognizerManager.Listener {
        override fun onListeningStarted() {
            _uiState.update {
                it.copy(voiceState = VoiceState.LISTENING, statusLine = "Listening…")
            }
        }

        override fun onPartialResult(text: String) {
            _uiState.update { it.copy(partialTranscript = text) }
        }

        override fun onFinalResult(text: String) {
            _uiState.update { it.copy(partialTranscript = "") }
            send(text)
        }

        override fun onFinished() = Unit

        override fun onFailure(error: AssistantError, detail: String?) {
            speechRecognizer.reset()
            val trySystemDialog = error == AssistantError.UNKNOWN ||
                error == AssistantError.SPEECH_UNAVAILABLE
            _uiState.update {
                it.copy(
                    voiceState = VoiceState.ERROR,
                    statusLine = shortStatus(error),
                    error = error,
                    errorDetail = detail,
                    autoFallbackPending = trySystemDialog,
                    partialTranscript = ""
                )
            }
        }
    }

    init {
        speechRecognizer.listener = recognitionListener
        speechSynthesizer.onDone = { handleSpeechFinished() }
        speechSynthesizer.onError = { error ->
            _uiState.update { it.copy(voiceState = VoiceState.IDLE, error = error) }
        }
        speechSynthesizer.onLanguageFallback = { requested, used ->
            _uiState.update {
                it.copy(notice = "No $requested voice installed — speaking in $used instead.")
            }
        }
        _uiState.update { it.copy(micAvailable = speechRecognizer.isAvailable()) }

        viewModelScope.launch {
            settingsRepository.settings.collect { latest ->
                settings = latest
                _uiState.update {
                    it.copy(
                        language = latest.language,
                        hasApiKey = latest.apiKey.isNotBlank(),
                        continuous = latest.continuousConversation
                    )
                }
            }
        }
    }

    fun startListening() {
        if (!_uiState.value.hasApiKey) {
            _uiState.update { it.copy(error = AssistantError.MISSING_API_KEY) }
            return
        }
        if (!speechRecognizer.isAvailable()) {
            _uiState.update {
                it.copy(voiceState = VoiceState.ERROR, error = AssistantError.SPEECH_UNAVAILABLE)
            }
            return
        }
        speechSynthesizer.stop()
        _uiState.update {
            it.copy(
                voiceState = VoiceState.LISTENING,
                statusLine = "Listening…",
                partialTranscript = "",
                error = null
            )
        }
        speechRecognizer.start(settings.language.speechTag)
    }

    fun stopListening() {
        speechRecognizer.stop()
    }

    fun stopSpeaking() {
        speechSynthesizer.stop()
        _uiState.update {
            it.copy(voiceState = VoiceState.INTERRUPTED, statusLine = "Stopped. Tap to talk again.")
        }
    }

    fun repeatLastReply() {
        if (lastSpokenReply.isNotBlank()) {
            speak(lastSpokenReply)
        }
    }

    /** Text that came back from the system speech-recognition dialog. */
    fun submitVoiceText(text: String) {
        if (text.isBlank()) return
        speechRecognizer.cancel()
        send(text)
    }

    private fun shortStatus(error: AssistantError): String = when (error) {
        AssistantError.NO_SPEECH -> "I didn't hear that"
        AssistantError.MIC_PERMISSION -> "Microphone permission needed"
        AssistantError.SPEECH_UNAVAILABLE -> "Voice input is not available"
        AssistantError.NETWORK -> "Network problem while listening"
        AssistantError.TTS_UNAVAILABLE -> "Voice output is not available"
        else -> "Tap the orb to try again"
    }

    fun sendTypedMessage(text: String) {
        if (text.isBlank()) return
        speechRecognizer.cancel()
        send(text)
    }

    fun attachImageAndAsk(base64: String, mimeType: String, question: String) {
        send(question.ifBlank { "What is in this image?" }, base64, mimeType)
    }

    fun confirmPendingAction() {
        val action = _uiState.value.pendingAction ?: return
        _uiState.update { it.copy(pendingAction = null) }
        val outcome = deviceActions.execute(action)
        appendSystemNote(outcome.message)
    }

    fun dismissPendingAction() {
        _uiState.update { it.copy(pendingAction = null) }
        appendSystemNote("Okay, I won't do that.")
    }

    fun dismissError() {
        _uiState.update { it.copy(error = null, errorDetail = null) }
    }

    /** The UI has launched the system recogniser; clear the one-shot flag. */
    fun consumeAutoFallback() {
        _uiState.update { it.copy(autoFallbackPending = false) }
    }

    /** Called when the user declines (or permanently blocks) the microphone. */
    fun reportMicPermissionDenied() {
        _uiState.update {
            it.copy(
                voiceState = VoiceState.ERROR,
                statusLine = "Microphone permission needed",
                error = AssistantError.MIC_PERMISSION
            )
        }
    }

    fun dismissNotice() {
        _uiState.update { it.copy(notice = null) }
    }

    fun startNewConversation() {
        replyJob?.cancel()
        session = null
        lastSpokenReply = ""
        _uiState.update {
            it.copy(
                conversation = emptyList(),
                streamingReply = "",
                voiceState = VoiceState.IDLE,
                statusLine = "Tap the orb and talk to me",
                isStreaming = false
            )
        }
    }

    private fun send(text: String, imageBase64: String? = null, imageMimeType: String? = null) {
        val currentSession = session ?: ChatSession(
            title = text.take(40).ifBlank { "Voice chat" }
        )
        val history = currentSession.messages
        val userMessage = ChatMessage(
            role = ChatMessage.Role.USER,
            text = text,
            imageBase64 = imageBase64,
            imageMimeType = imageMimeType
        )
        val updated = currentSession.copy(
            messages = history + userMessage,
            updatedAt = System.currentTimeMillis()
        )
        session = updated

        _uiState.update {
            it.copy(
                conversation = updated.messages,
                streamingReply = "",
                voiceState = VoiceState.PROCESSING,
                statusLine = "Thinking…",
                partialTranscript = "",
                error = null,
                isStreaming = true
            )
        }

        replyJob = viewModelScope.launch {
            val builder = StringBuilder()
            conversationEngine
                .stream(history, text, imageBase64, imageMimeType)
                .collect { event ->
                    when (event) {
                        is EngineEvent.Token -> {
                            builder.append(event.text)
                            _uiState.update { it.copy(streamingReply = builder.toString()) }
                        }

                        is EngineEvent.Failed -> {
                            _uiState.update {
                                it.copy(
                                    voiceState = VoiceState.ERROR,
                                    statusLine = "Something went wrong",
                                    error = event.error,
                                    errorDetail = event.detail,
                                    isStreaming = false
                                )
                            }
                        }

                        is EngineEvent.Completed -> finishReply(event, builder.toString())
                    }
                }
        }
    }

    private suspend fun finishReply(event: EngineEvent.Completed, streamed: String) {
        val replyText = event.text.ifBlank { streamed }.trim().ifBlank { "Done." }
        val currentSession = session ?: return
        val assistantMessage = ChatMessage(role = ChatMessage.Role.ASSISTANT, text = replyText)
        val updated = currentSession.copy(
            messages = currentSession.messages + assistantMessage,
            updatedAt = System.currentTimeMillis()
        )
        session = updated
        chatRepository.save(updated)

        _uiState.update {
            it.copy(
                conversation = updated.messages,
                streamingReply = "",
                isStreaming = false,
                statusLine = "Your turn"
            )
        }

        val action = event.actions.firstOrNull()
        if (action != null) {
            if (deviceActions.requiresConfirmation(action)) {
                _uiState.update { it.copy(pendingAction = action) }
            } else {
                val outcome = deviceActions.execute(action)
                appendSystemNote(outcome.message)
            }
        }

        speak(replyText)
    }

    private fun speak(text: String) {
        lastSpokenReply = text
        if (!settings.voiceEnabled) {
            _uiState.update { it.copy(voiceState = VoiceState.IDLE, statusLine = "Your turn") }
            return
        }
        _uiState.update {
            it.copy(voiceState = VoiceState.SPEAKING, statusLine = "Speaking…")
        }
        speechSynthesizer.speak(text, settings.language.speechTag, settings.speechRate)
    }

    private fun handleSpeechFinished() {
        if (_uiState.value.voiceState != VoiceState.SPEAKING) return
        _uiState.update {
            it.copy(
                voiceState = VoiceState.IDLE,
                statusLine = if (settings.continuousConversation) "Listening again…" else "Tap the orb to talk again"
            )
        }
        if (settings.continuousConversation && _uiState.value.pendingAction == null) {
            startListening()
        }
    }

    private fun appendSystemNote(message: String) {
        val currentSession = session ?: return
        val note = ChatMessage(role = ChatMessage.Role.ASSISTANT, text = message)
        val updated = currentSession.copy(
            messages = currentSession.messages + note,
            updatedAt = System.currentTimeMillis()
        )
        session = updated
        _uiState.update { it.copy(conversation = updated.messages) }
        viewModelScope.launch { chatRepository.save(updated) }
    }

    override fun onCleared() {
        replyJob?.cancel()
        speechRecognizer.listener = null
        speechSynthesizer.onDone = null
        speechSynthesizer.onError = null
        speechSynthesizer.onLanguageFallback = null
        super.onCleared()
    }

    companion object {
        fun factory(container: AppContainer): ViewModelProvider.Factory = viewModelFactory {
            initializer {
                HomeViewModel(
                    settingsRepository = container.settingsRepository,
                    chatRepository = container.chatRepository,
                    conversationEngine = container.conversationEngine,
                    speechRecognizer = container.speechRecognizer,
                    speechSynthesizer = container.speechSynthesizer,
                    deviceActions = container.deviceActions
                )
            }
        }
    }
}
