package com.codemaster.madhuri.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.codemaster.madhuri.AppContainer
import com.codemaster.madhuri.actions.DeviceActionHandler
import com.codemaster.madhuri.data.ChatRepository
import com.codemaster.madhuri.data.ConversationEngine
import com.codemaster.madhuri.data.GeminiClient
import com.codemaster.madhuri.data.GeminiException
import com.codemaster.madhuri.data.EngineEvent
import com.codemaster.madhuri.data.MemoryRepository
import com.codemaster.madhuri.data.PromptBuilder
import com.codemaster.madhuri.data.SettingsRepository
import com.codemaster.madhuri.data.WeatherInfo
import com.codemaster.madhuri.data.WeatherRepository
import com.codemaster.madhuri.util.LocationHelper
import com.codemaster.madhuri.model.AppSettings
import com.codemaster.madhuri.model.AssistantError
import com.codemaster.madhuri.model.ChatMessage
import com.codemaster.madhuri.model.ChatSession
import com.codemaster.madhuri.model.DeviceAction
import com.codemaster.madhuri.model.Language
import com.codemaster.madhuri.model.VoiceState
import com.codemaster.madhuri.live.GrokLiveSession
import com.codemaster.madhuri.live.LiveVoiceSession
import com.codemaster.madhuri.voice.AudioRecorder
import com.codemaster.madhuri.voice.GeminiSpeaker
import com.codemaster.madhuri.voice.SpeechRecognizerManager
import com.codemaster.madhuri.voice.SpeechSynthesizer
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * Drives the voice loop: listen → send → stream → speak → (optionally) listen again.
 * Every state the orb renders comes from here.
 */
class HomeViewModel(
    private val settingsRepository: SettingsRepository,
    private val chatRepository: ChatRepository,
    private val conversationEngine: ConversationEngine,
    private val speechRecognizer: SpeechRecognizerManager,
    private val speechSynthesizer: SpeechSynthesizer,
    private val deviceActions: DeviceActionHandler,
    private val audioRecorder: AudioRecorder,
    private val geminiClient: GeminiClient,
    private val geminiSpeaker: GeminiSpeaker,
    private val appContext: android.content.Context,
    private val liveSession: LiveVoiceSession,
    private val grokSession: GrokLiveSession,
    private val memoryRepository: MemoryRepository
) : ViewModel() {

    data class UiState(
        val voiceState: VoiceState = VoiceState.IDLE,
        val statusLine: String = "Tap the orb and talk to me",
        val partialTranscript: String = "",
        val conversation: List<ChatMessage> = emptyList(),
        val streamingReply: String = "",
        val pendingAction: DeviceAction? = null,
        val error: AssistantError? = null,
        val errorDetail: String? = null,
        val notice: String? = null,
        val language: Language = Language.AUTO,
        val hasApiKey: Boolean = false,
        val continuous: Boolean = false,
        val micAvailable: Boolean = true,
        val autoFallbackPending: Boolean = false,
        val voiceEngine: String = AppSettings.ENGINE_GEMINI,
        val userName: String = "",
        val interruptEnabled: Boolean = true,
        val micLevel: Float = 0f,
        val weather: WeatherInfo? = null,
        val weatherLoading: Boolean = false,
        val locationAllowed: Boolean = false,
        val timeZoneLabel: String = "",
        val isStreaming: Boolean = false
    )

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    private var settings = AppSettings()
    private var session: ChatSession? = null
    private var replyJob: Job? = null
    private var lastSpokenReply: String = ""

    private val recognitionListener = object : SpeechRecognizerManager.Listener {
        override fun onListeningStarted() {
            _uiState.update {
                it.copy(voiceState = VoiceState.LISTENING, statusLine = "Listening…")
            }
        }

        override fun onPartialResult(text: String) {
            _uiState.update { it.copy(partialTranscript = text) }
        }

        override fun onFinalResult(text: String) {
            _uiState.update { it.copy(partialTranscript = "") }
            send(text)
        }

        override fun onFinished() = Unit

        override fun onFailure(error: AssistantError, detail: String?) {
            speechRecognizer.reset()
            val trySystemDialog = error == AssistantError.UNKNOWN ||
                error == AssistantError.SPEECH_UNAVAILABLE
            _uiState.update {
                it.copy(
                    voiceState = VoiceState.ERROR,
                    statusLine = shortStatus(error),
                    error = error,
                    errorDetail = detail,
                    autoFallbackPending = trySystemDialog,
                    partialTranscript = ""
                )
            }
        }
    }

    private val recordingListener = object : AudioRecorder.Listener {
        override fun onLevel(level: Float) {
            _uiState.update { it.copy(micLevel = level) }
        }

        override fun onError(message: String) {
            _uiState.update {
                it.copy(
                    voiceState = VoiceState.ERROR,
                    statusLine = "Microphone problem",
                    error = AssistantError.MIC_PERMISSION,
                    errorDetail = message
                )
            }
        }

        override fun onFinished(clip: AudioRecorder.Clip?) {
            val state = _uiState.value.voiceState
            if (state != VoiceState.LISTENING && state != VoiceState.PROCESSING) return
            if (clip == null) {
                _uiState.update {
                    it.copy(
                        voiceState = VoiceState.IDLE,
                        statusLine = "I didn't hear that",
                        error = AssistantError.NO_SPEECH,
                        errorDetail = "the recording was under 0.3 s — hold the orb, speak, then tap stop"
                    )
                }
                return
            }
            transcribeClip(clip)
        }
    }

    private val liveListener = object : LiveVoiceSession.Listener {
        override fun onReady() {
            _uiState.update {
                it.copy(
                    voiceState = VoiceState.LISTENING,
                    statusLine = "Live — just talk",
                    error = null,
                    errorDetail = null
                )
            }
        }

        override fun onUserTranscript(text: String) {
            _uiState.update { it.copy(partialTranscript = text, voiceState = VoiceState.LISTENING) }
        }

        override fun onModelTranscript(text: String) {
            _uiState.update { state ->
                state.copy(
                    streamingReply = state.streamingReply + text,
                    voiceState = VoiceState.SPEAKING,
                    statusLine = "Speaking… (live)"
                )
            }
        }

        override fun onTurnComplete() = finaliseLiveTurn()

        override fun onInterrupted() {
            _uiState.update {
                it.copy(
                    streamingReply = "",
                    voiceState = VoiceState.LISTENING,
                    statusLine = "Live — just talk"
                )
            }
        }

        override fun onClosed(reason: String?) {
            _uiState.update {
                it.copy(
                    voiceState = VoiceState.IDLE,
                    statusLine = "Live ended. Tap the orb to start again."
                )
            }
        }

        override fun onError(message: String) {
            _uiState.update {
                it.copy(
                    voiceState = VoiceState.ERROR,
                    statusLine = "Live stopped",
                    error = AssistantError.NETWORK,
                    errorDetail = "live: $message"
                )
            }
        }
    }

    init {
        liveSession.listener = liveListener
        grokSession.listener = liveListener
        _uiState.update { it.copy(timeZoneLabel = java.util.TimeZone.getDefault().id) }
        refreshWeather()
        speechRecognizer.listener = recognitionListener
        audioRecorder.listener = recordingListener
        geminiSpeaker.onDone = { handleSpeechFinished() }
        geminiSpeaker.onError = { message ->
            _uiState.update {
                it.copy(voiceState = VoiceState.IDLE, errorDetail = "voice playback: $message")
            }
        }
        speechSynthesizer.onDone = { handleSpeechFinished() }
        speechSynthesizer.onError = { error ->
            _uiState.update { it.copy(voiceState = VoiceState.IDLE, error = error) }
        }
        speechSynthesizer.onLanguageMissing = { requested ->
            _uiState.update {
                it.copy(
                    voiceState = VoiceState.IDLE,
                    statusLine = "Read the reply above",
                    notice = "Your phone has no voice for $requested, so I kept quiet instead of " +
                        "reading it badly. Switch to Gemini voice in Settings → Voice."
                )
            }
        }
        speechSynthesizer.onLanguageFallback = { requested, used ->
            _uiState.update {
                it.copy(notice = "No $requested voice installed — speaking in $used instead.")
            }
        }
        _uiState.update { it.copy(micAvailable = speechRecognizer.isAvailable()) }

        viewModelScope.launch {
            settingsRepository.settings.collect { latest ->
                settings = latest
                audioRecorder.silenceMs = AppSettings.silenceMs(latest.endOfSpeechSensitivity)
                _uiState.update {
                    it.copy(
                        language = latest.language,
                        hasApiKey = latest.apiKey.isNotBlank(),
                        continuous = latest.continuousConversation,
                        voiceEngine = latest.voiceEngine,
                        userName = latest.userName,
                        interruptEnabled = latest.interruptEnabled
                    )
                }
            }
        }
    }

    fun startListening() {
        if (!_uiState.value.hasApiKey) {
            _uiState.update { it.copy(error = AssistantError.MISSING_API_KEY) }
            return
        }
        // "Let me interrupt": talking over Madhuri stops her and starts listening.
        if (_uiState.value.voiceState == VoiceState.SPEAKING) {
            speechSynthesizer.stop()
            geminiSpeaker.stop()
        }
        speechSynthesizer.stop()
        if (settings.voiceEngine == AppSettings.ENGINE_GEMINI) {
            startRecording()
        } else {
            startPhoneRecognition()
        }
    }

    fun stopListening() {
        if (liveSession.isRunning || grokSession.isRunning) {
            liveSession.stop()
            grokSession.stop()
            _uiState.update {
                it.copy(
                    voiceState = VoiceState.IDLE,
                    statusLine = "Live ended. Tap the orb to start again.",
                    partialTranscript = "",
                    streamingReply = ""
                )
            }
            return
        }
        if (settings.voiceEngine == AppSettings.ENGINE_GEMINI) {
            audioRecorder.stop()
        } else {
            speechRecognizer.stop()
        }
    }

    /** Records a clip and lets Gemini turn it into text. No speech service needed. */
    private fun startRecording() {
        if (!audioRecorder.hasPermission()) {
            _uiState.update {
                it.copy(
                    voiceState = VoiceState.ERROR,
                    statusLine = "Microphone permission needed",
                    error = AssistantError.MIC_PERMISSION
                )
            }
            return
        }
        _uiState.update {
            it.copy(
                voiceState = VoiceState.LISTENING,
                statusLine = "Listening… tap to stop",
                partialTranscript = "",
                error = null,
                errorDetail = null,
                isStreaming = false
            )
        }
        audioRecorder.start()
    }

    private fun transcribeClip(clip: AudioRecorder.Clip) {
        _uiState.update {
            it.copy(
                voiceState = VoiceState.PROCESSING,
                statusLine = "Sending your voice…",
                micLevel = 0f
            )
        }
        viewModelScope.launch {
            val latest = settingsRepository.current()
            if (latest.apiKey.isBlank()) {
                _uiState.update { it.copy(voiceState = VoiceState.ERROR, error = AssistantError.MISSING_API_KEY) }
                return@launch
            }
            // The lite model transcribes faster and is plenty for a short clip.
            geminiClient.transcribe(TRANSCRIBE_MODEL, latest.apiKey, clip.wavBase64)
                .onSuccess { transcript ->
                    val clean = transcript.trim()
                    if (clean.isEmpty() || clean.equals("NONE", ignoreCase = true)) {
                        val peak = String.format("%.2f", clip.peakLevel)
                        _uiState.update {
                            it.copy(
                                voiceState = VoiceState.IDLE,
                                statusLine = "I didn't hear that",
                                error = AssistantError.NO_SPEECH,
                                errorDetail = "clip " + (clip.durationMs / 1000) +
                                    "s, mic level " + peak + " (speak closer to the phone)"
                            )
                        }
                    } else {
                        send(clean)
                    }
                }
                .onFailure { failure ->
                    val gemini = failure as? GeminiException
                    _uiState.update {
                        it.copy(
                            voiceState = VoiceState.ERROR,
                            statusLine = "Could not understand the audio",
                            error = gemini?.error ?: AssistantError.UNKNOWN,
                            errorDetail = "transcribe: " + (gemini?.detail ?: failure.message)
                        )
                    }
                }
        }
    }

    /** The phone's own SpeechRecognizer, kept for devices where it does work. */
    private fun startPhoneRecognition() {
        if (!speechRecognizer.isAvailable()) {
            _uiState.update {
                it.copy(voiceState = VoiceState.ERROR, error = AssistantError.SPEECH_UNAVAILABLE)
            }
            return
        }
        _uiState.update {
            it.copy(
                voiceState = VoiceState.LISTENING,
                statusLine = "Listening…",
                partialTranscript = "",
                error = null
            )
        }
        speechRecognizer.start(settings.language.speechTag)
    }

    /** Cancels whatever is happening: a reply being generated, or speech. */
    fun stopEverything() {
        liveSession.stop()
        grokSession.stop()
        replyJob?.cancel()
        replyJob = null
        audioRecorder.cancel()
        speechSynthesizer.stop()
        geminiSpeaker.stop()
        _uiState.update {
            it.copy(
                voiceState = VoiceState.INTERRUPTED,
                statusLine = "Stopped. Tap the orb to talk again.",
                isStreaming = false,
                streamingReply = ""
            )
        }
    }

    fun stopSpeaking() {
        speechSynthesizer.stop()
        geminiSpeaker.stop()
        _uiState.update {
            it.copy(voiceState = VoiceState.INTERRUPTED, statusLine = "Stopped. Tap to talk again.")
        }
    }

    fun repeatLastReply() {
        if (lastSpokenReply.isNotBlank()) {
            speak(lastSpokenReply)
        }
    }

    /** Text that came back from the system speech-recognition dialog. */
    fun submitVoiceText(text: String) {
        if (text.isBlank()) return
        speechRecognizer.cancel()
        send(text)
    }

    private fun shortStatus(error: AssistantError): String = when (error) {
        AssistantError.NO_SPEECH -> "I didn't hear that"
        AssistantError.MIC_PERMISSION -> "Microphone permission needed"
        AssistantError.SPEECH_UNAVAILABLE -> "Voice input is not available"
        AssistantError.NETWORK -> "Network problem while listening"
        AssistantError.TTS_UNAVAILABLE -> "Voice output is not available"
        else -> "Tap the orb to try again"
    }

    /** Sends a screenshot to Gemini and asks what is on it. */
    fun sendScreenLook(jpegBase64: String) {
        speechSynthesizer.stop()
        geminiSpeaker.stop()
        audioRecorder.cancel()
        send(
            text = "Yeh mere phone ki screen hai. Isme kya hai, aur main kya kar sakta hoon? " +
                "Hindi me chhote do-tin vaakya me batao.",
            imageBase64 = jpegBase64,
            imageMimeType = "image/jpeg"
        )
    }

    fun sendTypedMessage(text: String) {
        if (text.isBlank()) return
        speechRecognizer.cancel()
        send(text)
    }

    fun attachImageAndAsk(base64: String, mimeType: String, question: String) {
        send(question.ifBlank { "What is in this image?" }, base64, mimeType)
    }

    fun confirmPendingAction() {
        val action = _uiState.value.pendingAction ?: return
        _uiState.update { it.copy(pendingAction = null) }
        val outcome = deviceActions.execute(action)
        appendSystemNote(outcome.message)
    }

    fun dismissPendingAction() {
        _uiState.update { it.copy(pendingAction = null) }
        appendSystemNote("Okay, I won't do that.")
    }

    /** Reads the last known position once and fetches the local weather. */
    fun refreshWeather() {
        val allowed = LocationHelper.hasPermission(appContext)
        _uiState.update { it.copy(locationAllowed = allowed) }
        if (!allowed) return
        if (_uiState.value.weatherLoading) return
        _uiState.update { it.copy(weatherLoading = true) }
        viewModelScope.launch {
            val position = LocationHelper.current(appContext)
            val weather = position?.let { (lat, lon) -> WeatherRepository.current(lat, lon) }
            _uiState.update { it.copy(weather = weather, weatherLoading = false) }
        }
    }

    fun onLocationPermissionResult(granted: Boolean) {
        _uiState.update { it.copy(locationAllowed = granted) }
        if (granted) refreshWeather()
    }

    fun dismissError() {
        _uiState.update { it.copy(error = null, errorDetail = null) }
    }

    /** The UI has launched the system recogniser; clear the one-shot flag. */
    fun consumeAutoFallback() {
        _uiState.update { it.copy(autoFallbackPending = false) }
    }

    /** Called when the user declines (or permanently blocks) the microphone. */
    fun reportMicPermissionDenied() {
        _uiState.update {
            it.copy(
                voiceState = VoiceState.ERROR,
                statusLine = "Microphone permission needed",
                error = AssistantError.MIC_PERMISSION
            )
        }
    }

    fun dismissNotice() {
        _uiState.update { it.copy(notice = null) }
    }

    fun startNewConversation() {
        replyJob?.cancel()
        session = null
        lastSpokenReply = ""
        _uiState.update {
            it.copy(
                conversation = emptyList(),
                streamingReply = "",
                voiceState = VoiceState.IDLE,
                statusLine = "Tap the orb and talk to me",
                isStreaming = false
            )
        }
    }

    private fun send(text: String, imageBase64: String? = null, imageMimeType: String? = null) {
        val currentSession = session ?: ChatSession(
            title = text.take(40).ifBlank { "Voice chat" }
        )
        val history = currentSession.messages
        val userMessage = ChatMessage(
            role = ChatMessage.Role.USER,
            text = text,
            imageBase64 = imageBase64,
            imageMimeType = imageMimeType
        )
        val updated = currentSession.copy(
            messages = history + userMessage,
            updatedAt = System.currentTimeMillis()
        )
        session = updated

        _uiState.update {
            it.copy(
                conversation = updated.messages,
                streamingReply = "",
                voiceState = VoiceState.PROCESSING,
                statusLine = "Thinking…",
                partialTranscript = "",
                error = null,
                isStreaming = true
            )
        }

        replyJob = viewModelScope.launch {
            val builder = StringBuilder()
            conversationEngine
                .stream(history, text, imageBase64, imageMimeType)
                .collect { event ->
                    when (event) {
                        is EngineEvent.Token -> {
                            builder.append(event.text)
                            _uiState.update { it.copy(streamingReply = builder.toString()) }
                        }

                        is EngineEvent.Failed -> {
                            _uiState.update {
                                it.copy(
                                    voiceState = VoiceState.ERROR,
                                    statusLine = "Something went wrong",
                                    error = event.error,
                                    errorDetail = "chat: " + (event.detail ?: "no detail"),
                                    isStreaming = false
                                )
                            }
                        }

                        is EngineEvent.Completed -> finishReply(event, builder.toString())
                    }
                }
        }
    }

    private suspend fun finishReply(event: EngineEvent.Completed, streamed: String) {
        val replyText = event.text.ifBlank { streamed }.trim().ifBlank { "Done." }
        val currentSession = session ?: return
        val assistantMessage = ChatMessage(role = ChatMessage.Role.ASSISTANT, text = replyText)
        val updated = currentSession.copy(
            messages = currentSession.messages + assistantMessage,
            updatedAt = System.currentTimeMillis()
        )
        session = updated
        chatRepository.save(updated)

        _uiState.update {
            it.copy(
                conversation = updated.messages,
                streamingReply = "",
                isStreaming = false,
                statusLine = "Your turn"
            )
        }

        val action = event.actions.firstOrNull()
        if (action != null) {
            if (deviceActions.requiresConfirmation(action)) {
                _uiState.update { it.copy(pendingAction = action) }
            } else {
                val outcome = deviceActions.execute(action)
                appendSystemNote(outcome.message)
            }
        }

        speak(replyText)
    }

    private fun speak(text: String) {
        lastSpokenReply = text
        if (!settings.voiceEnabled) {
            _uiState.update { it.copy(voiceState = VoiceState.IDLE, statusLine = "Your turn") }
            return
        }
        _uiState.update {
            it.copy(voiceState = VoiceState.SPEAKING, statusLine = "Speaking…")
        }
        if (settings.speechEngine != AppSettings.SPEECH_GEMINI) {
            _uiState.update { it.copy(statusLine = "Speaking… (phone voice)") }
            speechSynthesizer.speak(text, settings.language.speechTag, settings.speechRate)
            return
        }
        viewModelScope.launch {
            val latest = settingsRepository.current()
            // One attempt only, on the fast voice: a second Gemini try would
            // add another 15 s of silence before the phone voice takes over.
            val candidates = listOf("gemini-3.8-flash-lite-tts")
            val spokenText = text.take(600)
            var spoken = false
            for (model in candidates) {
                val audio = geminiClient.synthesize(
                    model,
                    latest.apiKey,
                    spokenText,
                    latest.voiceName,
                    latest.language
                ).getOrNull()
                if (audio != null) {
                    // The user may have pressed stop while the voice was rendering.
                    if (_uiState.value.voiceState == VoiceState.SPEAKING) {
                        _uiState.update { it.copy(statusLine = "Speaking… (natural voice)") }
                        geminiSpeaker.playAudio(audio.data, audio.mimeType)
                    }
                    spoken = true
                    break
                }
            }
            if (!spoken) {
                _uiState.update { it.copy(statusLine = "Speaking… (phone voice)") }
                speechSynthesizer.speak(text, latest.language.speechTag, latest.speechRate)
            }
        }
    }

    private fun startLive() {
        if (!_uiState.value.hasApiKey) {
            _uiState.update { it.copy(error = AssistantError.MISSING_API_KEY) }
            return
        }
        speechSynthesizer.stop()
        geminiSpeaker.stop()
        audioRecorder.cancel()
        _uiState.update {
            it.copy(
                voiceState = VoiceState.PROCESSING,
                statusLine = "Connecting…",
                partialTranscript = "",
                streamingReply = "",
                error = null,
                errorDetail = null
            )
        }
        viewModelScope.launch {
            val latest = settingsRepository.current()
            val memory = if (latest.memoryEnabled) memoryRepository.all() else emptyList()
            val prompt = PromptBuilder.systemInstruction(latest, memory, hasImage = false)
            val languageHint = if (latest.language.tag == "auto") {
                null
            } else {
                latest.language.tag.substringBefore("-")
            }
            if (latest.liveEngine == AppSettings.LIVE_GROK) {
                if (latest.grokKey.isBlank()) {
                    _uiState.update {
                        it.copy(
                            voiceState = VoiceState.ERROR,
                            statusLine = "Grok key needed",
                            error = AssistantError.MISSING_API_KEY,
                            errorDetail = "Add an xAI key in Settings → API keys, or switch Live voice back to Gemini."
                        )
                    }
                    return@launch
                }
                grokSession.start(
                    apiKey = latest.grokKey,
                    systemPrompt = prompt,
                    voice = latest.grokVoice.ifBlank { GrokLiveSession.DEFAULT_VOICE },
                    languageHint = languageHint
                )
            } else {
                liveSession.start(latest.apiKey, LiveVoiceSession.MODEL, prompt, latest.voiceName)
            }
        }
    }

    private fun finaliseLiveTurn() {
        val spoken = _uiState.value.streamingReply.trim()
        _uiState.update {
            it.copy(
                streamingReply = "",
                partialTranscript = "",
                voiceState = VoiceState.LISTENING,
                statusLine = "Live — just talk"
            )
        }
        if (spoken.isBlank()) return
        val current = session ?: ChatSession(title = spoken.take(40))
        val message = ChatMessage(role = ChatMessage.Role.ASSISTANT, text = spoken)
        val updated = current.copy(
            messages = current.messages + message,
            updatedAt = System.currentTimeMillis()
        )
        session = updated
        _uiState.update { it.copy(conversation = updated.messages) }
        viewModelScope.launch { chatRepository.save(updated) }
    }

    private fun ttsModelFor(chatModel: String): String =
        if (chatModel.contains("lite")) "gemini-3.8-flash-lite-tts" else "gemini-3.8-flash-tts"

    private fun handleSpeechFinished() {
        if (_uiState.value.voiceState != VoiceState.SPEAKING) return
        _uiState.update {
            it.copy(
                voiceState = VoiceState.IDLE,
                statusLine = if (settings.continuousConversation) "Listening again…" else "Tap the orb to talk again"
            )
        }
        if (settings.continuousConversation && _uiState.value.pendingAction == null) {
            startListening()
        }
    }

    private fun appendSystemNote(message: String) {
        val currentSession = session ?: return
        val note = ChatMessage(role = ChatMessage.Role.ASSISTANT, text = message)
        val updated = currentSession.copy(
            messages = currentSession.messages + note,
            updatedAt = System.currentTimeMillis()
        )
        session = updated
        _uiState.update { it.copy(conversation = updated.messages) }
        viewModelScope.launch { chatRepository.save(updated) }
    }

    override fun onCleared() {
        replyJob?.cancel()
        audioRecorder.cancel()
        audioRecorder.listener = null
        liveSession.stop()
        liveSession.listener = null
        grokSession.stop()
        grokSession.listener = null
        geminiSpeaker.stop()
        geminiSpeaker.onDone = null
        geminiSpeaker.onError = null
        speechRecognizer.listener = null
        speechSynthesizer.onDone = null
        speechSynthesizer.onError = null
        speechSynthesizer.onLanguageFallback = null
        speechSynthesizer.onLanguageMissing = null
        super.onCleared()
    }

    companion object {
        /** Fast model used only to turn a recorded clip into text. */
        private const val TRANSCRIBE_MODEL = "gemini-3.5-flash-lite"

        fun factory(container: AppContainer): ViewModelProvider.Factory = viewModelFactory {
            initializer {
                HomeViewModel(
                    settingsRepository = container.settingsRepository,
                    chatRepository = container.chatRepository,
                    conversationEngine = container.conversationEngine,
                    speechRecognizer = container.speechRecognizer,
                    speechSynthesizer = container.speechSynthesizer,
                    deviceActions = container.deviceActions,
                    audioRecorder = container.audioRecorder,
                    geminiClient = container.geminiClient,
                    geminiSpeaker = container.geminiSpeaker,
                    appContext = container.appContext,
                    liveSession = container.liveSession,
                    grokSession = container.grokSession,
                    memoryRepository = container.memoryRepository
                )
            }
        }
    }
}
