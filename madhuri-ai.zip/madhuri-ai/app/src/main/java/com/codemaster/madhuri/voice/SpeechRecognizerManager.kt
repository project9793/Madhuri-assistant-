package com.codemaster.madhuri.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.codemaster.madhuri.model.AssistantError
import java.util.Locale

/**
 * Wraps [SpeechRecognizer]. It is started only on an explicit user tap (or by the
 * continuous-conversation loop the user switched on) and never records in the
 * background.
 */
class SpeechRecognizerManager(private val context: Context) {

    interface Listener {
        fun onListeningStarted()
        fun onPartialResult(text: String)
        fun onFinalResult(text: String)
        fun onFinished()
        fun onFailure(error: AssistantError)
    }

    var listener: Listener? = null

    private val mainHandler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var listening = false

    val isListening: Boolean get() = listening

    fun isAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    fun start(languageTag: String) {
        mainHandler.post {
            if (!isAvailable()) {
                listener?.onFailure(AssistantError.SPEECH_UNAVAILABLE)
                return@post
            }
            if (listening) return@post
            val engine = recognizer ?: createRecognizer().also { recognizer = it }
            listening = true
            engine.startListening(buildIntent(languageTag))
        }
    }

    /** Ask the service to finish and deliver whatever it already heard. */
    fun stop() {
        mainHandler.post {
            if (listening) recognizer?.stopListening()
        }
    }

    /** Abandon the current capture; nothing is delivered. */
    fun cancel() {
        mainHandler.post {
            listening = false
            recognizer?.cancel()
        }
    }

    fun destroy() {
        mainHandler.post {
            listening = false
            recognizer?.destroy()
            recognizer = null
        }
    }

    private fun createRecognizer(): SpeechRecognizer =
        SpeechRecognizer.createSpeechRecognizer(context).also { it.setRecognitionListener(callback) }

    private fun buildIntent(languageTag: String): Intent {
        val tag = localeFor(languageTag).toLanguageTag()
        return Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, tag)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, tag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1800L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 800L)
        }
    }

    private val callback = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            listener?.onListeningStarted()
        }

        override fun onBeginningOfSpeech() = Unit

        override fun onRmsChanged(rmsdB: Float) = Unit

        override fun onBufferReceived(buffer: ByteArray?) = Unit

        override fun onEndOfSpeech() = Unit

        override fun onError(error: Int) {
            listening = false
            listener?.onFailure(mapError(error))
        }

        override fun onResults(results: Bundle?) {
            listening = false
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                ?.trim()
                .orEmpty()
            if (text.isEmpty()) {
                listener?.onFailure(AssistantError.NO_SPEECH)
            } else {
                listener?.onFinalResult(text)
            }
            listener?.onFinished()
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val text = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                ?.trim()
                .orEmpty()
            if (text.isNotEmpty()) listener?.onPartialResult(text)
        }

        override fun onEvent(eventType: Int, params: Bundle?) = Unit
    }

    private fun mapError(error: Int): AssistantError = when (error) {
        SpeechRecognizer.ERROR_NO_MATCH,
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> AssistantError.NO_SPEECH

        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> AssistantError.MIC_PERMISSION

        SpeechRecognizer.ERROR_NETWORK,
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> AssistantError.NETWORK

        else -> AssistantError.UNKNOWN
    }

    private fun localeFor(languageTag: String): Locale {
        val locale = Locale.forLanguageTag(languageTag)
        return if (locale.language.isEmpty()) Locale.forLanguageTag("en-IN") else locale
    }
}
