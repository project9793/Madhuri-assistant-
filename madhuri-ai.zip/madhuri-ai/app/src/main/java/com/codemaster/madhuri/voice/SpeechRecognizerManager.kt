package com.codemaster.madhuri.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.codemaster.madhuri.model.AssistantError
import java.util.Locale

/**
 * Wraps [SpeechRecognizer]. It is started only on an explicit user tap (or by the
 * continuous-conversation loop the user switched on) and never records in the
 * background.
 */
class SpeechRecognizerManager(private var context: Context) {

    interface Listener {
        fun onListeningStarted()
        fun onPartialResult(text: String)
        fun onFinalResult(text: String)
        fun onFinished()
        fun onFailure(error: AssistantError, detail: String? = null)
    }

    var listener: Listener? = null

    private val mainHandler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var listening = false

    val isListening: Boolean get() = listening

    fun isAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    fun start(languageTag: String) {
        mainHandler.post {
            if (!isAvailable()) {
                listener?.onFailure(AssistantError.SPEECH_UNAVAILABLE, "no recognition service")
                return@post
            }
            if (listening) return@post
            val engine = recognizer ?: createRecognizer().also { recognizer = it }
            listening = true
            armWatchdog()
            engine.startListening(buildIntent(languageTag))
        }
    }

    /** Ask the service to finish and deliver whatever it already heard. */
    fun stop() {
        mainHandler.post {
            if (listening) recognizer?.stopListening()
        }
    }

    /** Abandon the current capture; nothing is delivered. */
    fun cancel() {
        mainHandler.post {
            listening = false
            recognizer?.cancel()
        }
    }

    fun destroy() {
        mainHandler.post {
            listening = false
            disarmWatchdog()
            recognizer?.destroy()
            recognizer = null
        }
    }

    /** Clears a stuck state so the next tap always starts a fresh capture. */
    /**
     * Some phones refuse the recognizer when it is built from the application
     * context and answer with ERROR_INSUFFICIENT_PERMISSIONS. Rebuilding it on
     * the live Activity fixes that.
     */
    fun reattach(activity: Context) {
        mainHandler.post {
            listening = false
            disarmWatchdog()
            runCatching { recognizer?.cancel() }
            runCatching { recognizer?.destroy() }
            recognizer = null
            context = activity
        }
    }

    fun reset() {
        mainHandler.post {
            listening = false
            disarmWatchdog()
            recognizer?.cancel()
        }
    }

    private fun createRecognizer(): SpeechRecognizer =
        SpeechRecognizer.createSpeechRecognizer(context).also { it.setRecognitionListener(callback) }

    private fun buildIntent(languageTag: String): Intent {
        return Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1800L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 800L)
            // In "Automatic" mode the language is left unset on purpose so the
            // recognition service detects it (Hindi, English, Hinglish) itself.
            if (languageTag.isNotBlank() && languageTag != "auto") {
                val tag = localeFor(languageTag).toLanguageTag()
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, tag)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, tag)
            }
        }
    }

    /**
     * If the service never calls back (seen on some devices when the mic is
     * held by another app), the UI must not stay stuck in "Listening…".
     */
    private val watchdog = Runnable {
        if (listening) {
            listening = false
            recognizer?.cancel()
            listener?.onFailure(AssistantError.NO_SPEECH, "speech service did not respond")
            listener?.onFinished()
        }
    }

    private fun armWatchdog() {
        mainHandler.removeCallbacks(watchdog)
        mainHandler.postDelayed(watchdog, WATCHDOG_MILLIS)
    }

    private fun disarmWatchdog() {
        mainHandler.removeCallbacks(watchdog)
    }

    private val callback = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            listener?.onListeningStarted()
        }

        override fun onBeginningOfSpeech() = Unit

        override fun onRmsChanged(rmsdB: Float) = Unit

        override fun onBufferReceived(buffer: ByteArray?) = Unit

        override fun onEndOfSpeech() = Unit

        override fun onError(error: Int) {
            listening = false
            disarmWatchdog()
            listener?.onFailure(mapError(error), "SpeechRecognizer code " + error)
        }

        override fun onResults(results: Bundle?) {
            listening = false
            disarmWatchdog()
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                ?.trim()
                .orEmpty()
            if (text.isEmpty()) {
                listener?.onFailure(AssistantError.NO_SPEECH, "empty result")
            } else {
                listener?.onFinalResult(text)
            }
            listener?.onFinished()
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val text = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                ?.trim()
                .orEmpty()
            if (text.isNotEmpty()) listener?.onPartialResult(text)
        }

        override fun onEvent(eventType: Int, params: Bundle?) = Unit
    }

    private fun mapError(error: Int): AssistantError = when (error) {
        SpeechRecognizer.ERROR_NO_MATCH,
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> AssistantError.NO_SPEECH

        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> AssistantError.MIC_PERMISSION

        SpeechRecognizer.ERROR_NETWORK,
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> AssistantError.NETWORK

        else -> AssistantError.UNKNOWN
    }

    private fun localeFor(languageTag: String): Locale {
        val locale = Locale.forLanguageTag(languageTag)
        return if (locale.language.isEmpty()) Locale.forLanguageTag("en-IN") else locale
    }

    private companion object {
        const val WATCHDOG_MILLIS = 15_000L
    }
}
