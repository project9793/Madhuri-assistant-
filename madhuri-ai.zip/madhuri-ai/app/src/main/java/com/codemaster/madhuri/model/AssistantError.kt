package com.codemaster.madhuri.model

/**
 * Every failure the user can hit, with a message in English and Hindi so the UI
 * can show both without a lookup table per screen.
 */
enum class AssistantError(val english: String, val hindi: String) {
    MISSING_API_KEY(
        "No Gemini API key yet. Open Settings and add one to start talking.",
        "अभी Gemini API key नहीं है। बात शुरू करने के लिए Settings में key डालें।"
    ),
    INVALID_API_KEY(
        "That API key was rejected. Check it in Google AI Studio and paste it again.",
        "यह API key स्वीकार नहीं हुई। Google AI Studio में जाँच कर दोबारा डालें।"
    ),
    MODEL_NOT_FOUND(
        "This model is not available for your key. Pick another model in Settings.",
        "यह model आपकी key के लिए उपलब्ध नहीं है। Settings में दूसरा model चुनें।"
    ),
    QUOTA_EXCEEDED(
        "Every service you have a key for is out of quota right now. Add an OpenRouter key " +
            "as a backup in Settings → API keys, or wait for the reset.",
        "जिन सेवाओं की key आपके पास है, उन सबकी सीमा अभी पूरी है। Settings → API keys में " +
            "OpenRouter key बैकअप के तौर पर डालें, या रीसेट का इंतज़ार करें।"
    ),
    RATE_LIMITED(
        "Too many requests in a row. Wait a few seconds.",
        "बहुत जल्दी-जल्दी requests भेजी गईं। कुछ सेकंड रुकें।"
    ),
    NETWORK(
        "No internet connection. Check your network and try again.",
        "इंटरनेट कनेक्शन नहीं है। नेटवर्क जाँच कर दोबारा कोशिश करें।"
    ),
    TIMEOUT(
        "The request timed out. Try again.",
        "Request का समय समाप्त हो गया। दोबारा कोशिश करें।"
    ),
    SERVER(
        "Gemini is having trouble right now. Try again shortly.",
        "Gemini में अभी दिक्कत है। थोड़ी देर बाद कोशिश करें।"
    ),
    SPEECH_UNAVAILABLE(
        "This phone's own speech service cannot listen right now. Add a Groq key (free) so " +
            "Whisper can listen instead.",
        "इस फ़ोन की आवाज़ सेवा अभी सुन नहीं सकती। मुफ़्त Groq key डालें ताकि Whisper सुन सके।"
    ),
    MIC_PERMISSION(
        "Microphone permission is needed to listen. Enable it in Settings.",
        "सुनने के लिए माइक्रोफ़ोन की अनुमति चाहिए। Settings में इसे चालू करें।"
    ),
    NO_SPEECH(
        "I didn't catch that. Try speaking again.",
        "मैं समझ नहीं पाई। फिर से बोलिए।"
    ),
    TTS_UNAVAILABLE(
        "Text-to-speech is not installed. Replies will be shown as text.",
        "Text-to-speech इंस्टॉल नहीं है। जवाब टेक्स्ट में दिखेंगे।"
    ),
    UNKNOWN(
        "Something went wrong. Please try again.",
        "कुछ गलत हो गया। कृपया दोबारा कोशिश करें।"
    );

    /** Both lines, for a snackbar or dialog. */
    val bilingual: String get() = "$english\n$hindi"
}
