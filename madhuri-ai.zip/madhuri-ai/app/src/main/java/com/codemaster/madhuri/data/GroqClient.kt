package com.codemaster.madhuri.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/**
 * Groq Cloud: OpenAI-compatible chat plus Whisper speech-to-text.
 *
 * Keys from console.groq.com start with `gsk_`. The free tier covers both, which
 * makes it a complete voice loop without any Gemini quota.
 */
object GroqClient {

    const val BASE = "https://api.groq.com/openai/v1"
    const val CHAT_ENDPOINT = "$BASE/chat/completions"
    const val TRANSCRIBE_ENDPOINT = "$BASE/audio/transcriptions"
    const val MODELS_ENDPOINT = "$BASE/models"
    const val DEFAULT_MODEL = "llama-3.3-70b-versatile"
    const val WHISPER_MODEL = "whisper-large-v3-turbo"

    /** True when the key belongs to Groq rather than xAI. */
    fun isGroqKey(key: String): Boolean = key.trim().startsWith("gsk_", ignoreCase = true)

    /** Transcribes a WAV clip. Returns null when Groq could not read it. */
    suspend fun transcribe(
        apiKey: String,
        wavBytes: ByteArray,
        languageCode: String?
    ): Result<String> = withContext(Dispatchers.IO) {
        var connection: HttpURLConnection? = null
        try {
            val boundary = "----madhuri${UUID.randomUUID().toString().replace("-", "")}"
            connection = (URL(TRANSCRIBE_ENDPOINT).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 20_000
                readTimeout = 60_000
                doOutput = true
                setRequestProperty("Authorization", "Bearer $apiKey")
                setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            }

            connection.outputStream.use { out ->
                fun field(name: String, value: String) {
                    out.write("--$boundary\r\n".toByteArray())
                    out.write("Content-Disposition: form-data; name=\"$name\"\r\n\r\n".toByteArray())
                    out.write(value.toByteArray())
                    out.write("\r\n".toByteArray())
                }

                field("model", WHISPER_MODEL)
                field("response_format", "json")
                if (!languageCode.isNullOrBlank() && languageCode != "auto") {
                    field("language", languageCode.substringBefore("-"))
                }

                out.write("--$boundary\r\n".toByteArray())
                out.write(
                    "Content-Disposition: form-data; name=\"file\"; filename=\"clip.wav\"\r\n"
                        .toByteArray()
                )
                out.write("Content-Type: audio/wav\r\n\r\n".toByteArray())
                out.write(wavBytes)
                out.write("\r\n--$boundary--\r\n".toByteArray())
            }

            val code = connection.responseCode
            val body = if (code in 200..299) {
                connection.inputStream.bufferedReader().use { it.readText() }
            } else {
                connection.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
            }

            if (code !in 200..299) {
                return@withContext Result.failure(
                    GeminiException(
                        when (code) {
                            401, 403 -> com.codemaster.madhuri.model.AssistantError.INVALID_API_KEY
                            429 -> com.codemaster.madhuri.model.AssistantError.QUOTA_EXCEEDED
                            else -> com.codemaster.madhuri.model.AssistantError.UNKNOWN
                        },
                        "groq HTTP $code: $body",
                        "groq: ${body.replace("\n", " ").take(160)}"
                    )
                )
            }

            val text = JSONObject(body).optString("text").trim()
            if (text.isBlank()) {
                Result.failure(
                    GeminiException(
                        com.codemaster.madhuri.model.AssistantError.UNKNOWN,
                        "groq returned an empty transcript",
                        "groq: whisper heard nothing"
                    )
                )
            } else {
                Result.success(text)
            }
        } catch (e: IOException) {
            Result.failure(
                GeminiException(
                    com.codemaster.madhuri.model.AssistantError.NETWORK,
                    e.message ?: "groq network",
                    "groq: network"
                )
            )
        } catch (e: Exception) {
            Result.failure(
                GeminiException(
                    com.codemaster.madhuri.model.AssistantError.UNKNOWN,
                    e.message ?: "groq failed",
                    "groq: ${e.message}"
                )
            )
        } finally {
            connection?.disconnect()
        }
    }

    /** Validates the key against /models. */
    suspend fun testKey(apiKey: String): Int? = withContext(Dispatchers.IO) {
        var connection: HttpURLConnection? = null
        try {
            connection = (URL(MODELS_ENDPOINT).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 15_000
                readTimeout = 20_000
                setRequestProperty("Authorization", "Bearer $apiKey")
            }
            if (connection.responseCode !in 200..299) return@withContext null
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            JSONObject(body).optJSONArray("data")?.length() ?: 0
        } catch (e: Exception) {
            null
        } finally {
            connection?.disconnect()
        }
    }
}
