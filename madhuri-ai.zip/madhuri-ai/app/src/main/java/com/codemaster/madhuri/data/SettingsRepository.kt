package com.codemaster.madhuri.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.codemaster.madhuri.BuildConfig
import com.codemaster.madhuri.model.AppSettings
import com.codemaster.madhuri.model.Language
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "madhuri_settings"
)

/**
 * Single source of truth for user preferences. The API key is stored in the
 * app's private DataStore; it is never written to logs or exported.
 */
class SettingsRepository(private val context: Context) {

    private object Keys {
        val apiKey = stringPreferencesKey("api_key")
        val model = stringPreferencesKey("model")
        val languageTag = stringPreferencesKey("language_tag")
        val voiceEnabled = booleanPreferencesKey("voice_enabled")
        val continuous = booleanPreferencesKey("continuous_conversation")
        val memoryEnabled = booleanPreferencesKey("memory_enabled")
        val persona = stringPreferencesKey("persona")
        val speechRate = floatPreferencesKey("speech_rate")
        val themeMode = stringPreferencesKey("theme_mode")
        val voiceEngine = stringPreferencesKey("voice_engine")
        val speechEngine = stringPreferencesKey("speech_engine")
        val voiceName = stringPreferencesKey("voice_name")
        val userName = stringPreferencesKey("user_name")
        val userEmail = stringPreferencesKey("user_email")
        val avatarPath = stringPreferencesKey("avatar_path")
    }

    val settings: Flow<AppSettings> = context.settingsDataStore.data.map { it.toSettings() }

    suspend fun current(): AppSettings = settings.first()

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        context.settingsDataStore.edit { preferences ->
            val next = transform(preferences.toSettings())
            preferences[Keys.apiKey] = next.apiKey
            preferences[Keys.model] = next.model
            preferences[Keys.languageTag] = next.languageTag
            preferences[Keys.voiceEnabled] = next.voiceEnabled
            preferences[Keys.continuous] = next.continuousConversation
            preferences[Keys.memoryEnabled] = next.memoryEnabled
            preferences[Keys.persona] = next.persona
            preferences[Keys.speechRate] = next.speechRate
            preferences[Keys.themeMode] = next.themeMode
            preferences[Keys.voiceEngine] = next.voiceEngine
            preferences[Keys.speechEngine] = next.speechEngine
            preferences[Keys.voiceName] = next.voiceName
            preferences[Keys.userName] = next.userName
            preferences[Keys.userEmail] = next.userEmail
            preferences[Keys.avatarPath] = next.avatarPath
        }
    }

    suspend fun saveApiKey(key: String) = update { it.copy(apiKey = key.trim()) }

    suspend fun deleteApiKey() = update { it.copy(apiKey = "") }

    private fun Preferences.toSettings(): AppSettings = AppSettings(
        // A key baked in at build time from local.properties acts as the default
        // so a fresh clone can talk to Gemini before the user visits Settings.
        apiKey = this[Keys.apiKey] ?: BuildConfig.GEMINI_API_KEY,
        model = this[Keys.model] ?: AppSettings.DEFAULT_MODEL,
        languageTag = this[Keys.languageTag] ?: Language.AUTO.tag,
        voiceEnabled = this[Keys.voiceEnabled] ?: true,
        continuousConversation = this[Keys.continuous] ?: false,
        memoryEnabled = this[Keys.memoryEnabled] ?: true,
        persona = this[Keys.persona] ?: AppSettings.DEFAULT_PERSONA,
        speechRate = this[Keys.speechRate] ?: 1.0f,
        themeMode = this[Keys.themeMode] ?: AppSettings.THEME_DARK,
        voiceEngine = this[Keys.voiceEngine] ?: AppSettings.ENGINE_GEMINI,
        speechEngine = this[Keys.speechEngine] ?: AppSettings.SPEECH_GEMINI,
        voiceName = this[Keys.voiceName] ?: AppSettings.DEFAULT_VOICE,
        userName = this[Keys.userName] ?: "",
        userEmail = this[Keys.userEmail] ?: "",
        avatarPath = this[Keys.avatarPath] ?: ""
    )
}
