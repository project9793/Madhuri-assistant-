package com.codemaster.madhuri.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.codemaster.madhuri.BuildConfig
import com.codemaster.madhuri.model.AppSettings
import com.codemaster.madhuri.model.Language
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "madhuri_settings"
)

/**
 * Single source of truth for user preferences. The API key is stored in the
 * app's private DataStore; it is never written to logs or exported.
 */
class SettingsRepository(private val context: Context) {

    private object Keys {
        val apiKey = stringPreferencesKey("api_key")
        val model = stringPreferencesKey("model")
        val languageTag = stringPreferencesKey("language_tag")
        val voiceEnabled = booleanPreferencesKey("voice_enabled")
        val continuous = booleanPreferencesKey("continuous_conversation")
        val memoryEnabled = booleanPreferencesKey("memory_enabled")
        val persona = stringPreferencesKey("persona")
        val speechRate = floatPreferencesKey("speech_rate")
        val themeMode = stringPreferencesKey("theme_mode")
        val voiceEngine = stringPreferencesKey("voice_engine")
        val speechEngine = stringPreferencesKey("speech_engine")
        val voiceName = stringPreferencesKey("voice_name")
        val userName = stringPreferencesKey("user_name")
        val userEmail = stringPreferencesKey("user_email")
        val avatarPath = stringPreferencesKey("avatar_path")
        val thinking = stringPreferencesKey("thinking")
        val temperature = floatPreferencesKey("temperature")
        val maxTokens = intPreferencesKey("max_tokens")
        val memoryTurns = intPreferencesKey("memory_turns")
        val interruptEnabled = booleanPreferencesKey("interrupt_enabled")
        val endOfSpeech = stringPreferencesKey("end_of_speech")
        val webSearch = booleanPreferencesKey("web_search")
        val liveVoice = booleanPreferencesKey("live_voice")
        val chatProvider = stringPreferencesKey("chat_provider")
        val openRouterKey = stringPreferencesKey("openrouter_key")
        val openRouterModel = stringPreferencesKey("openrouter_model")
        val liveEngine = stringPreferencesKey("live_engine")
        val grokKey = stringPreferencesKey("grok_key")
        val grokVoice = stringPreferencesKey("grok_voice")
        val grokModel = stringPreferencesKey("grok_model")
        val quotaDeadAt = androidx.datastore.preferences.core.longPreferencesKey("quota_dead_at")
        val saveQuota = booleanPreferencesKey("save_quota")
        val assistantName = stringPreferencesKey("assistant_name")
        val voiceGender = stringPreferencesKey("voice_gender")
        val elevenKey = stringPreferencesKey("eleven_key")
        val elevenVoiceId = stringPreferencesKey("eleven_voice")
        val elevenModel = stringPreferencesKey("eleven_model")
    }

    val settings: Flow<AppSettings> = context.settingsDataStore.data.map { it.toSettings() }

    suspend fun current(): AppSettings = settings.first()

    /** Timestamp of the last Gemini quota wall, so the app can stop trying it. */
    suspend fun markGeminiQuotaDead() {
        context.settingsDataStore.edit { prefs ->
            prefs[Keys.quotaDeadAt] = System.currentTimeMillis()
        }
    }

    suspend fun geminiQuotaDeadRecently(): Boolean {
        val deadAt = context.settingsDataStore.data.first()[Keys.quotaDeadAt] ?: 0L
        return deadAt > 0 && System.currentTimeMillis() - deadAt < 6 * 60 * 60 * 1000L
    }

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        context.settingsDataStore.edit { preferences ->
            val next = transform(preferences.toSettings())
            preferences[Keys.apiKey] = next.apiKey
            preferences[Keys.model] = next.model
            preferences[Keys.languageTag] = next.languageTag
            preferences[Keys.voiceEnabled] = next.voiceEnabled
            preferences[Keys.continuous] = next.continuousConversation
            preferences[Keys.memoryEnabled] = next.memoryEnabled
            preferences[Keys.persona] = next.persona
            preferences[Keys.speechRate] = next.speechRate
            preferences[Keys.themeMode] = next.themeMode
            preferences[Keys.voiceEngine] = next.voiceEngine
            preferences[Keys.speechEngine] = next.speechEngine
            preferences[Keys.voiceName] = next.voiceName
            preferences[Keys.userName] = next.userName
            preferences[Keys.userEmail] = next.userEmail
            preferences[Keys.avatarPath] = next.avatarPath
            preferences[Keys.thinking] = next.thinking
            preferences[Keys.temperature] = next.temperature
            preferences[Keys.maxTokens] = next.maxTokens
            preferences[Keys.memoryTurns] = next.memoryTurns
            preferences[Keys.interruptEnabled] = next.interruptEnabled
            preferences[Keys.endOfSpeech] = next.endOfSpeechSensitivity
            preferences[Keys.webSearch] = next.webSearchEnabled
            preferences[Keys.liveVoice] = next.liveVoice
            preferences[Keys.chatProvider] = next.chatProvider
            preferences[Keys.openRouterKey] = next.openRouterKey
            preferences[Keys.openRouterModel] = next.openRouterModel
            preferences[Keys.liveEngine] = next.liveEngine
            preferences[Keys.grokKey] = next.grokKey
            preferences[Keys.grokVoice] = next.grokVoice
            preferences[Keys.grokModel] = next.grokModel
            preferences[Keys.saveQuota] = next.saveQuota
            preferences[Keys.assistantName] = next.assistantName
            preferences[Keys.voiceGender] = next.voiceGender
            preferences[Keys.elevenKey] = next.elevenKey
            preferences[Keys.elevenVoiceId] = next.elevenVoiceId
            preferences[Keys.elevenModel] = next.elevenModel
        }
    }

    suspend fun saveApiKey(key: String) = update { it.copy(apiKey = key.trim()) }

    suspend fun deleteApiKey() = update { it.copy(apiKey = "") }

    private fun Preferences.toSettings(): AppSettings = AppSettings(
        // A key baked in at build time from local.properties acts as the default
        // so a fresh clone can talk to Gemini before the user visits Settings.
        apiKey = this[Keys.apiKey] ?: BuildConfig.GEMINI_API_KEY,
        model = this[Keys.model] ?: AppSettings.DEFAULT_MODEL,
        languageTag = this[Keys.languageTag] ?: Language.AUTO.tag,
        voiceEnabled = this[Keys.voiceEnabled] ?: true,
        continuousConversation = this[Keys.continuous] ?: false,
        memoryEnabled = this[Keys.memoryEnabled] ?: true,
        persona = this[Keys.persona] ?: AppSettings.DEFAULT_PERSONA,
        speechRate = this[Keys.speechRate] ?: 1.0f,
        themeMode = this[Keys.themeMode] ?: AppSettings.THEME_DARK,
        voiceEngine = this[Keys.voiceEngine] ?: AppSettings.ENGINE_GEMINI,
        speechEngine = this[Keys.speechEngine] ?: AppSettings.SPEECH_GEMINI,
        voiceName = run {
            val saved = this[Keys.voiceName] ?: AppSettings.DEFAULT_VOICE
            val gender = this[Keys.voiceGender] ?: AppSettings.GENDER_FEMALE
            val matches = AppSettings.VOICE_GENDER[saved] == gender
            if (gender == AppSettings.GENDER_ALL || matches) {
                saved
            } else {
                // A male/gravelly voice was saved while a female voice is wanted.
                AppSettings.voicesFor(gender).firstOrNull() ?: AppSettings.DEFAULT_VOICE
            }
        },
        userName = this[Keys.userName] ?: "",
        userEmail = this[Keys.userEmail] ?: "",
        avatarPath = this[Keys.avatarPath] ?: "",
        thinking = this[Keys.thinking] ?: AppSettings.THINKING_DEFAULT,
        temperature = this[Keys.temperature] ?: 0.85f,
        maxTokens = this[Keys.maxTokens] ?: 2048,
        memoryTurns = this[Keys.memoryTurns] ?: 20,
        interruptEnabled = this[Keys.interruptEnabled] ?: true,
        endOfSpeechSensitivity = this[Keys.endOfSpeech] ?: AppSettings.SENSITIVITY_MEDIUM,
        webSearchEnabled = this[Keys.webSearch] ?: false,
        liveVoice = this[Keys.liveVoice] ?: false,
        chatProvider = this[Keys.chatProvider] ?: AppSettings.PROVIDER_AUTO,
        openRouterKey = this[Keys.openRouterKey] ?: "",
        openRouterModel = this[Keys.openRouterModel] ?: "openrouter/auto",
        liveEngine = this[Keys.liveEngine] ?: AppSettings.LIVE_GEMINI,
        grokKey = this[Keys.grokKey] ?: "",
        grokVoice = this[Keys.grokVoice] ?: "eve",
        grokModel = this[Keys.grokModel] ?: "grok-4.7",
        saveQuota = this[Keys.saveQuota] ?: false,
        assistantName = this[Keys.assistantName] ?: AppSettings.DEFAULT_ASSISTANT_NAME,
        voiceGender = this[Keys.voiceGender] ?: AppSettings.GENDER_FEMALE,
        elevenKey = this[Keys.elevenKey] ?: "",
        elevenVoiceId = this[Keys.elevenVoiceId] ?: "21m00Tcm4TlvDq8ikWAM",
        elevenModel = this[Keys.elevenModel] ?: "eleven_flash_v2_5"
    )
}
