package com.codemaster.madhuri.model

data class AppSettings(
    val apiKey: String = "",
    val model: String = DEFAULT_MODEL,
    val languageTag: String = Language.AUTO.tag,
    val voiceEnabled: Boolean = true,
    val continuousConversation: Boolean = false,
    val memoryEnabled: Boolean = true,
    val persona: String = DEFAULT_PERSONA,
    val speechRate: Float = 1.0f,
    val themeMode: String = THEME_DARK,
    val voiceEngine: String = ENGINE_GEMINI,
    val speechEngine: String = SPEECH_GEMINI,
    val voiceName: String = DEFAULT_VOICE,
    val userName: String = "",
    val userEmail: String = "",
    val avatarPath: String = "",
    val thinking: String = THINKING_DEFAULT,
    val temperature: Float = 0.85f,
    val maxTokens: Int = 2048,
    val memoryTurns: Int = 20,
    val interruptEnabled: Boolean = true,
    val endOfSpeechSensitivity: String = SENSITIVITY_MEDIUM,
    val webSearchEnabled: Boolean = false
) {
    val language: Language get() = Language.fromTag(languageTag)

    companion object {
        const val DEFAULT_MODEL = "gemini-3.8-flash"

        /** Used automatically when the chosen model is overloaded (HTTP 503). */
        const val FALLBACK_MODEL = "gemini-3.5-flash-lite"
        const val DEFAULT_PERSONA = "warm, confident, lightly witty, never sycophantic"

        /** Voice input that never depends on the phone's speech service. */
        const val ENGINE_GEMINI = "gemini"

        /** The phone's own SpeechRecognizer. */
        const val ENGINE_ANDROID = "android"

        /** Replies spoken by Gemini's natural voice models. */
        const val SPEECH_GEMINI = "gemini"

        /** Replies spoken by the phone's own text-to-speech engine. */
        const val SPEECH_ANDROID = "android"

        const val DEFAULT_VOICE = "Aoede"

        const val THINKING_DEFAULT = "default"
        const val THINKING_OFF = "off"
        const val THINKING_LOW = "low"
        const val THINKING_MEDIUM = "medium"
        const val THINKING_HIGH = "high"

        const val SENSITIVITY_LOW = "low"
        const val SENSITIVITY_MEDIUM = "medium"
        const val SENSITIVITY_HIGH = "high"

        /** Thinking budgets sent to Gemini, in tokens. */
        fun thinkingBudget(mode: String): Int? = when (mode) {
            THINKING_OFF -> 0
            THINKING_LOW -> 512
            THINKING_MEDIUM -> 2048
            THINKING_HIGH -> 8192
            else -> null
        }

        /** Silence, in milliseconds, before a recording stops by itself. */
        fun silenceMs(mode: String): Long = when (mode) {
            SENSITIVITY_LOW -> 3_400L
            SENSITIVITY_HIGH -> 1_300L
            else -> 2_200L
        }

        /** Personality presets offered in Settings; the text is what the model reads. */
        val PERSONAS = listOf(
            "GirlFriend" to "a warm, affectionate girlfriend-like companion: playful, a little flirty but " +
                "always respectful and never explicit, genuinely interested in the user's day",
            "Boss" to "a confident boss: direct, decisive and slightly commanding, but fair and encouraging",
            "Teacher" to "a patient teacher who explains step by step, checks understanding and never makes " +
                "the user feel slow",
            "Soft Romantic Listener" to "gentle, soft-spoken and romantic, a patient listener who lets the " +
                "user talk and answers with warmth",
            "Hyper Energetic" to "high-energy and enthusiastic, quick and upbeat, celebrating small wins loudly",
            "Caring Neon AI" to "a futuristic caring AI with a soft glow in her voice: precise, kind and a " +
                "little bit sci-fi",
            "Savage Girl" to "witty and blunt, playfully roasting the user like a close friend, never cruel " +
                "and never insulting about real insecurities",
            "Mystical" to "mystical and poetic, speaking in gentle images and calm riddles, never vague about facts",
            "MT Assistant" to "an efficient professional assistant: concise, organised, task-focused",
            "Unknown" to "mysterious and minimal, answering briefly with a hint of intrigue",
            "Warm & witty" to DEFAULT_PERSONA,
            "Sweet & caring" to "sweet, caring and softly spoken, always gentle with the user's feelings",
            "Playful & teasing" to "playful and lightly teasing, quick with a joke but never mean",
            "Calm & professional" to "calm, precise and professional, warm but businesslike"
        )

        /** Every prebuilt voice the Gemini speech models offer. */
        val VOICES = listOf(
            "Aoede", "Achernar", "Achird", "Algenib", "Algieba", "Alnilam",
            "Autonoe", "Callirrhoe", "Charon", "Despina", "Enceladus", "Erinome",
            "Fenrir", "Gacrux", "Iapetus", "Kore", "Laomedeia", "Leda",
            "Orus", "Puck", "Pulcherrima", "Rasalgethi", "Sadachbia", "Sadaltager",
            "Schedar", "Sulafat", "Umbriel", "Vindemiatrix", "Zephyr", "Zubenelgenubi"
        )

        const val THEME_SYSTEM = "system"
        const val THEME_DARK = "dark"
        const val THEME_LIGHT = "light"

        /** Stable Gemini models that support generateContent and vision. */
        val MODELS = listOf(
            "gemini-3.8-flash",
            "gemini-3.5-flash-lite"
        )
    }
}

/** The six states of the voice loop, each with its own orb animation. */
enum class VoiceState { IDLE, LISTENING, PROCESSING, SPEAKING, INTERRUPTED, ERROR }
