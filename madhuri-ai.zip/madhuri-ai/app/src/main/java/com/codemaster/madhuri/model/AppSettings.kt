package com.codemaster.madhuri.model

data class AppSettings(
    val apiKey: String = "",
    val model: String = DEFAULT_MODEL,
    val languageTag: String = Language.AUTO.tag,
    val voiceEnabled: Boolean = true,
    val continuousConversation: Boolean = false,
    val memoryEnabled: Boolean = true,
    val persona: String = DEFAULT_PERSONA,
    val speechRate: Float = 1.0f,
    val themeMode: String = THEME_DARK,
    val voiceEngine: String = ENGINE_GEMINI,
    val speechEngine: String = SPEECH_GEMINI,
    val voiceName: String = DEFAULT_VOICE
) {
    val language: Language get() = Language.fromTag(languageTag)

    companion object {
        const val DEFAULT_MODEL = "gemini-3.8-flash"
        const val DEFAULT_PERSONA = "warm, confident, lightly witty, never sycophantic"

        /** Voice input that never depends on the phone's speech service. */
        const val ENGINE_GEMINI = "gemini"

        /** The phone's own SpeechRecognizer. */
        const val ENGINE_ANDROID = "android"

        /** Replies spoken by Gemini's natural voice models. */
        const val SPEECH_GEMINI = "gemini"

        /** Replies spoken by the phone's own text-to-speech engine. */
        const val SPEECH_ANDROID = "android"

        const val DEFAULT_VOICE = "Aoede"

        /** Gemini prebuilt voices that suit a warm, friendly assistant. */
        val VOICES = listOf("Aoede", "Kore", "Leda", "Zephyr", "Sulafat")

        const val THEME_SYSTEM = "system"
        const val THEME_DARK = "dark"
        const val THEME_LIGHT = "light"

        /** Stable Gemini models that support generateContent and vision. */
        val MODELS = listOf(
            "gemini-3.8-flash",
            "gemini-3.5-flash-lite"
        )
    }
}

/** The six states of the voice loop, each with its own orb animation. */
enum class VoiceState { IDLE, LISTENING, PROCESSING, SPEAKING, INTERRUPTED, ERROR }
