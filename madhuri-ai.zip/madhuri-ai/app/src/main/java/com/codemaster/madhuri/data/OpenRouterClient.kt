package com.codemaster.madhuri.data

import com.codemaster.madhuri.model.AssistantError
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

/**
 * Text chat through OpenRouter, which speaks the OpenAI chat-completions shape.
 * OpenRouter has no realtime audio API, so voice still comes from Gemini or the
 * phone; this only replaces the "what should she say" step.
 */
class OpenRouterClient {

    data class Turn(val role: String, val text: String)

    fun streamChat(
        model: String,
        apiKey: String,
        endpoint: String = ENDPOINT,
        systemInstruction: String,
        history: List<Turn>,
        userText: String,
        temperature: Double,
        maxTokens: Int
    ): Flow<String> = flow {
        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content", systemInstruction))
        history.forEach { turn ->
            messages.put(JSONObject().put("role", turn.role).put("content", turn.text))
        }
        messages.put(JSONObject().put("role", "user").put("content", userText))

        val body = JSONObject().apply {
            put("model", model)
            put("messages", messages)
            put("stream", true)
            put("temperature", temperature)
            put("max_tokens", maxTokens)
        }

        var connection: HttpURLConnection? = null
        try {
            connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 30_000
                readTimeout = 120_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Authorization", "Bearer $apiKey")
                setRequestProperty("HTTP-Referer", "https://github.com/project9793/Madhuri-assistant-")
                setRequestProperty("X-Title", "Madhuri AI")
            }
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = connection.responseCode
            if (code !in 200..299) {
                val payload = connection.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                throw GeminiException(errorFor(code, payload), "HTTP $code: $payload", detailFor(code, payload))
            }

            connection.inputStream.bufferedReader(Charsets.UTF_8).use { reader ->
                while (true) {
                    val line = reader.readLine() ?: break
                    if (!line.startsWith("data:")) continue
                    val payload = line.substring(5).trim()
                    if (payload.isEmpty() || payload == "[DONE]") continue
                    val text = runCatching {
                        JSONObject(payload)
                            .optJSONArray("choices")
                            ?.optJSONObject(0)
                            ?.optJSONObject("delta")
                            ?.optString("content")
                            .orEmpty()
                    }.getOrDefault("")
                    if (text.isNotEmpty()) emit(text)
                }
            }
        } catch (e: GeminiException) {
            throw e
        } catch (e: SocketTimeoutException) {
            throw GeminiException(AssistantError.TIMEOUT, e.message ?: "timeout", "openrouter: timeout")
        } catch (e: UnknownHostException) {
            throw GeminiException(AssistantError.NETWORK, e.message ?: "network", "openrouter: no network")
        } catch (e: IOException) {
            throw GeminiException(AssistantError.NETWORK, e.message ?: "network", "openrouter: network")
        } finally {
            connection?.disconnect()
        }
    }.flowOn(Dispatchers.IO)

    /** Returns the number of models the key can see, or null when it is rejected. */
    suspend fun testKey(apiKey: String): Int? = withContext(Dispatchers.IO) {
        var connection: HttpURLConnection? = null
        try {
            connection = (URL(MODELS_ENDPOINT).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 20_000
                readTimeout = 25_000
                setRequestProperty("Authorization", "Bearer $apiKey")
            }
            if (connection.responseCode !in 200..299) return@withContext null
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            JSONObject(body).optJSONArray("data")?.length() ?: 0
        } catch (e: Exception) {
            null
        } finally {
            connection?.disconnect()
        }
    }

    private fun errorFor(code: Int, payload: String): AssistantError {
        val lower = payload.lowercase()
        return when {
            code == 401 || code == 403 -> AssistantError.INVALID_API_KEY
            code == 402 -> AssistantError.QUOTA_EXCEEDED
            code == 404 -> AssistantError.MODEL_NOT_FOUND
            code == 429 && lower.contains("quota") -> AssistantError.QUOTA_EXCEEDED
            code == 429 -> AssistantError.RATE_LIMITED
            code in 500..599 -> AssistantError.SERVER
            else -> AssistantError.UNKNOWN
        }
    }

    private fun detailFor(code: Int, payload: String): String {
        val message = runCatching {
            JSONObject(payload).optJSONObject("error")?.optString("message")
        }.getOrNull()
        return if (message.isNullOrBlank()) "openrouter: HTTP $code" else "openrouter: $message".take(240)
    }

    companion object {
        const val ENDPOINT = "https://openrouter.ai/api/v1/chat/completions"

        /** xAI speaks the same shape, so one client serves both. */
        const val XAI_ENDPOINT = "https://api.x.ai/v1/chat/completions"
        private const val MODELS_ENDPOINT = "https://openrouter.ai/api/v1/models"
        const val DEFAULT_MODEL = "openrouter/auto"
    }
}
