package com.codemaster.madhuri.voice

import android.content.Context
import android.media.AudioAttributes
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.codemaster.madhuri.model.AssistantError
import java.util.Locale

/**
 * Wraps Android [TextToSpeech]. Utterances are flushed rather than queued so
 * "stop" and "interrupt" are instant, and the completion callback is what drives
 * the continuous-conversation loop.
 */
class SpeechSynthesizer(private val context: Context) {

    var onDone: (() -> Unit)? = null
    var onError: ((AssistantError) -> Unit)? = null

    /** (requestedTag, usedTag) — fired when the device has no voice for a language. */
    var onLanguageFallback: ((String, String) -> Unit)? = null

    /** Fired when the phone has no usable voice and speaking would sound wrong. */
    var onLanguageMissing: ((String) -> Unit)? = null

    private data class Pending(val text: String, val languageTag: String, val rate: Float)

    private val mainHandler = Handler(Looper.getMainLooper())
    private var engine: TextToSpeech? = null
    private var ready = false
    private var pending: Pending? = null
    private var lastSpokenText: String = ""

    init {
        engine = TextToSpeech(context) { status -> handleInit(status) }
    }

    val isSpeaking: Boolean get() = engine?.isSpeaking == true

    fun speak(text: String, languageTag: String, rate: Float) {
        if (text.isBlank()) return
        lastSpokenText = text
        val engine = this.engine
        if (engine == null) {
            onError?.invoke(AssistantError.TTS_UNAVAILABLE)
            return
        }
        if (!ready) {
            pending = Pending(text, languageTag, rate)
            return
        }
        deliver(engine, text, languageTag, rate)
    }

    /** True when the phone actually has a voice for this language. */
    fun hasVoiceFor(languageTag: String): Boolean {
        val engine = this.engine ?: return false
        if (!ready) return false
        val locale = Locale.forLanguageTag(languageTag.ifBlank { "en-IN" })
        val result = runCatching { engine.isLanguageAvailable(locale) }.getOrDefault(-1)
        return result >= TextToSpeech.LANG_AVAILABLE
    }

    fun repeatLast() {
        if (lastSpokenText.isNotBlank()) {
            speak(lastSpokenText, lastLanguageTag, lastRate)
        }
    }

    fun stop() {
        engine?.stop()
    }

    fun shutdown() {
        engine?.stop()
        engine?.shutdown()
        engine = null
        ready = false
    }

    private fun handleInit(status: Int) {
        val engine = this.engine
        if (status != TextToSpeech.SUCCESS || engine == null) {
            ready = false
            onError?.invoke(AssistantError.TTS_UNAVAILABLE)
            return
        }
        ready = true
        engine.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = Unit

            override fun onDone(utteranceId: String?) {
                mainHandler.post { onDone?.invoke() }
            }

            override fun onError(utteranceId: String?) {
                mainHandler.post { onError?.invoke(AssistantError.TTS_UNAVAILABLE) }
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                mainHandler.post { onError?.invoke(AssistantError.TTS_UNAVAILABLE) }
            }
        })
        pending?.let { queued ->
            pending = null
            deliver(engine, queued.text, queued.languageTag, queued.rate)
        }
    }

    private fun deliver(engine: TextToSpeech, text: String, languageTag: String, rate: Float) {
        val requested = Locale.forLanguageTag(languageTag.ifBlank { "en-IN" })
        var result = engine.setLanguage(requested)
        lastLanguageTag = languageTag
        lastRate = rate

        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            val hindi = Locale.forLanguageTag("hi-IN")
            if (engine.setLanguage(hindi) >= TextToSpeech.LANG_AVAILABLE) {
                onLanguageFallback?.invoke(requested.toLanguageTag(), hindi.toLanguageTag())
            } else if (containsNonLatin(text)) {
                // An English voice reading Devanagari or Tamil is unlistenable;
                // better to stay quiet and show the text than to garble it.
                onLanguageMissing?.invoke(requested.toLanguageTag())
                return
            } else {
                engine.setLanguage(Locale.forLanguageTag("en-IN"))
                onLanguageFallback?.invoke(requested.toLanguageTag(), "en-IN")
            }
        }

        // Prefer the highest-quality offline voice the phone has for this
        // language: the default one is often the thin, harsh legacy voice.
        runCatching {
            val target = engine.language ?: requested
            engine.voices
                ?.filter { it.locale.language == target.language && !it.isNetworkConnectionRequired }
                ?.maxByOrNull { it.quality }
                ?.let { engine.voice = it }
        }

        engine.setSpeechRate(rate.coerceIn(0.5f, 2.0f))
        engine.setPitch(1.06f)
        val utteranceId = "madhuri-" + System.nanoTime()
        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
        }
        val started = engine.speak(text, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
        if (started != TextToSpeech.SUCCESS) {
            onError?.invoke(AssistantError.TTS_UNAVAILABLE)
        }
    }

    private fun containsNonLatin(text: String): Boolean = text.any { it.code > 0x024F }

    private var lastLanguageTag: String = "en-IN"
    private var lastRate: Float = 1.0f
}
