package com.codemaster.madhuri.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.codemaster.madhuri.appContainer
import com.codemaster.madhuri.model.AppSettings
import androidx.compose.ui.platform.LocalContext

private val DarkColors = darkColorScheme(
    primary = VioletPrimary,
    onPrimary = Color(0xFF16082E),
    primaryContainer = VioletDeep,
    onPrimaryContainer = Color.White,
    secondary = CyanSecondary,
    onSecondary = Color(0xFF00202A),
    tertiary = PinkTertiary,
    onTertiary = Color(0xFF2B0020),
    background = NightBackground,
    onBackground = Color(0xFFEDE8FA),
    surface = NightSurface,
    onSurface = Color(0xFFEDE8FA),
    surfaceVariant = NightSurfaceHigh,
    onSurfaceVariant = Color(0xFFC7BEE0),
    outline = NightOutline,
    error = ErrorRed,
    onError = Color(0xFF3B0010)
)

private val LightColors = lightColorScheme(
    primary = VioletDeep,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE4D9FF),
    onPrimaryContainer = Color(0xFF21005D),
    secondary = Color(0xFF007A8A),
    onSecondary = Color.White,
    tertiary = Color(0xFFB0207F),
    onTertiary = Color.White,
    background = DayBackground,
    onBackground = Color(0xFF1B1430),
    surface = DaySurface,
    onSurface = Color(0xFF1B1430),
    surfaceVariant = DaySurfaceHigh,
    onSurfaceVariant = Color(0xFF4A4160),
    outline = DayOutline,
    error = Color(0xFFB3123C),
    onError = Color.White
)

@Composable
fun MadhuriTheme(content: @Composable () -> Unit) {
    val context = LocalContext.current
    val settings by context.appContainer.settingsRepository.settings
        .collectAsStateWithLifecycle(initialValue = AppSettings())

    val darkTheme = when (settings.themeMode) {
        AppSettings.THEME_DARK -> true
        AppSettings.THEME_LIGHT -> false
        else -> isSystemInDarkTheme()
    }

    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = MadhuriTypography,
        content = content
    )
}
