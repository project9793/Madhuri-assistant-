package com.codemaster.madhuri.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.codemaster.madhuri.appContainer
import com.codemaster.madhuri.model.AppSettings
import androidx.compose.ui.platform.LocalContext

private val DarkColors = darkColorScheme(
    primary = AccentPink,
    onPrimary = Color.White,
    primaryContainer = AccentPinkDeep,
    onPrimaryContainer = Color.White,
    secondary = AccentPinkSoft,
    onSecondary = Color(0xFF3A0016),
    tertiary = AccentViolet,
    onTertiary = Color.White,
    background = NightBackground,
    onBackground = Color(0xFFF4F2F7),
    surface = NightSurface,
    onSurface = Color(0xFFF4F2F7),
    surfaceVariant = NightSurfaceHigh,
    onSurfaceVariant = NightTextSecondary,
    outline = NightOutline,
    error = ErrorRed,
    onError = Color.White
)

private val LightColors = lightColorScheme(
    primary = AccentPinkDeep,
    onPrimary = Color.White,
    primaryContainer = AccentPinkSoft,
    onPrimaryContainer = Color(0xFF3A0016),
    secondary = AccentViolet,
    onSecondary = Color.White,
    tertiary = AccentPinkSoft,
    onTertiary = Color(0xFF3A0016),
    background = DayBackground,
    onBackground = Color(0xFF1B1720),
    surface = DaySurface,
    onSurface = Color(0xFF1B1720),
    surfaceVariant = DaySurfaceHigh,
    onSurfaceVariant = DayTextSecondary,
    outline = DayOutline,
    error = ErrorRed,
    onError = Color.White
)

@Composable
fun MadhuriTheme(content: @Composable () -> Unit) {
    val context = LocalContext.current
    val settings by context.appContainer.settingsRepository.settings
        .collectAsStateWithLifecycle(initialValue = AppSettings())

    val darkTheme = when (settings.themeMode) {
        AppSettings.THEME_DARK -> true
        AppSettings.THEME_LIGHT -> false
        else -> isSystemInDarkTheme()
    }

    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = MadhuriTypography,
        content = content
    )
}
