package com.codemaster.madhuri.data

import android.content.Context
import com.codemaster.madhuri.model.ChatMessage
import com.codemaster.madhuri.model.ChatSession
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Chats are stored as one JSON file per session in the app's private files
 * directory. It is deliberately simple: no database, no code generation, and it
 * keeps everything on the device. Swapping this for Room or a Firebase-backed
 * implementation only means reimplementing this class.
 */
class ChatRepository(private val context: Context) {

    private val directory: File
        get() = File(context.filesDir, "chats").apply { if (!exists()) mkdirs() }

    suspend fun listSessions(): List<ChatSession> = withContext(Dispatchers.IO) {
        directory.listFiles()
            ?.filter { it.isFile && it.name.endsWith(".json") }
            ?.mapNotNull { file -> readSession(file) }
            ?.sortedByDescending { it.updatedAt }
            ?: emptyList()
    }

    suspend fun load(id: String): ChatSession? = withContext(Dispatchers.IO) {
        readSession(File(directory, "$id.json"))
    }

    suspend fun save(session: ChatSession) = withContext(Dispatchers.IO) {
        val payload = JSONObject().apply {
            put("id", session.id)
            put("title", session.title)
            put("createdAt", session.createdAt)
            put("updatedAt", session.updatedAt)
            put("messages", JSONArray().apply {
                session.messages.forEach { put(it.toJson()) }
            })
        }
        File(directory, "${session.id}.json").writeText(payload.toString())
    }

    suspend fun delete(id: String) = withContext(Dispatchers.IO) {
        File(directory, "$id.json").delete()
        Unit
    }

    suspend fun deleteAll() = withContext(Dispatchers.IO) {
        directory.listFiles()?.forEach { it.delete() }
        Unit
    }

    private fun readSession(file: File): ChatSession? {
        if (!file.exists()) return null
        return runCatching {
            val json = JSONObject(file.readText())
            val messages = json.optJSONArray("messages")?.let { array ->
                (0 until array.length()).mapNotNull { index ->
                    array.optJSONObject(index)?.let(ChatMessage::fromJson)
                }
            } ?: emptyList()
            ChatSession(
                id = json.optString("id", file.nameWithoutExtension),
                title = json.optString("title", "Chat"),
                createdAt = json.optLong("createdAt", file.lastModified()),
                updatedAt = json.optLong("updatedAt", file.lastModified()),
                messages = messages
            )
        }.getOrNull()
    }
}
