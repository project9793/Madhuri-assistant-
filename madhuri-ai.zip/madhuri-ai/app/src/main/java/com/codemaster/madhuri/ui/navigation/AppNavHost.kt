package com.codemaster.madhuri.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.codemaster.madhuri.ui.chat.ChatScreen
import com.codemaster.madhuri.ui.history.HistoryScreen
import com.codemaster.madhuri.ui.home.HomeScreen
import com.codemaster.madhuri.ui.settings.SettingsScreen

object Routes {
    const val HOME = "home"
    const val HISTORY = "history"
    const val SETTINGS = "settings"
    const val CHAT = "chat?sessionId={sessionId}&preset={preset}"

    fun chat(sessionId: String = "new", preset: String = ""): String =
        "chat?sessionId=$sessionId&preset=$preset"
}

@Composable
fun AppRoot() {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val showBottomBar = currentRoute == Routes.HOME ||
        currentRoute == Routes.HISTORY ||
        currentRoute == Routes.SETTINGS

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (showBottomBar) {
                MadhuriBottomBar(
                    currentRoute = currentRoute,
                    onHome = { navController.switchTab(Routes.HOME) },
                    onChat = { navController.navigate(Routes.chat()) },
                    onHistory = { navController.switchTab(Routes.HISTORY) },
                    onSettings = { navController.switchTab(Routes.SETTINGS) }
                )
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Routes.HOME,
            modifier = Modifier.padding(padding)
        ) {
            composable(Routes.HOME) {
                HomeScreen(
                    onOpenChat = { preset -> navController.navigate(Routes.chat(preset = preset)) },
                    onOpenSettings = { navController.switchTab(Routes.SETTINGS) }
                )
            }

            composable(
                route = Routes.CHAT,
                arguments = listOf(
                    navArgument("sessionId") {
                        type = NavType.StringType
                        defaultValue = "new"
                    },
                    navArgument("preset") {
                        type = NavType.StringType
                        defaultValue = ""
                    }
                )
            ) { entry ->
                ChatScreen(
                    preset = entry.arguments?.getString("preset").orEmpty(),
                    sessionId = entry.arguments?.getString("sessionId") ?: "new",
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Routes.HISTORY) {
                HistoryScreen(
                    onOpenChat = { sessionId ->
                        navController.navigate(Routes.chat(sessionId = sessionId))
                    }
                )
            }

            composable(Routes.SETTINGS) {
                SettingsScreen()
            }
        }
    }
}

private fun NavHostController.switchTab(route: String) {
    navigate(route) {
        popUpTo(Routes.HOME) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
private fun MadhuriBottomBar(
    currentRoute: String?,
    onHome: () -> Unit,
    onChat: () -> Unit,
    onHistory: () -> Unit,
    onSettings: () -> Unit
) {
    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
        BottomItem("Home", Icons.Filled.Home, currentRoute == Routes.HOME, onHome)
        BottomItem("Chat", Icons.Filled.Email, currentRoute == Routes.CHAT, onChat)
        BottomItem("History", Icons.Filled.List, currentRoute == Routes.HISTORY, onHistory)
        BottomItem("Settings", Icons.Filled.Settings, currentRoute == Routes.SETTINGS, onSettings)
    }
}

@Composable
private fun BottomItem(
    label: String,
    icon: ImageVector,
    selected: Boolean,
    onClick: () -> Unit
) {
    NavigationBarItem(
        selected = selected,
        onClick = onClick,
        icon = { Icon(icon, contentDescription = label) },
        label = { Text(label) }
    )
}
