package com.codemaster.madhuri.ui.navigation

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.codemaster.madhuri.ui.chat.ChatScreen
import com.codemaster.madhuri.ui.history.HistoryScreen
import com.codemaster.madhuri.ui.home.HomeScreen
import com.codemaster.madhuri.ui.components.MicGlyph
import com.codemaster.madhuri.ui.settings.SettingsScreen
import com.codemaster.madhuri.ui.theme.AccentPink
import com.codemaster.madhuri.ui.theme.AccentPinkSoft

object Routes {
    const val HOME = "home?listen={listen}"

    fun home(listen: Boolean = false): String = "home?listen=$listen"
    const val HISTORY = "history"
    const val SETTINGS = "settings?tab={tab}"

    fun settings(tab: Int = 0): String = "settings?tab=$tab"
    const val CHAT = "chat?sessionId={sessionId}&preset={preset}"

    fun chat(sessionId: String = "new", preset: String = ""): String =
        "chat?sessionId=$sessionId&preset=$preset"
}

@Composable
fun AppRoot() {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val showBottomBar = currentRoute == Routes.HOME ||
        currentRoute == Routes.HISTORY ||
        currentRoute == Routes.SETTINGS

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (showBottomBar) {
                MadhuriBottomBar(
                    currentRoute = currentRoute,
                    onHome = { navController.switchTab(Routes.home()) },
                    onChat = { navController.navigate(Routes.chat()) },
                    onHistory = { navController.switchTab(Routes.HISTORY) },
                    onSettings = { navController.switchTab(Routes.settings(0)) },
                    onTalk = {
                        navController.navigate(Routes.home(listen = true)) {
                            popUpTo(Routes.HOME) { inclusive = false }
                            launchSingleTop = true
                        }
                    }
                )
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Routes.home(),
            modifier = Modifier.padding(padding)
        ) {
            composable(
                route = Routes.HOME,
                arguments = listOf(
                    navArgument("listen") {
                        type = NavType.BoolType
                        defaultValue = false
                    }
                )
            ) { entry ->
                HomeScreen(
                    listenOnStart = entry.arguments?.getBoolean("listen") ?: false,
                    onOpenChat = { preset -> navController.navigate(Routes.chat(preset = preset)) },
                    onOpenSettings = { tab -> navController.navigate(Routes.settings(tab)) }
                )
            }

            composable(
                route = Routes.CHAT,
                arguments = listOf(
                    navArgument("sessionId") {
                        type = NavType.StringType
                        defaultValue = "new"
                    },
                    navArgument("preset") {
                        type = NavType.StringType
                        defaultValue = ""
                    }
                )
            ) { entry ->
                ChatScreen(
                    preset = entry.arguments?.getString("preset").orEmpty(),
                    sessionId = entry.arguments?.getString("sessionId") ?: "new",
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Routes.HISTORY) {
                HistoryScreen(
                    onOpenChat = { sessionId ->
                        navController.navigate(Routes.chat(sessionId = sessionId))
                    }
                )
            }

            composable(
                route = Routes.SETTINGS,
                arguments = listOf(
                    navArgument("tab") {
                        type = NavType.IntType
                        defaultValue = 0
                    }
                )
            ) { entry ->
                SettingsScreen(initialTab = entry.arguments?.getInt("tab") ?: 0)
            }
        }
    }
}

private fun NavHostController.switchTab(route: String) {
    navigate(route) {
        popUpTo(Routes.HOME) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
private fun MadhuriBottomBar(
    currentRoute: String?,
    onHome: () -> Unit,
    onChat: () -> Unit,
    onHistory: () -> Unit,
    onSettings: () -> Unit,
    onTalk: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = RoundedCornerShape(32.dp),
            color = Color(0xFF131217),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.07f)),
            shadowElevation = 18.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(68.dp)
                    .padding(horizontal = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BottomItem("Home", Icons.Filled.Home, currentRoute == Routes.HOME, Modifier.weight(1f), onHome)
                BottomItem("Chat", Icons.Filled.Email, currentRoute == Routes.CHAT, Modifier.weight(1f), onChat)
                Spacer(Modifier.weight(1f))
                BottomItem("History", Icons.Filled.List, currentRoute == Routes.HISTORY, Modifier.weight(1f), onHistory)
                BottomItem("Settings", Icons.Filled.Settings, currentRoute == Routes.SETTINGS, Modifier.weight(1f), onSettings)
            }
        }
        Box(
            modifier = Modifier
                .size(58.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(AccentPinkSoft, AccentPink)))
                .clickable(onClick = onTalk),
            contentAlignment = Alignment.Center
        ) {
            MicGlyph(tint = Color.White, modifier = Modifier.size(26.dp))
        }
    }
}

@Composable
private fun RowScope.BottomItem(
    label: String,
    icon: ImageVector,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (selected) AccentPink else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(22.dp)
        )
        Spacer(Modifier.height(3.dp))
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            color = if (selected) AccentPink else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
