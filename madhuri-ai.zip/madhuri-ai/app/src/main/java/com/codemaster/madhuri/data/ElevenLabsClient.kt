package com.codemaster.madhuri.data

import com.codemaster.madhuri.model.AssistantError
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * ElevenLabs text-to-speech.
 *
 * This is the voice the user liked in the reference app: noticeably warmer than
 * the phone engine and faster than a full Gemini round trip when the flash model
 * is used.
 */
object ElevenLabsClient {

    const val BASE = "https://api.elevenlabs.io/v1"

    /** Rachel — a warm, natural female voice that speaks Hindi well. */
    const val DEFAULT_VOICE_ID = "21m00Tcm4TlvDq8ikWAM"

    /** Flash is the lowest-latency model; multilingual handles Indian languages. */
    const val MODEL_FLASH = "eleven_flash_v2_5"
    const val MODEL_TURBO = "eleven_turbo_v2_5"
    const val MODEL_MULTILINGUAL = "eleven_multilingual_v2"

    data class Spoken(val bytes: ByteArray, val mimeType: String)

    suspend fun synthesize(
        apiKey: String,
        voiceId: String,
        modelId: String,
        text: String
    ): Result<Spoken> = withContext(Dispatchers.IO) {
        var connection: HttpURLConnection? = null
        try {
            val id = voiceId.ifBlank { DEFAULT_VOICE_ID }
            val url = URL("$BASE/text-to-speech/$id?output_format=mp3_44100_128")
            connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 20_000
                readTimeout = 60_000
                doOutput = true
                setRequestProperty("xi-api-key", apiKey)
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Accept", "audio/mpeg")
            }
            val body = JSONObject().apply {
                put("text", text.take(2_500))
                put("model_id", modelId.ifBlank { MODEL_FLASH })
                put(
                    "voice_settings",
                    JSONObject().apply {
                        put("stability", 0.45)
                        put("similarity_boost", 0.8)
                        put("style", 0.15)
                        put("use_speaker_boost", true)
                    }
                )
            }
            connection.outputStream.use { it.write(body.toString().toByteArray()) }

            val code = connection.responseCode
            if (code !in 200..299) {
                val payload = connection.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                val message = runCatching {
                    JSONObject(payload).optJSONObject("detail")?.optString("message")
                        ?: JSONObject(payload).optString("message")
                }.getOrNull()
                return@withContext Result.failure(
                    GeminiException(
                        when (code) {
                            401, 403 -> AssistantError.INVALID_API_KEY
                            429 -> AssistantError.QUOTA_EXCEEDED
                            else -> AssistantError.UNKNOWN
                        },
                        "elevenlabs HTTP $code: $payload",
                        "elevenlabs: " + (message?.take(140) ?: "HTTP $code")
                    )
                )
            }

            val bytes = connection.inputStream.readBytes()
            if (bytes.size < 1_000) {
                Result.failure(
                    GeminiException(
                        AssistantError.UNKNOWN,
                        "elevenlabs returned no audio",
                        "elevenlabs: empty audio"
                    )
                )
            } else {
                Result.success(Spoken(bytes, "audio/mpeg"))
            }
        } catch (e: IOException) {
            Result.failure(
                GeminiException(AssistantError.NETWORK, e.message ?: "elevenlabs network", "elevenlabs: network")
            )
        } catch (e: Exception) {
            Result.failure(
                GeminiException(AssistantError.UNKNOWN, e.message ?: "elevenlabs failed", "elevenlabs: ${e.message}")
            )
        } finally {
            connection?.disconnect()
        }
    }

    /** Checks the key and returns how many voices it can see. */
    suspend fun testKey(apiKey: String): Int? = withContext(Dispatchers.IO) {
        var connection: HttpURLConnection? = null
        try {
            connection = (URL("$BASE/voices").openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 15_000
                readTimeout = 20_000
                setRequestProperty("xi-api-key", apiKey)
            }
            if (connection.responseCode !in 200..299) return@withContext null
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            JSONObject(body).optJSONArray("voices")?.length() ?: 0
        } catch (e: Exception) {
            null
        } finally {
            connection?.disconnect()
        }
    }
}
