package com.codemaster.madhuri.voice

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Plays the PCM audio Gemini's speech models return. The bytes are wrapped in a
 * small WAV container and written to the cache directory, then handed to
 * MediaPlayer — that keeps audio focus, volume and interruption behaviour the
 * same as any other sound on the phone.
 */
class GeminiSpeaker(private val context: Context) {

    var onDone: (() -> Unit)? = null
    var onError: ((String) -> Unit)? = null

    private val mainHandler = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null
    private var currentFile: File? = null

    val isSpeaking: Boolean get() = player?.isPlaying == true

    fun playAudio(bytes: ByteArray, mimeType: String) {
        stop()
        if (bytes.isEmpty()) {
            onError?.invoke("the speech model returned no audio")
            return
        }
        val (payload, extension) = normalise(bytes, mimeType)
        val file = File(context.cacheDir, "madhuri_voice_${System.nanoTime()}.$extension")
        val written = runCatching {
            file.writeBytes(payload)
            true
        }.getOrDefault(false)
        if (!written) {
            onError?.invoke("could not write the audio file")
            return
        }
        currentFile = file

        val mp = MediaPlayer()
        player = mp
        try {
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            mp.setDataSource(file.absolutePath)
            mp.setOnCompletionListener {
                mainHandler.post {
                    release()
                    onDone?.invoke()
                }
            }
            mp.setOnErrorListener { _, _, _ ->
                mainHandler.post {
                    release()
                    onError?.invoke("the audio could not be played")
                }
                true
            }
            mp.prepare()
            mp.start()
        } catch (e: Exception) {
            release()
            onError?.invoke("playback failed: ${e.message ?: "unknown"}")
        }
    }

    fun stop() {
        val mp = player
        player = null
        if (mp != null) {
            runCatching { if (mp.isPlaying) mp.stop() }
            runCatching { mp.release() }
        }
        currentFile?.let { runCatching { it.delete() } }
        currentFile = null
    }

    fun shutdown() = stop()

    private fun release() {
        val mp = player
        player = null
        runCatching { mp?.release() }
        currentFile?.let { runCatching { it.delete() } }
        currentFile = null
    }

    /**
     * Gemini sometimes returns raw PCM and sometimes a finished container. Only
     * raw PCM may be wrapped in a WAV header; wrapping an MP3 or an existing WAV
     * is exactly what produces that harsh crackle.
     */
    private fun normalise(bytes: ByteArray, mimeType: String): Pair<ByteArray, String> {
        val header = String(bytes, 0, minOf(4, bytes.size), Charsets.US_ASCII)
        return when {
            header.startsWith("RIFF") -> bytes to "wav"
            header.startsWith("OggS") -> bytes to "ogg"
            header.startsWith("fLaC") -> bytes to "flac"
            header.startsWith("ID3") -> bytes to "mp3"
            bytes.size > 1 && bytes[0] == 0xFF.toByte() && (bytes[1].toInt() and 0xE0) == 0xE0 ->
                bytes to "mp3"

            else -> {
                val rate = Regex("rate=(\\d+)").find(mimeType)?.groupValues?.get(1)?.toIntOrNull()
                    ?: 24_000
                wrapAsWav(bytes, rate) to "wav"
            }
        }
    }

    private fun wrapAsWav(pcm: ByteArray, sampleRate: Int): ByteArray {
        val header = ByteArray(44)
        val byteRate = sampleRate * 2
        fun ascii(offset: Int, value: String) {
            value.toByteArray(Charsets.US_ASCII).copyInto(header, offset)
        }
        fun int(offset: Int, value: Int) {
            ByteBuffer.wrap(header, offset, 4).order(ByteOrder.LITTLE_ENDIAN).putInt(value)
        }
        fun short(offset: Int, value: Int) {
            ByteBuffer.wrap(header, offset, 2).order(ByteOrder.LITTLE_ENDIAN).putShort(value.toShort())
        }
        ascii(0, "RIFF")
        int(4, pcm.size + 36)
        ascii(8, "WAVE")
        ascii(12, "fmt ")
        int(16, 16)
        short(20, 1)
        short(22, 1)
        int(24, sampleRate)
        int(28, byteRate)
        short(32, 2)
        short(34, 16)
        ascii(36, "data")
        int(40, pcm.size)

        val out = ByteArray(header.size + pcm.size)
        header.copyInto(out, 0)
        pcm.copyInto(out, header.size)
        return out
    }
}
