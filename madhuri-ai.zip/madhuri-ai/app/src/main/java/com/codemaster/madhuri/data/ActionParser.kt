package com.codemaster.madhuri.data

import com.codemaster.madhuri.model.DeviceAction
import org.json.JSONObject

/**
 * Pulls the machine-readable blocks out of a model reply. The model is told to
 * use `<<ACTION>>…<</ACTION>>` and `<<MEMORY>>…<</MEMORY>>`; a fenced
 * ```action block is also accepted because models drift.
 */
object ActionParser {

    private val actionMarker = Regex(
        "<<ACTION>>(.*?)<</ACTION>>",
        setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)
    )
    private val memoryMarker = Regex(
        "<<MEMORY>>(.*?)<</MEMORY>>",
        setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)
    )
    private val actionFence = Regex(
        "```action\\s*(.*?)```",
        setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)
    )

    fun parseActions(raw: String): List<DeviceAction> {
        val payloads = actionMarker.findAll(raw).map { it.groupValues[1] }.toMutableList()
        payloads += actionFence.findAll(raw).map { it.groupValues[1] }
        return payloads.mapNotNull { payload ->
            runCatching { DeviceAction.fromJson(JSONObject(payload.trim())) }.getOrNull()
        }.filter { it.type.isNotBlank() }
    }

    fun parseMemory(raw: String): List<String> = memoryMarker.findAll(raw)
        .map { it.groupValues[1].trim() }
        .filter { it.isNotEmpty() && it.length <= 300 }
        .toList()

    /** The reply as it should be shown and spoken: markers removed. */
    fun strip(raw: String): String = raw
        .replace(actionMarker, "")
        .replace(memoryMarker, "")
        .replace(actionFence, "")
        .trim()
}
