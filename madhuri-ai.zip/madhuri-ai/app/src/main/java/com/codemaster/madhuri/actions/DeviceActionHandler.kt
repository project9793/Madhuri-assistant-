package com.codemaster.madhuri.actions

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.codemaster.madhuri.model.DeviceAction
import java.net.URLEncoder

/**
 * Executes the permitted Android actions. Anything that calls, texts or messages
 * a person is flagged by [requiresConfirmation] and the UI asks the user first.
 */
class DeviceActionHandler(private val context: Context) {

    data class Outcome(val message: String, val success: Boolean)

    fun requiresConfirmation(action: DeviceAction): Boolean =
        action.type in CONFIRM_REQUIRED_TYPES

    fun execute(action: DeviceAction): Outcome = try {
        when (action.type) {
            "open_app" -> openApp(action.app)
            "open_url" -> openUrl(action.url)
            "search_web" -> openUrl("https://www.google.com/search?q=" + encode(action.query.orEmpty()))
            "search_youtube" ->
                openUrl("https://www.youtube.com/results?search_query=" + encode(action.query.orEmpty()))

            "dial" -> dial(action.number)
            "call" -> call(action.number)
            "call_contact" -> callContact(action.name)
            "sms" -> composeSms(action.number, action.message)
            "whatsapp" -> whatsapp(action.number, action.message)
            "set_alarm" -> setAlarm(action.hour ?: 7, action.minute ?: 0, action.label)
            "set_reminder" -> setReminder(action.label ?: action.text ?: "Reminder")
            "set_volume" -> setVolume(action.percent ?: 50)
            "open_settings" -> openSettings(action.screen)
            "share_text" -> shareText(action.text.orEmpty())
            "open_camera" -> launch(
                Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA),
                "Camera opened."
            )

            "open_gallery" -> launch(
                Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI),
                "Gallery opened."
            )

            else -> Outcome("I don't know how to do \"${action.type}\" yet.", false)
        }
    } catch (e: ActivityNotFoundException) {
        Outcome("Nothing on this phone can handle that.", false)
    } catch (e: SecurityException) {
        Outcome("That needs a permission this app does not have yet.", false)
    } catch (e: Exception) {
        Outcome("I couldn't do that: ${e.message ?: "unknown error"}.", false)
    }

    private fun openApp(appName: String?): Outcome {
        val key = appName?.trim()?.lowercase().orEmpty()
        when (key) {
            "", "app" -> return showAppChooser()
            "settings" -> return launch(Intent(Settings.ACTION_SETTINGS), "Settings opened.")
            "camera" -> return launch(
                Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA),
                "Camera opened."
            )

            "gallery" -> return launch(
                Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI),
                "Gallery opened."
            )
        }
        val packageName = KNOWN_APPS[key]
            ?: KNOWN_APPS.entries.firstOrNull { key.contains(it.key) || it.key.contains(key) }?.value
        if (packageName != null) {
            val intent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                return Outcome("Opening ${prettyName(key)}.", true)
            }
        }
        return showAppChooser()
    }

    private fun showAppChooser(): Outcome {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(Intent.createChooser(intent, "Open with").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return Outcome("I couldn't find that app installed, so I opened your app list.", false)
    }

    private fun openUrl(url: String?): Outcome {
        val clean = url?.trim().orEmpty()
        if (clean.isBlank()) return Outcome("I need a link for that.", false)
        val normalised = if (clean.startsWith("http")) clean else "https://$clean"
        return launch(Intent(Intent.ACTION_VIEW, Uri.parse(normalised)), "Opening $normalised.")
    }

    private fun dial(number: String?): Outcome {
        val clean = number?.trim().orEmpty()
        if (clean.isBlank()) return Outcome("I need a number to dial.", false)
        return launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(clean))), "Dialer opened.")
    }

    private fun call(number: String?): Outcome {
        val clean = number?.trim().orEmpty()
        if (clean.isBlank()) return Outcome("I need a number to call.", false)
        val hasPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED
        return if (hasPermission) {
            launch(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(clean))), "Calling $clean.")
        } else {
            launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(clean))), "Dialer opened for $clean.")
        }
    }

    private fun callContact(name: String?): Outcome {
        val contactName = name?.trim().orEmpty()
        if (contactName.isBlank()) return Outcome("Whom should I call?", false)
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return Outcome("I need contacts permission before I can look people up.", false)
        }
        val number = findNumber(contactName)
            ?: return Outcome("I couldn't find \"$contactName\" in your contacts.", false)
        return call(number)
    }

    private fun findNumber(name: String): String? {
        val projection = arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER)
        val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        return context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            projection,
            selection,
            arrayOf("%$name%"),
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        }
    }

    private fun composeSms(number: String?, message: String?): Outcome {
        val clean = number?.trim().orEmpty()
        if (clean.isBlank()) return Outcome("I need a number to text.", false)
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(clean))).apply {
            putExtra("sms_body", message.orEmpty())
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return Outcome("Message draft ready for $clean.", true)
    }

    private fun whatsapp(number: String?, message: String?): Outcome {
        val digits = number?.filter { it.isDigit() }.orEmpty()
        val intent = if (digits.isBlank()) {
            context.packageManager.getLaunchIntentForPackage("com.whatsapp")
        } else {
            Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://wa.me/$digits?text=" + encode(message.orEmpty()))
            )
        }
        if (intent == null) return Outcome("WhatsApp is not installed on this phone.", false)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return Outcome("WhatsApp draft ready.", true)
    }

    private fun setAlarm(hour: Int, minute: Int, label: String?): Outcome {
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour.coerceIn(0, 23))
            putExtra(AlarmClock.EXTRA_MINUTES, minute.coerceIn(0, 59))
            putExtra(AlarmClock.EXTRA_MESSAGE, label ?: "Madhuri reminder")
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return Outcome(String.format("Alarm set for %02d:%02d.", hour, minute), true)
    }

    private fun setReminder(title: String): Outcome {
        val begin = System.currentTimeMillis() + 60 * 60 * 1000L
        val intent = Intent(Intent.ACTION_INSERT).apply {
            data = CalendarContract.Events.CONTENT_URI
            putExtra(CalendarContract.Events.TITLE, title)
            putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, begin)
            putExtra(CalendarContract.EXTRA_EVENT_END_TIME, begin + 30 * 60 * 1000L)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return Outcome("Calendar entry ready: \"$title\".", true)
    }

    private fun setVolume(percent: Int): Outcome {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            ?: return Outcome("I can't reach the volume controls on this phone.", false)
        val stream = AudioManager.STREAM_MUSIC
        val max = audio.getStreamMaxVolume(stream)
        val target = (max * percent.coerceIn(0, 100) / 100f).toInt().coerceIn(0, max)
        audio.setStreamVolume(stream, target, 0)
        return Outcome("Media volume set to $percent%.", true)
    }

    private fun openSettings(screen: String?): Outcome {
        val action = when (screen?.trim()?.lowercase()) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        return launch(Intent(action), "Settings opened.")
    }

    private fun shareText(text: String): Outcome {
        if (text.isBlank()) return Outcome("There is nothing to share.", false)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        context.startActivity(
            Intent.createChooser(intent, "Share via").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return Outcome("Share sheet opened.", true)
    }

    private fun launch(intent: Intent, successMessage: String): Outcome {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return Outcome(successMessage, true)
    }

    private fun encode(value: String): String = URLEncoder.encode(value, "UTF-8")

    private fun prettyName(key: String): String = key.replaceFirstChar { it.uppercase() }

    companion object {
        private val CONFIRM_REQUIRED_TYPES = setOf("call", "call_contact", "sms", "whatsapp")

        /**
         * Apps Madhuri can open by name. Each package is also declared in the
         * manifest's <queries> block, which is what Android 11+ requires for
         * package visibility. No QUERY_ALL_PACKAGES permission is used.
         */
        private val KNOWN_APPS = mapOf(
            "whatsapp" to "com.whatsapp",
            "youtube" to "com.google.android.youtube",
            "gmail" to "com.google.android.gm",
            "maps" to "com.google.android.apps.maps",
            "chrome" to "com.android.chrome",
            "browser" to "com.android.chrome",
            "photos" to "com.google.android.apps.photos",
            "instagram" to "com.instagram.android",
            "facebook" to "com.facebook.katana",
            "dialer" to "com.google.android.dialer",
            "phone" to "com.google.android.dialer",
            "calendar" to "com.google.android.calendar",
            "spotify" to "com.spotify.music",
            "telegram" to "org.telegram.messenger",
            "docs" to "com.google.android.apps.docs",
            "files" to "com.google.android.apps.nbu.files"
        )
    }
}
