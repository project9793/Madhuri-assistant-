package com.codemaster.madhuri.model

import org.json.JSONObject
import java.util.UUID

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val role: Role,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val imageBase64: String? = null,
    val imageMimeType: String? = null
) {
    enum class Role { USER, ASSISTANT }

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("role", role.name)
        put("text", text)
        put("timestamp", timestamp)
        if (imageBase64 != null) put("imageBase64", imageBase64)
        if (imageMimeType != null) put("imageMimeType", imageMimeType)
    }

    companion object {
        fun fromJson(json: JSONObject): ChatMessage = ChatMessage(
            id = json.optString("id", UUID.randomUUID().toString()),
            role = if (json.optString("role") == Role.USER.name) Role.USER else Role.ASSISTANT,
            text = json.optString("text"),
            timestamp = json.optLong("timestamp", System.currentTimeMillis()),
            imageBase64 = if (json.has("imageBase64")) json.optString("imageBase64") else null,
            imageMimeType = if (json.has("imageMimeType")) json.optString("imageMimeType") else null
        )
    }
}

data class ChatSession(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "New chat",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val messages: List<ChatMessage> = emptyList()
) {
    fun preview(): String =
        messages.lastOrNull { it.role == ChatMessage.Role.ASSISTANT }?.text
            ?: messages.lastOrNull()?.text
            ?: "No messages yet"
}

data class MemoryEntry(
    val id: String = UUID.randomUUID().toString(),
    val content: String,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("content", content)
        put("createdAt", createdAt)
    }

    companion object {
        fun fromJson(json: JSONObject): MemoryEntry = MemoryEntry(
            id = json.optString("id", UUID.randomUUID().toString()),
            content = json.optString("content"),
            createdAt = json.optLong("createdAt", System.currentTimeMillis())
        )
    }
}
