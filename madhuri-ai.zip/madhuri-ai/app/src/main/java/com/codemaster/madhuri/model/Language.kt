package com.codemaster.madhuri.model

/**
 * Languages Madhuri can listen and speak in. The tag is a BCP-47 code handed to
 * the speech services; [indian] only drives how the picker groups them.
 *
 * Every one of India's 22 scheduled languages is here, plus widely spoken ones
 * that are not scheduled (Bhojpuri, Hinglish, Rajasthani, Chhattisgarhi,
 * Haryanvi, Awadhi, Bundeli, Garhwali, Kumaoni, Magahi, Tulu, Kodava, Mizo,
 * Khasi, Sylheti, Chakma) and the languages of India's neighbours.
 */
enum class Language(
    val tag: String,
    val englishName: String,
    val nativeName: String,
    val indian: Boolean = false
) {
    AUTO("auto", "Automatic", "Automatic"),

    // ---- Indian languages ----
    ASSAMESE("as-IN", "Assamese", "অসমীয়া", true),
    AWADHI("awa-IN", "Awadhi", "अवधी", true),
    BENGALI("bn-IN", "Bengali", "বাংলা", true),
    BHOJPURI("bho-IN", "Bhojpuri", "भोजपुरी", true),
    BODO("brx-IN", "Bodo", "बर'", true),
    BUNDELI("bns-IN", "Bundeli", "बुन्देली", true),
    CHAKMA("ccp-IN", "Chakma", "𑄌𑄋𑄴𑄟𑄳𑄦", true),
    CHHATTISGARHI("hne-IN", "Chhattisgarhi", "छत्तीसगढ़ी", true),
    DOGRI("doi-IN", "Dogri", "डोगरी", true),
    ENGLISH("en-IN", "English", "English", true),
    GARHWALI("gbm-IN", "Garhwali", "गढ़वळि", true),
    GUJARATI("gu-IN", "Gujarati", "ગુજરાતી", true),
    HARYANVI("bgc-IN", "Haryanvi", "हरियाणवी", true),
    HINDI("hi-IN", "Hindi", "हिन्दी", true),
    HINGLISH("hi-Latn", "Hinglish", "Hinglish", true),
    KANNADA("kn-IN", "Kannada", "ಕನ್ನಡ", true),
    KASHMIRI("ks-IN", "Kashmiri", "کٲشُر", true),
    KHASI("kha-IN", "Khasi", "Khasi", true),
    KODAVA("kfa-IN", "Kodava", "ಕೊಡವ", true),
    KONKANI("kok-IN", "Konkani", "कोंकणी", true),
    KUMAONI("kfy-IN", "Kumaoni", "कुमाऊँनी", true),
    MAGAHI("mag-IN", "Magahi", "मगही", true),
    MAITHILI("mai-IN", "Maithili", "मैथिली", true),
    MALAYALAM("ml-IN", "Malayalam", "മലയാളം", true),
    MANIPURI("mni-IN", "Manipuri", "মৈতৈলোন্", true),
    MARATHI("mr-IN", "Marathi", "मराठी", true),
    MIZO("lus-IN", "Mizo", "Mizo ṭawng", true),
    NEPALI("ne-NP", "Nepali", "नेपाली", true),
    ODIA("or-IN", "Odia", "ଓଡ଼ିଆ", true),
    PUNJABI("pa-IN", "Punjabi", "ਪੰਜਾਬੀ", true),
    RAJASTHANI("mwr-IN", "Rajasthani", "राजस्थानी", true),
    SANSKRIT("sa-IN", "Sanskrit", "संस्कृतम्", true),
    SANTALI("sat-IN", "Santali", "ᱥᱟᱱᱛᱟᱲᱤ", true),
    SINDHI("sd-IN", "Sindhi", "سنڌي", true),
    SYLHETI("syl-IN", "Sylheti", "ꠍꠤꠟꠐꠤ", true),
    TAMIL("ta-IN", "Tamil", "தமிழ்", true),
    TELUGU("te-IN", "Telugu", "తెలుగు", true),
    TULU("tcy-IN", "Tulu", "ತುಳು", true),
    URDU("ur-IN", "Urdu", "اردو", true),

    // ---- Neighbouring countries and the rest of the world ----
    ARABIC("ar-SA", "Arabic", "العربية"),
    BALOCHI("bal-PK", "Balochi", "بلوچی"),
    BENGALI_BANGLADESH("bn-BD", "Bengali (Bangladesh)", "বাংলা"),
    BURMESE("my-MM", "Burmese", "မြန်မာ"),
    CHINESE("zh-CN", "Mandarin Chinese", "中文"),
    DARI("fa-AF", "Dari", "دری"),
    DZONGKHA("dz-BT", "Dzongkha", "རྫོང་ཁ"),
    FRENCH("fr-FR", "French", "Français"),
    GERMAN("de-DE", "German", "Deutsch"),
    HINDKO("hnd-PK", "Hindko", "ہندکو"),
    JAPANESE("ja-JP", "Japanese", "日本語"),
    KAREN("ksw-MM", "Karen", "Karen"),
    PASHTO("ps-AF", "Pashto", "پښتو"),
    PUNJABI_PAKISTAN("pa-PK", "Punjabi (Pakistan)", "پنجابی"),
    SARAIKI("skr-PK", "Saraiki", "سرائیکی"),
    SHAN("shn-MM", "Shan", "တႆး"),
    SINDHI_PAKISTAN("sd-PK", "Sindhi (Pakistan)", "سنڌي"),
    SINHALA("si-LK", "Sinhala", "සිංහල"),
    SPANISH("es-ES", "Spanish", "Español"),
    TAMIL_SRI_LANKA("ta-LK", "Tamil (Sri Lanka)", "தமிழ்"),
    TIBETAN("bo-CN", "Tibetan", "བོད་སྐད་"),
    TURKMEN("tk-TM", "Turkmen", "Türkmençe"),
    UZBEK("uz-UZ", "Uzbek", "Oʻzbekcha");

    /** Locale actually handed to speech services, never "auto". */
    val speechTag: String get() = if (this == AUTO) ENGLISH.tag else tag

    /** What to show in a list: "Hindi · हिन्दी". */
    val label: String
        get() = if (this == AUTO) "Automatic — reply in the language I use" else "$englishName · $nativeName"

    companion object {
        fun fromTag(tag: String): Language = entries.firstOrNull { it.tag == tag } ?: AUTO

        fun selectable(): List<Language> = entries.toList()

        fun indianLanguages(): List<Language> = entries.filter { it.indian }

        fun otherLanguages(): List<Language> = entries.filter { !it.indian && it != AUTO }

        /** Case-insensitive search over the English and native names. */
        fun search(query: String): List<Language> {
            val q = query.trim().lowercase()
            if (q.isEmpty()) return emptyList()
            return entries.filter {
                it != AUTO &&
                    (it.englishName.lowercase().contains(q) ||
                        it.nativeName.lowercase().contains(q) ||
                        it.tag.lowercase().contains(q))
            }
        }
    }
}
