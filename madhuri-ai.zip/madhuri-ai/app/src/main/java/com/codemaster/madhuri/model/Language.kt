package com.codemaster.madhuri.model

/**
 * Languages Madhuri can listen and speak in. The tag is a BCP-47 code that is
 * handed to both SpeechRecognizer and TextToSpeech.
 *
 * Note: Android's on-device voices do not cover every language in this list
 * (Bhojpuri in particular usually has no installed voice). [TextToSpeechManager]
 * falls back to Hindi, then English, and tells the user when that happens.
 */
enum class Language(val tag: String, val englishName: String, val nativeName: String) {
    AUTO("auto", "Automatic", "Automatic"),
    ENGLISH("en-IN", "English", "English"),
    HINDI("hi-IN", "Hindi", "हिन्दी"),
    BHOJPURI("bho-IN", "Bhojpuri", "भोजपुरी"),
    SANSKRIT("sa-IN", "Sanskrit", "संस्कृतम्"),
    URDU("ur-IN", "Urdu", "اردو"),
    BENGALI("bn-IN", "Bengali", "বাংলা"),
    MARATHI("mr-IN", "Marathi", "मराठी"),
    GUJARATI("gu-IN", "Gujarati", "ગુજરાતી"),
    PUNJABI("pa-IN", "Punjabi", "ਪੰਜਾਬੀ"),
    TAMIL("ta-IN", "Tamil", "தமிழ்"),
    TELUGU("te-IN", "Telugu", "తెలుగు"),
    KANNADA("kn-IN", "Kannada", "ಕನ್ನಡ"),
    MALAYALAM("ml-IN", "Malayalam", "മലയാളം"),
    NEPALI("ne-NP", "Nepali", "नेपाली"),
    SPANISH("es-ES", "Spanish", "Español"),
    FRENCH("fr-FR", "French", "Français"),
    GERMAN("de-DE", "German", "Deutsch"),
    JAPANESE("ja-JP", "Japanese", "日本語"),
    CHINESE("zh-CN", "Chinese", "中文"),
    ARABIC("ar-SA", "Arabic", "العربية");

    /** Locale actually handed to speech services, never "auto". */
    val speechTag: String get() = if (this == AUTO) ENGLISH.tag else tag

    companion object {
        fun fromTag(tag: String): Language = entries.firstOrNull { it.tag == tag } ?: AUTO

        /** Languages offered in the picker, in a stable display order. */
        fun selectable(): List<Language> = entries.toList()
    }
}
