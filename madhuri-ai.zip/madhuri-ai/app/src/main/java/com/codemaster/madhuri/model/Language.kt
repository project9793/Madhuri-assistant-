package com.codemaster.madhuri.model

/**
 * Languages Madhuri can listen and speak in. The tag is a BCP-47 code handed to
 * the speech services; [indian] only drives how the picker groups them.
 *
 * Every one of India's 22 scheduled languages is here, plus the widely spoken
 * ones that are not scheduled (Bhojpuri, Rajasthani, Chhattisgarhi, Haryanvi,
 * Tulu) and a handful of international languages.
 */
enum class Language(
    val tag: String,
    val englishName: String,
    val nativeName: String,
    val indian: Boolean = false
) {
    AUTO("auto", "Automatic", "Automatic"),

    // ---- Indian languages ----
    ASSAMESE("as-IN", "Assamese", "অসমীয়া", true),
    BENGALI("bn-IN", "Bengali", "বাংলা", true),
    BHOJPURI("bho-IN", "Bhojpuri", "भोजपुरी", true),
    BODO("brx-IN", "Bodo", "बर'", true),
    CHHATTISGARHI("hne-IN", "Chhattisgarhi", "छत्तीसगढ़ी", true),
    DOGRI("doi-IN", "Dogri", "डोगरी", true),
    ENGLISH("en-IN", "English", "English", true),
    GUJARATI("gu-IN", "Gujarati", "ગુજરાતી", true),
    HARYANVI("bgc-IN", "Haryanvi", "हरियाणवी", true),
    HINDI("hi-IN", "Hindi", "हिन्दी", true),
    KANNADA("kn-IN", "Kannada", "ಕನ್ನಡ", true),
    KASHMIRI("ks-IN", "Kashmiri", "کٲشُر", true),
    KONKANI("kok-IN", "Konkani", "कोंकणी", true),
    MAITHILI("mai-IN", "Maithili", "मैथिली", true),
    MALAYALAM("ml-IN", "Malayalam", "മലയാളം", true),
    MANIPURI("mni-IN", "Manipuri", "মৈতৈলোন্", true),
    MARATHI("mr-IN", "Marathi", "मराठी", true),
    NEPALI("ne-NP", "Nepali", "नेपाली", true),
    ODIA("or-IN", "Odia", "ଓଡ଼ିଆ", true),
    PUNJABI("pa-IN", "Punjabi", "ਪੰਜਾਬੀ", true),
    RAJASTHANI("mwr-IN", "Rajasthani", "राजस्थानी", true),
    SANSKRIT("sa-IN", "Sanskrit", "संस्कृतम्", true),
    SANTALI("sat-IN", "Santali", "ᱥᱟᱱᱛᱟᱲᱤ", true),
    SINDHI("sd-IN", "Sindhi", "سنڌي", true),
    TAMIL("ta-IN", "Tamil", "தமிழ்", true),
    TELUGU("te-IN", "Telugu", "తెలుగు", true),
    TULU("tcy-IN", "Tulu", "ತುಳು", true),
    URDU("ur-IN", "Urdu", "اردو", true),

    // ---- Other languages ----
    ARABIC("ar-SA", "Arabic", "العربية"),
    CHINESE("zh-CN", "Chinese", "中文"),
    FRENCH("fr-FR", "French", "Français"),
    GERMAN("de-DE", "German", "Deutsch"),
    JAPANESE("ja-JP", "Japanese", "日本語"),
    SPANISH("es-ES", "Spanish", "Español");

    /** Locale actually handed to speech services, never "auto". */
    val speechTag: String get() = if (this == AUTO) ENGLISH.tag else tag

    /** What to show in a list: "Hindi · हिन्दी". */
    val label: String
        get() = if (this == AUTO) "Automatic — reply in the language I use" else "$englishName · $nativeName"

    companion object {
        fun fromTag(tag: String): Language = entries.firstOrNull { it.tag == tag } ?: AUTO

        fun selectable(): List<Language> = entries.toList()

        fun indianLanguages(): List<Language> = entries.filter { it.indian }

        fun otherLanguages(): List<Language> = entries.filter { !it.indian && it != AUTO }
    }
}
