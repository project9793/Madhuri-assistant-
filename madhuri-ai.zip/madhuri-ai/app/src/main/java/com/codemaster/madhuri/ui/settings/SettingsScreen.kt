package com.codemaster.madhuri.ui.settings

import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.codemaster.madhuri.BuildConfig
import com.codemaster.madhuri.appContainer
import com.codemaster.madhuri.model.AppSettings
import com.codemaster.madhuri.model.Language
import com.codemaster.madhuri.ui.theme.CyanSecondary
import com.codemaster.madhuri.ui.theme.PinkTertiary
import com.codemaster.madhuri.ui.theme.VioletDeep
import com.codemaster.madhuri.ui.theme.VioletPrimary

private val TABS = listOf("Profile", "Assistant", "Voice", "Language", "Memory", "Privacy")

@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel = viewModel(
        factory = SettingsViewModel.factory(LocalContext.current.appContainer)
    )
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val settings = state.settings
    val context = LocalContext.current

    var tab by remember { mutableIntStateOf(0) }
    var showLanguageDialog by remember { mutableStateOf(false) }
    var showVoiceDialog by remember { mutableStateOf(false) }
    var showPersonalityDialog by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }
    var showDeleteAllDialog by remember { mutableStateOf(false) }
    var showKey by remember { mutableStateOf(false) }
    var nameDraft by remember(settings.userName) { mutableStateOf(settings.userName) }
    var emailDraft by remember(settings.userEmail) { mutableStateOf(settings.userEmail) }
    var rateDraft by remember(settings.speechRate) { mutableFloatStateOf(settings.speechRate) }

    val avatarPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri -> if (uri != null) viewModel.setAvatarFromUri(uri) }

    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            text = "Settings",
            style = androidx.compose.material3.MaterialTheme.typography.headlineSmall,
            modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 10.dp)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TABS.forEachIndexed { index, label ->
                TabChip(label = label, selected = tab == index, onClick = { tab = index })
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            Spacer(Modifier.height(14.dp))

            if (tab == 0) {
                ProfileCard(
                    name = settings.userName.ifBlank { "Madhuri's friend" },
                    email = settings.userEmail.ifBlank { "Add your email" },
                    avatarPath = settings.avatarPath
                )
                Spacer(Modifier.height(18.dp))
                SectionLabel("PROFILE")
                SettingsCard {
                    RowField(
                        emoji = "\uD83D\uDC64",
                        title = "Name",
                        subtitle = "What Madhuri calls you",
                        value = settings.userName.ifBlank { "Set" },
                        onClick = {}
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = nameDraft,
                        onValueChange = { nameDraft = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Your name") },
                        singleLine = true
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = emailDraft,
                        onValueChange = { emailDraft = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Email (optional)") },
                        singleLine = true
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                viewModel.setUserName(nameDraft)
                                viewModel.setUserEmail(emailDraft)
                            }
                        ) { Text("Save") }
                        OutlinedButton(
                            onClick = {
                                avatarPicker.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            }
                        ) { Text("Profile photo") }
                    }
                }
            }

            if (tab == 1) {
                SectionLabel("ASSISTANT")
                SettingsCard {
                    RowField(
                        emoji = "\u2764\uFE0F",
                        title = "Personality",
                        subtitle = "How Madhuri behaves and talks",
                        value = personaLabel(settings.persona),
                        onClick = { showPersonalityDialog = true }
                    )
                    RowField(
                        emoji = "\uD83C\uDFA8",
                        title = "Theme",
                        subtitle = "Dark, light or follow the phone",
                        value = when (settings.themeMode) {
                            AppSettings.THEME_LIGHT -> "Light"
                            AppSettings.THEME_SYSTEM -> "System"
                            else -> "Dark"
                        },
                        onClick = {}
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TabChip("System", settings.themeMode == AppSettings.THEME_SYSTEM) {
                            viewModel.setThemeMode(AppSettings.THEME_SYSTEM)
                        }
                        TabChip("Dark", settings.themeMode == AppSettings.THEME_DARK) {
                            viewModel.setThemeMode(AppSettings.THEME_DARK)
                        }
                        TabChip("Light", settings.themeMode == AppSettings.THEME_LIGHT) {
                            viewModel.setThemeMode(AppSettings.THEME_LIGHT)
                        }
                    }
                }

                Spacer(Modifier.height(18.dp))
                SectionLabel("GEMINI")
                SettingsCard {
                    Text(
                        text = "Create a key in Google AI Studio. It is stored in this app's private storage and sent only to generativelanguage.googleapis.com.",
                        style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = state.keyDraft,
                        onValueChange = viewModel::onKeyDraftChange,
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("API key") },
                        singleLine = true,
                        visualTransformation = if (showKey) {
                            VisualTransformation.None
                        } else {
                            PasswordVisualTransformation()
                        },
                        trailingIcon = {
                            TextButton(onClick = { showKey = !showKey }) {
                                Text(if (showKey) "Hide" else "Show")
                            }
                        }
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = viewModel::testKey, enabled = !state.testing) {
                            Text(if (state.testing) "Testing…" else "Test")
                        }
                        OutlinedButton(onClick = viewModel::saveKey) { Text("Save") }
                        TextButton(onClick = viewModel::deleteKey) { Text("Delete") }
                    }
                    state.keyStatus?.let { status ->
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = status,
                            style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                            color = CyanSecondary
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("Model", style = androidx.compose.material3.MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.height(6.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        AppSettings.MODELS.forEach { model ->
                            TabChip(model, settings.model == model) { viewModel.setModel(model) }
                        }
                    }
                }
            }

            if (tab == 2) {
                SectionLabel("VOICE")
                SettingsCard {
                    SwitchField(
                        emoji = "\uD83D\uDD0A",
                        title = "Speak replies aloud",
                        subtitle = "Read every answer out loud",
                        checked = settings.voiceEnabled,
                        onCheckedChange = viewModel::setVoiceEnabled
                    )
                    SwitchField(
                        emoji = "\uD83D\uDD01",
                        title = "Continuous conversation",
                        subtitle = "Listen again after each reply",
                        checked = settings.continuousConversation,
                        onCheckedChange = viewModel::setContinuousConversation
                    )
                    RowField(
                        emoji = "\uD83C\uDFB5",
                        title = "Voice",
                        subtitle = "How Madhuri sounds",
                        value = if (settings.speechEngine == AppSettings.SPEECH_GEMINI) {
                            settings.voiceName
                        } else {
                            "Phone"
                        },
                        onClick = { showVoiceDialog = true }
                    )
                    RowField(
                        emoji = "\uD83C\uDF99\uFE0F",
                        title = "Listening engine",
                        subtitle = "How your speech becomes text",
                        value = if (settings.voiceEngine == AppSettings.ENGINE_GEMINI) "Gemini" else "Phone",
                        onClick = {}
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        TabChip(
                            "Gemini transcription (recommended)",
                            settings.voiceEngine == AppSettings.ENGINE_GEMINI
                        ) { viewModel.setVoiceEngine(AppSettings.ENGINE_GEMINI) }
                        TabChip(
                            "Phone speech service",
                            settings.voiceEngine == AppSettings.ENGINE_ANDROID
                        ) { viewModel.setVoiceEngine(AppSettings.ENGINE_ANDROID) }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = "Speech speed · ${"%.1f".format(rateDraft)}×",
                        style = androidx.compose.material3.MaterialTheme.typography.labelLarge
                    )
                    Slider(
                        value = rateDraft,
                        onValueChange = { rateDraft = it },
                        onValueChangeFinished = { viewModel.setSpeechRate(rateDraft) },
                        valueRange = 0.5f..2.0f,
                        steps = 5
                    )
                    OutlinedButton(onClick = viewModel::testVoice) { Text("Test voice") }
                }
            }

            if (tab == 3) {
                SectionLabel("LANGUAGE")
                SettingsCard {
                    RowField(
                        emoji = "\uD83C\uDF10",
                        title = "Response language",
                        subtitle = "Language Madhuri talks in",
                        value = if (settings.language == Language.AUTO) "Automatic" else settings.language.englishName,
                        onClick = { showLanguageDialog = true }
                    )
                    Text(
                        text = if (settings.language == Language.AUTO) {
                            "Replies come in the language you speak. Indian languages are understood too."
                        } else {
                            "${settings.language.label}. Replies use this language's own script."
                        },
                        style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (tab == 4) {
                SectionLabel("MEMORY")
                SettingsCard {
                    SwitchField(
                        emoji = "\uD83E\uDDE0",
                        title = "Remember things about me",
                        subtitle = "Notes Madhuri saves can be deleted here",
                        checked = settings.memoryEnabled,
                        onCheckedChange = viewModel::setMemoryEnabled
                    )
                    OutlinedTextField(
                        value = state.memoryDraft,
                        onValueChange = viewModel::onMemoryDraftChange,
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Add a note, e.g. \"I live in Patna\"") },
                        singleLine = true
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = viewModel::addMemory) { Text("Add") }
                        if (state.memoryEntries.isNotEmpty()) {
                            TextButton(onClick = viewModel::clearMemory) { Text("Clear all") }
                        }
                    }
                    state.memoryNotice?.let { notice ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = notice,
                                style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                                color = CyanSecondary,
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(onClick = viewModel::dismissMemoryNotice) { Text("OK") }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    if (state.memoryEntries.isEmpty()) {
                        Text(
                            text = "Nothing remembered yet.",
                            style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                            color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        Text(
                            text = "${state.memoryEntries.size} note${if (state.memoryEntries.size == 1) "" else "s"} remembered",
                            style = androidx.compose.material3.MaterialTheme.typography.labelLarge,
                            color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        state.memoryEntries.forEach { entry ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = entry.content,
                                    style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                                    modifier = Modifier.weight(1f)
                                )
                                TextButton(onClick = { viewModel.deleteMemory(entry.id) }) {
                                    Text("Delete")
                                }
                            }
                        }
                    }
                }
            }

            if (tab == 5) {
                SectionLabel("PRIVACY")
                SettingsCard {
                    RowField("\uD83D\uDD12", "Privacy policy", "What is stored and what leaves the phone", "", { showPrivacyDialog = true })
                    RowField("\u2139\uFE0F", "About Madhuri AI", "Version " + BuildConfig.VERSION_NAME, "", { showAboutDialog = true })
                    RowField("\uD83D\uDDD1\uFE0F", "Delete all conversations", "Removes every saved chat", "", { viewModel.deleteAllChats() })
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { showDeleteAllDialog = true }) { Text("Delete everything") }
                }
            }

            Spacer(Modifier.height(30.dp))
        }
    }

    if (showLanguageDialog) {
        AlertDialog(
            onDismissRequest = { showLanguageDialog = false },
            title = { Text("Response language") },
            text = {
                LazyColumn(modifier = Modifier.heightIn(max = 420.dp)) {
                    item {
                        LanguageRow(Language.AUTO, settings.language) {
                            viewModel.setLanguage(it); showLanguageDialog = false
                        }
                    }
                    item { DialogHeader("Indian languages · ${Language.indianLanguages().size}") }
                    items(Language.indianLanguages()) { language ->
                        LanguageRow(language, settings.language) {
                            viewModel.setLanguage(it); showLanguageDialog = false
                        }
                    }
                    item { DialogHeader("Other languages") }
                    items(Language.otherLanguages()) { language ->
                        LanguageRow(language, settings.language) {
                            viewModel.setLanguage(it); showLanguageDialog = false
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showLanguageDialog = false }) { Text("Close") }
            }
        )
    }

    if (showVoiceDialog) {
        AlertDialog(
            onDismissRequest = { showVoiceDialog = false },
            title = { Text("How Madhuri sounds") },
            text = {
                Column {
                    TabChip("Gemini natural voice", settings.speechEngine == AppSettings.SPEECH_GEMINI) {
                        viewModel.setSpeechEngine(AppSettings.SPEECH_GEMINI)
                    }
                    Spacer(Modifier.height(6.dp))
                    TabChip("Phone voice", settings.speechEngine == AppSettings.SPEECH_ANDROID) {
                        viewModel.setSpeechEngine(AppSettings.SPEECH_ANDROID)
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("Voice", style = androidx.compose.material3.MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.height(6.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        AppSettings.VOICES.forEach { voice ->
                            TabChip(voice, settings.voiceName == voice) { viewModel.setVoiceName(voice) }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = viewModel::testVoice) { Text("Test voice") }
                }
            },
            confirmButton = {
                TextButton(onClick = { showVoiceDialog = false }) { Text("Done") }
            }
        )
    }

    if (showPersonalityDialog) {
        AlertDialog(
            onDismissRequest = { showPersonalityDialog = false },
            title = { Text("Personality") },
            text = {
                LazyColumn(modifier = Modifier.heightIn(max = 400.dp)) {
                    items(AppSettings.PERSONAS) { (label, prompt) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.setPersona(prompt)
                                    showPersonalityDialog = false
                                }
                                .padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = label,
                                style = androidx.compose.material3.MaterialTheme.typography.bodyLarge,
                                modifier = Modifier.weight(1f)
                            )
                            if (settings.persona == prompt) {
                                Text(
                                    text = "Selected",
                                    style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                                    color = VioletPrimary
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showPersonalityDialog = false }) { Text("Close") }
            }
        )
    }

    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            title = { Text("Privacy") },
            text = {
                Text(
                    "Chats, memory notes and settings live only in this app's private storage on this phone. " +
                        "The text of your messages, any image you attach, and short voice clips go to Google's " +
                        "Gemini API to produce answers and speech. Nothing else leaves the phone. Madhuri never " +
                        "records in the background, never reads other apps, and always asks before calling or " +
                        "messaging anyone. You can delete every note, chat and key from this screen."
                )
            },
            confirmButton = {
                TextButton(onClick = { showPrivacyDialog = false }) { Text("Close") }
            }
        )
    }

    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            title = { Text("Madhuri AI") },
            text = {
                Text(
                    "Version " + BuildConfig.VERSION_NAME + "\n\nYour Voice. Your World. Your Intelligent Companion.\n\n" +
                        "Kotlin and Jetpack Compose, Material 3. Answers come from Google Gemini. " +
                        "Voice input and speech use Gemini, with the Android platform services as a fallback."
                )
            },
            confirmButton = {
                TextButton(onClick = { showAboutDialog = false }) { Text("Close") }
            }
        )
    }

    if (showDeleteAllDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteAllDialog = false },
            title = { Text("Delete everything?") },
            text = { Text("Chats, memory notes and your API key will be removed from this phone. This cannot be undone.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteEverything()
                        showDeleteAllDialog = false
                    }
                ) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteAllDialog = false }) { Text("Cancel") }
            }
        )
    }
}

private fun personaLabel(persona: String): String =
    AppSettings.PERSONAS.firstOrNull { it.second == persona }?.first ?: "Custom"

@Composable
private fun TabChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(50),
        color = if (selected) VioletDeep.copy(alpha = 0.85f) else Color.White.copy(alpha = 0.06f),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            text = label,
            style = androidx.compose.material3.MaterialTheme.typography.labelLarge,
            color = if (selected) Color.White else androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp)
        )
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text,
        style = androidx.compose.material3.MaterialTheme.typography.labelLarge,
        letterSpacing = 1.6.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(start = 6.dp, bottom = 8.dp)
    )
}

@Composable
private fun SettingsCard(content: @Composable ColumnScope.() -> Unit) {
    Surface(
        shape = RoundedCornerShape(22.dp),
        color = Color.White.copy(alpha = 0.045f),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            Color.White.copy(alpha = 0.08f)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), content = content)
    }
}

@Composable
private fun ProfileCard(name: String, email: String, avatarPath: String) {
    val bitmap = remember(avatarPath) {
        if (avatarPath.isBlank()) {
            null
        } else {
            runCatching { BitmapFactory.decodeFile(avatarPath)?.asImageBitmap() }.getOrNull()
        }
    }
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.linearGradient(
                    listOf(
                        VioletDeep.copy(alpha = 0.55f),
                        PinkTertiary.copy(alpha = 0.35f),
                        Color.Transparent
                    )
                )
            )
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(68.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(VioletPrimary, PinkTertiary))),
                contentAlignment = Alignment.Center
            ) {
                if (bitmap != null) {
                    Image(
                        bitmap = bitmap,
                        contentDescription = "Profile photo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Text(
                        text = name.trim().take(1).uppercase().ifBlank { "M" },
                        style = androidx.compose.material3.MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
            Spacer(Modifier.width(14.dp))
            Column {
                Text(
                    text = name,
                    style = androidx.compose.material3.MaterialTheme.typography.titleLarge,
                    color = Color.White
                )
                Text(
                    text = email,
                    style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.75f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun RowField(
    emoji: String,
    title: String,
    subtitle: String,
    value: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconTile(emoji)
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = androidx.compose.material3.MaterialTheme.typography.titleMedium)
            if (subtitle.isNotBlank()) {
                Text(
                    text = subtitle,
                    style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                    color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        if (value.isNotBlank()) {
            Text(
                text = value,
                style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.width(120.dp)
            )
        }
        Spacer(Modifier.width(6.dp))
        Text("›", style = androidx.compose.material3.MaterialTheme.typography.titleLarge, color = VioletPrimary)
    }
}

@Composable
private fun SwitchField(
    emoji: String,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconTile(emoji)
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = androidx.compose.material3.MaterialTheme.typography.titleMedium)
            Text(
                text = subtitle,
                style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun IconTile(emoji: String) {
    Box(
        modifier = Modifier
            .size(42.dp)
            .clip(RoundedCornerShape(13.dp))
            .background(VioletDeep.copy(alpha = 0.28f)),
        contentAlignment = Alignment.Center
    ) {
        Text(text = emoji, fontSize = 20.sp)
    }
}

@Composable
private fun DialogHeader(text: String) {
    Text(
        text = text,
        style = androidx.compose.material3.MaterialTheme.typography.labelLarge,
        color = VioletPrimary,
        modifier = Modifier.padding(top = 14.dp, bottom = 4.dp)
    )
}

@Composable
private fun LanguageRow(language: Language, selected: Language, onPick: (Language) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onPick(language) }
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = language.label,
            style = androidx.compose.material3.MaterialTheme.typography.bodyLarge,
            modifier = Modifier.weight(1f)
        )
        if (selected == language) {
            Text(
                text = "Selected",
                style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                color = VioletPrimary
            )
        }
    }
}
