package com.codemaster.madhuri.ui.settings

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.codemaster.madhuri.BuildConfig
import com.codemaster.madhuri.appContainer
import com.codemaster.madhuri.model.AppSettings
import com.codemaster.madhuri.model.Language
import com.codemaster.madhuri.ui.theme.CyanSecondary
import com.codemaster.madhuri.ui.theme.SuccessGreen
import com.codemaster.madhuri.ui.theme.PinkTertiary
import com.codemaster.madhuri.ui.theme.VioletDeep
import com.codemaster.madhuri.ui.theme.VioletPrimary

private val TABS = listOf(
    "Profile", "Assistant", "Permissions", "Voice", "Language", "Memory", "API keys", "Privacy"
)

@Composable
fun SettingsScreen(
    initialTab: Int = 0,
    viewModel: SettingsViewModel = viewModel(
        factory = SettingsViewModel.factory(LocalContext.current.appContainer)
    )
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val settings = state.settings
    val context = LocalContext.current

    var tab by remember(initialTab) { mutableIntStateOf(initialTab.coerceIn(0, TABS.lastIndex)) }
    var showLanguageDialog by remember { mutableStateOf(false) }
    var languageQuery by remember { mutableStateOf("") }
    var memoryQuery by remember { mutableStateOf("") }
    var showAddMemoryDialog by remember { mutableStateOf(false) }
    var showVoiceDialog by remember { mutableStateOf(false) }
    var showPersonalityDialog by remember { mutableStateOf(false) }
    var showModelDialog by remember { mutableStateOf(false) }
    var showThinkingDialog by remember { mutableStateOf(false) }
    var temperatureDraft by remember(settings.temperature) { mutableFloatStateOf(settings.temperature) }
    var tokensDraft by remember(settings.maxTokens) { mutableFloatStateOf(settings.maxTokens.toFloat()) }
    var turnsDraft by remember(settings.memoryTurns) { mutableFloatStateOf(settings.memoryTurns.toFloat()) }
    var showCustomPersonaDialog by remember { mutableStateOf(false) }
    var customPersonaDraft by remember { mutableStateOf("") }
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }
    var showDeleteAllDialog by remember { mutableStateOf(false) }
    var showKey by remember { mutableStateOf(false) }
    var nameDraft by remember(settings.userName) { mutableStateOf(settings.userName) }
    var emailDraft by remember(settings.userEmail) { mutableStateOf(settings.userEmail) }
    var rateDraft by remember(settings.speechRate) { mutableFloatStateOf(settings.speechRate) }

    val avatarPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri -> if (uri != null) viewModel.setAvatarFromUri(uri) }

    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            text = "Settings",
            style = androidx.compose.material3.MaterialTheme.typography.headlineSmall,
            modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 10.dp)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TABS.forEachIndexed { index, label ->
                TabChip(label = label, selected = tab == index, onClick = { tab = index })
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            Spacer(Modifier.height(14.dp))

            if (tab == 0) {
                ProfileCard(
                    name = settings.userName.ifBlank { "Madhuri's friend" },
                    email = settings.userEmail.ifBlank { "Add your email" },
                    avatarPath = settings.avatarPath
                )
                Spacer(Modifier.height(18.dp))
                SectionLabel("PROFILE")
                SettingsCard {
                    RowField(
                        emoji = "\uD83D\uDC64",
                        title = "Name",
                        subtitle = "What Madhuri calls you",
                        value = settings.userName.ifBlank { "Set" },
                        onClick = {}
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = nameDraft,
                        onValueChange = { nameDraft = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Your name") },
                        singleLine = true
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = emailDraft,
                        onValueChange = { emailDraft = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Email (optional)") },
                        singleLine = true
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                viewModel.setUserName(nameDraft)
                                viewModel.setUserEmail(emailDraft)
                            }
                        ) { Text("Save") }
                        OutlinedButton(
                            onClick = {
                                avatarPicker.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            }
                        ) { Text("Profile photo") }
                    }
                }
            }

            if (tab == 1) {
                SectionLabel("MODEL & REASONING")
                SettingsCard {
                    RowField(
                        emoji = "\uD83E\uDD16",
                        title = "AI model",
                        subtitle = "Powers the answers. If it is busy, Madhuri switches automatically.",
                        value = settings.model,
                        onClick = { showModelDialog = true }
                    )
                    RowField(
                        emoji = "\uD83E\uDDE0",
                        title = "Thinking",
                        subtitle = "More thinking means smarter but slower replies",
                        value = thinkingLabel(settings.thinking),
                        onClick = { showThinkingDialog = true }
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "Creativity · ${"%.1f".format(temperatureDraft)}",
                        style = androidx.compose.material3.MaterialTheme.typography.labelLarge
                    )
                    Text(
                        text = "Lower is focused and consistent, higher is more varied",
                        style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Slider(
                        value = temperatureDraft,
                        onValueChange = { temperatureDraft = it },
                        onValueChangeFinished = { viewModel.setTemperature(temperatureDraft) },
                        valueRange = 0f..2f,
                        steps = 7
                    )
                    Text(
                        text = "Response length · ${tokensDraft.toInt()} tokens",
                        style = androidx.compose.material3.MaterialTheme.typography.labelLarge
                    )
                    Slider(
                        value = tokensDraft,
                        onValueChange = { tokensDraft = it },
                        onValueChangeFinished = { viewModel.setMaxTokens(tokensDraft.toInt()) },
                        valueRange = 256f..8192f,
                        steps = 30
                    )
                }

                Spacer(Modifier.height(18.dp))
                SectionLabel("MEMORY")
                SettingsCard {
                    SwitchField(
                        emoji = "\uD83D\uDCDD",
                        title = "Conversation memory",
                        subtitle = "Remember earlier chats in new conversations",
                        checked = settings.memoryEnabled,
                        onCheckedChange = viewModel::setMemoryEnabled
                    )
                    Text(
                        text = "Remember last · ${turnsDraft.toInt()} turns",
                        style = androidx.compose.material3.MaterialTheme.typography.labelLarge
                    )
                    Text(
                        text = "Recent exchanges sent with each question. Fewer is faster.",
                        style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Slider(
                        value = turnsDraft,
                        onValueChange = { turnsDraft = it },
                        onValueChangeFinished = { viewModel.setMemoryTurns(turnsDraft.toInt()) },
                        valueRange = 4f..40f,
                        steps = 8
                    )
                    OutlinedButton(onClick = viewModel::deleteAllChats) {
                        Text("Clear conversation history")
                    }
                }

                Spacer(Modifier.height(18.dp))
                OutlinedButton(onClick = viewModel::resetToDefaults) {
                    Text("Reset to defaults")
                }
            }

            if (tab == 2) {
                PermissionsTab()
            }

            if (tab == 3) {
                SectionLabel("VOICE")
                SettingsCard {
                    SwitchField(
                        emoji = "\uD83D\uDD0A",
                        title = "Speak replies aloud",
                        subtitle = "Read every answer out loud",
                        checked = settings.voiceEnabled,
                        onCheckedChange = viewModel::setVoiceEnabled
                    )
                    SwitchField(
                        emoji = "\uD83D\uDD01",
                        title = "Continuous conversation",
                        subtitle = "Listen again after each reply",
                        checked = settings.continuousConversation,
                        onCheckedChange = viewModel::setContinuousConversation
                    )
                    RowField(
                        emoji = "\uD83C\uDFB5",
                        title = "Voice",
                        subtitle = "How Madhuri sounds",
                        value = if (settings.speechEngine == AppSettings.SPEECH_GEMINI) {
                            settings.voiceName
                        } else {
                            "Phone"
                        },
                        onClick = { showVoiceDialog = true }
                    )
                    RowField(
                        emoji = "\uD83C\uDF99\uFE0F",
                        title = "Listening engine",
                        subtitle = "How your speech becomes text",
                        value = if (settings.voiceEngine == AppSettings.ENGINE_GEMINI) "Gemini" else "Phone",
                        onClick = {}
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        TabChip(
                            "Gemini transcription (recommended)",
                            settings.voiceEngine == AppSettings.ENGINE_GEMINI
                        ) { viewModel.setVoiceEngine(AppSettings.ENGINE_GEMINI) }
                        TabChip(
                            "Phone speech service",
                            settings.voiceEngine == AppSettings.ENGINE_ANDROID
                        ) { viewModel.setVoiceEngine(AppSettings.ENGINE_ANDROID) }
                    }
                    SwitchField(
                        emoji = "\u270B",
                        title = "Let me interrupt",
                        subtitle = "Start talking while she speaks and she stops to listen",
                        checked = settings.interruptEnabled,
                        onCheckedChange = viewModel::setInterruptEnabled
                    )
                    RowField(
                        emoji = "\uD83C\uDF9A\uFE0F",
                        title = "End-of-speech sensitivity",
                        subtitle = "How quickly she decides you have finished",
                        value = sensitivityLabel(settings.endOfSpeechSensitivity),
                        onClick = {}
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TabChip("Low", settings.endOfSpeechSensitivity == AppSettings.SENSITIVITY_LOW) {
                            viewModel.setEndOfSpeechSensitivity(AppSettings.SENSITIVITY_LOW)
                        }
                        TabChip("Medium", settings.endOfSpeechSensitivity == AppSettings.SENSITIVITY_MEDIUM) {
                            viewModel.setEndOfSpeechSensitivity(AppSettings.SENSITIVITY_MEDIUM)
                        }
                        TabChip("High", settings.endOfSpeechSensitivity == AppSettings.SENSITIVITY_HIGH) {
                            viewModel.setEndOfSpeechSensitivity(AppSettings.SENSITIVITY_HIGH)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = "Speech speed · ${"%.1f".format(rateDraft)}×",
                        style = androidx.compose.material3.MaterialTheme.typography.labelLarge
                    )
                    Slider(
                        value = rateDraft,
                        onValueChange = { rateDraft = it },
                        onValueChangeFinished = { viewModel.setSpeechRate(rateDraft) },
                        valueRange = 0.5f..2.0f,
                        steps = 5
                    )
                    OutlinedButton(onClick = viewModel::testVoice) { Text("Test voice") }
                }
            }

            if (tab == 4) {
                SectionLabel("LANGUAGE")
                SettingsCard {
                    RowField(
                        emoji = "\uD83C\uDF10",
                        title = "Response language",
                        subtitle = "Language Madhuri talks in",
                        value = if (settings.language == Language.AUTO) "Automatic" else settings.language.englishName,
                        onClick = { showLanguageDialog = true }
                    )
                    Text(
                        text = if (settings.language == Language.AUTO) {
                            "Replies come in the language you speak. Indian languages are understood too."
                        } else {
                            "${settings.language.label}. Replies use this language's own script."
                        },
                        style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (tab == 5) {
                val filtered = state.memoryEntries.filter {
                    memoryQuery.isBlank() || it.content.contains(memoryQuery.trim(), ignoreCase = true)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "My memories",
                            style = androidx.compose.material3.MaterialTheme.typography.headlineSmall
                        )
                        Text(
                            text = when {
                                state.memoryEntries.isEmpty() -> "No memories saved"
                                state.memoryEntries.size == 1 -> "1 memory saved"
                                else -> "${state.memoryEntries.size} memories saved"
                            },
                            style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                            color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = VioletDeep,
                        modifier = Modifier.clickable { showAddMemoryDialog = true }
                    ) {
                        Text(
                            text = "+  Add",
                            style = androidx.compose.material3.MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)
                        )
                    }
                }

                Spacer(Modifier.height(14.dp))

                OutlinedTextField(
                    value = memoryQuery,
                    onValueChange = { memoryQuery = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Search memories") },
                    leadingIcon = { Text("\uD83D\uDD0D") },
                    singleLine = true,
                    shape = RoundedCornerShape(18.dp)
                )

                Spacer(Modifier.height(14.dp))

                if (filtered.isEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 40.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(96.dp)
                                .clip(RoundedCornerShape(28.dp))
                                .background(VioletDeep.copy(alpha = 0.18f))
                                .border(1.dp, VioletDeep.copy(alpha = 0.45f), RoundedCornerShape(28.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "\uD83E\uDDE0", fontSize = 40.sp)
                        }
                        Spacer(Modifier.height(18.dp))
                        Text(
                            text = if (memoryQuery.isBlank()) "No memories yet" else "Nothing matches",
                            style = androidx.compose.material3.MaterialTheme.typography.titleLarge
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = if (memoryQuery.isBlank()) {
                                "Add things Madhuri should always remember — your routine, people you " +
                                    "talk about, what you like."
                            } else {
                                "Try another word, or clear the search."
                            },
                            style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                            color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 24.dp)
                        )
                    }
                } else {
                    filtered.forEach { entry ->
                        SettingsCard {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = entry.content,
                                    style = androidx.compose.material3.MaterialTheme.typography.bodyLarge,
                                    modifier = Modifier.weight(1f)
                                )
                                TextButton(onClick = { viewModel.deleteMemory(entry.id) }) {
                                    Text("Delete")
                                }
                            }
                            Text(
                                text = android.text.format.DateFormat.format(
                                    "d MMM yyyy, h:mm a",
                                    entry.createdAt
                                ).toString(),
                                style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                    }
                }

                Spacer(Modifier.height(16.dp))
                SettingsCard {
                    SwitchField(
                        emoji = "\uD83E\uDDE0",
                        title = "Remember things about me",
                        subtitle = "When off, nothing new is saved",
                        checked = settings.memoryEnabled,
                        onCheckedChange = viewModel::setMemoryEnabled
                    )
                    if (state.memoryEntries.isNotEmpty()) {
                        OutlinedButton(onClick = viewModel::clearMemory) { Text("Clear all memories") }
                    }
                }
            }

            if (tab == 6) {
                Text(
                    text = "Keys are stored only on this phone. Gemini is required; the optional " +
                        "tools stay off until you switch them on.",
                    style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                    color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                SettingsCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconTile("\u2728")
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Gemini",
                                style = androidx.compose.material3.MaterialTheme.typography.titleLarge
                            )
                            Text(
                                text = "Required · powers Madhuri's voice and replies",
                                style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        StatusChip(
                            text = if (settings.apiKey.isNotBlank()) "Active" else "Not set",
                            color = if (settings.apiKey.isNotBlank()) SuccessGreen else Color(0xFF8A8A99)
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = state.keyDraft,
                        onValueChange = viewModel::onKeyDraftChange,
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Paste your key") },
                        singleLine = true,
                        shape = RoundedCornerShape(50),
                        visualTransformation = if (showKey) {
                            VisualTransformation.None
                        } else {
                            PasswordVisualTransformation()
                        },
                        trailingIcon = {
                            TextButton(onClick = { showKey = !showKey }) {
                                Text(if (showKey) "Hide" else "Show")
                            }
                        }
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "\u2197  Get a key",
                            style = androidx.compose.material3.MaterialTheme.typography.titleSmall,
                            color = VioletPrimary,
                            modifier = Modifier.clickable {
                                runCatching {
                                    context.startActivity(
                                        Intent(
                                            Intent.ACTION_VIEW,
                                            Uri.parse("https://aistudio.google.com/apikey")
                                        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    )
                                }
                            }
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            TextButton(onClick = viewModel::testKey, enabled = !state.testing) {
                                Text(if (state.testing) "Testing…" else "Test")
                            }
                            Button(onClick = viewModel::saveKey) { Text("Update") }
                        }
                    }
                    state.keyStatus?.let { status ->
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = status,
                            style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                            color = CyanSecondary
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    TextButton(onClick = viewModel::deleteKey) { Text("Delete key") }
                }

                Spacer(Modifier.height(14.dp))

                SettingsCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconTile("\uD83C\uDF10")
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Web search",
                                style = androidx.compose.material3.MaterialTheme.typography.titleLarge
                            )
                            Text(
                                text = "Optional · lets Madhuri look things up on Google. No extra key needed.",
                                style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        StatusChip(
                            text = if (settings.webSearchEnabled) "On" else "Off",
                            color = if (settings.webSearchEnabled) SuccessGreen else Color(0xFF8A8A99)
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    SwitchField(
                        emoji = "\uD83D\uDD0E",
                        title = "Use Google search",
                        subtitle = "Answers about news, prices and weather can use live results",
                        checked = settings.webSearchEnabled,
                        onCheckedChange = viewModel::setWebSearchEnabled
                    )
                }
            }

            if (tab == 7) {
                SectionLabel("PRIVACY")
                SettingsCard {
                    RowField("\uD83D\uDD12", "Privacy policy", "What is stored and what leaves the phone", "", { showPrivacyDialog = true })
                    RowField("\u2139\uFE0F", "About Madhuri AI", "Version " + BuildConfig.VERSION_NAME, "", { showAboutDialog = true })
                    RowField("\uD83D\uDDD1\uFE0F", "Delete all conversations", "Removes every saved chat", "", { viewModel.deleteAllChats() })
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { showDeleteAllDialog = true }) { Text("Delete everything") }
                }
            }

            Spacer(Modifier.height(30.dp))
        }
    }

    if (showLanguageDialog) {
        val results = Language.search(languageQuery)
        val searching = languageQuery.isNotBlank()
        AlertDialog(
            onDismissRequest = { showLanguageDialog = false },
            title = { Text("Choose language") },
            text = {
                Column {
                    OutlinedTextField(
                        value = languageQuery,
                        onValueChange = { languageQuery = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Search language") },
                        singleLine = true
                    )
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(modifier = Modifier.heightIn(max = 360.dp)) {
                        if (searching) {
                            if (results.isEmpty()) {
                                item {
                                    Text(
                                        text = "No language matches \"$languageQuery\"",
                                        style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            items(results) { language ->
                                LanguageRow(language, settings.language) {
                                    viewModel.setLanguage(language)
                                    showLanguageDialog = false
                                    languageQuery = ""
                                }
                            }
                        } else {
                            item {
                                LanguageRow(Language.AUTO, settings.language) { picked ->
                                    viewModel.setLanguage(picked)
                                    showLanguageDialog = false
                                }
                            }
                            item { DialogHeader("Indian languages · ${Language.indianLanguages().size}") }
                            items(Language.indianLanguages()) { language ->
                                LanguageRow(language, settings.language) {
                                    viewModel.setLanguage(language)
                                    showLanguageDialog = false
                                }
                            }
                            item { DialogHeader("Neighbouring countries · ${Language.otherLanguages().size}") }
                            items(Language.otherLanguages()) { language ->
                                LanguageRow(language, settings.language) {
                                    viewModel.setLanguage(language)
                                    showLanguageDialog = false
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showLanguageDialog = false; languageQuery = "" }) { Text("Close") }
            }
        )
    }

    if (showVoiceDialog) {
        AlertDialog(
            onDismissRequest = { showVoiceDialog = false },
            title = { Text("Choose voice") },
            text = {
                Column {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TabChip("Gemini natural", settings.speechEngine == AppSettings.SPEECH_GEMINI) {
                            viewModel.setSpeechEngine(AppSettings.SPEECH_GEMINI)
                        }
                        TabChip("Phone voice", settings.speechEngine == AppSettings.SPEECH_ANDROID) {
                            viewModel.setSpeechEngine(AppSettings.SPEECH_ANDROID)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    LazyColumn(modifier = Modifier.heightIn(max = 380.dp)) {
                        items(AppSettings.VOICES) { voice ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.setVoiceName(voice) }
                                    .padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconTile("\uD83D\uDD0A")
                                Spacer(Modifier.width(12.dp))
                                Text(
                                    text = voice,
                                    style = androidx.compose.material3.MaterialTheme.typography.bodyLarge,
                                    color = if (settings.voiceName == voice) VioletPrimary
                                    else androidx.compose.material3.MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.weight(1f)
                                )
                                if (settings.voiceName == voice) {
                                    Text(
                                        text = "Selected",
                                        style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                                        color = VioletPrimary
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Row {
                    TextButton(onClick = viewModel::testVoice) { Text("Test") }
                    TextButton(onClick = { showVoiceDialog = false }) { Text("Done") }
                }
            }
        )
    }

    if (showAddMemoryDialog) {
        AlertDialog(
            onDismissRequest = { showAddMemoryDialog = false },
            title = { Text("Add a memory") },
            text = {
                Column {
                    Text(
                        text = "Something Madhuri should always know — your routine, people, likes.",
                        style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = state.memoryDraft,
                        onValueChange = viewModel::onMemoryDraftChange,
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("e.g. I live in Patna and work night shifts") },
                        minLines = 2,
                        maxLines = 5
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.addMemory()
                        showAddMemoryDialog = false
                    }
                ) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showAddMemoryDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showModelDialog) {
        AlertDialog(
            onDismissRequest = { showModelDialog = false },
            title = { Text("AI model") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    AppSettings.MODELS.forEach { model ->
                        TabChip(model, settings.model == model) {
                            viewModel.setModel(model)
                            showModelDialog = false
                        }
                    }
                    Text(
                        text = "If the chosen model is overloaded, Madhuri answers with the lighter one automatically.",
                        style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showModelDialog = false }) { Text("Close") }
            }
        )
    }

    if (showThinkingDialog) {
        AlertDialog(
            onDismissRequest = { showThinkingDialog = false },
            title = { Text("Thinking") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        AppSettings.THINKING_DEFAULT to "Default",
                        AppSettings.THINKING_OFF to "Off — fastest",
                        AppSettings.THINKING_LOW to "Low",
                        AppSettings.THINKING_MEDIUM to "Medium",
                        AppSettings.THINKING_HIGH to "High — deepest"
                    ).forEach { (mode, label) ->
                        TabChip(label, settings.thinking == mode) {
                            viewModel.setThinking(mode)
                            showThinkingDialog = false
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showThinkingDialog = false }) { Text("Close") }
            }
        )
    }

    if (showPersonalityDialog) {
        AlertDialog(
            onDismissRequest = { showPersonalityDialog = false },
            title = { Text("Choose personality") },
            text = {
                LazyColumn(modifier = Modifier.heightIn(max = 420.dp)) {
                    items(AppSettings.PERSONAS) { (label, prompt) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.setPersona(prompt)
                                    showPersonalityDialog = false
                                }
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = label,
                                style = androidx.compose.material3.MaterialTheme.typography.bodyLarge,
                                color = if (settings.persona == prompt) VioletPrimary
                                else androidx.compose.material3.MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.weight(1f)
                            )
                            if (settings.persona == prompt) {
                                Text(
                                    text = "Selected",
                                    style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                                    color = VioletPrimary
                                )
                            }
                        }
                    }
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    customPersonaDraft = settings.persona
                                    showPersonalityDialog = false
                                    showCustomPersonaDialog = true
                                }
                                .padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconTile("\u2699\uFE0F")
                            Spacer(Modifier.width(12.dp))
                            Text(
                                text = "Manage custom personality",
                                style = androidx.compose.material3.MaterialTheme.typography.bodyLarge
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showPersonalityDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showCustomPersonaDialog) {
        AlertDialog(
            onDismissRequest = { showCustomPersonaDialog = false },
            title = { Text("Custom personality") },
            text = {
                Column {
                    Text(
                        text = "Describe how Madhuri should behave, in your own words.",
                        style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = customPersonaDraft,
                        onValueChange = { customPersonaDraft = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("e.g. calm Hindi teacher who jokes sometimes") },
                        minLines = 3,
                        maxLines = 6
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (customPersonaDraft.isNotBlank()) viewModel.setPersona(customPersonaDraft.trim())
                        showCustomPersonaDialog = false
                    }
                ) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showCustomPersonaDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            title = { Text("Privacy") },
            text = {
                Text(
                    "Chats, memory notes and settings live only in this app's private storage on this phone. " +
                        "The text of your messages, any image you attach, and short voice clips go to Google's " +
                        "Gemini API to produce answers and speech. Nothing else leaves the phone. Madhuri never " +
                        "records in the background, never reads other apps, and always asks before calling or " +
                        "messaging anyone. You can delete every note, chat and key from this screen."
                )
            },
            confirmButton = {
                TextButton(onClick = { showPrivacyDialog = false }) { Text("Close") }
            }
        )
    }

    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            title = { Text("Madhuri AI") },
            text = {
                Text(
                    "Version " + BuildConfig.VERSION_NAME + "\n\nYour Voice. Your World. Your Intelligent Companion.\n\n" +
                        "Kotlin and Jetpack Compose, Material 3. Answers come from Google Gemini. " +
                        "Voice input and speech use Gemini, with the Android platform services as a fallback."
                )
            },
            confirmButton = {
                TextButton(onClick = { showAboutDialog = false }) { Text("Close") }
            }
        )
    }

    if (showDeleteAllDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteAllDialog = false },
            title = { Text("Delete everything?") },
            text = { Text("Chats, memory notes and your API key will be removed from this phone. This cannot be undone.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteEverything()
                        showDeleteAllDialog = false
                    }
                ) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteAllDialog = false }) { Text("Cancel") }
            }
        )
    }
}

private fun thinkingLabel(mode: String): String = when (mode) {
    AppSettings.THINKING_OFF -> "Off"
    AppSettings.THINKING_LOW -> "Low"
    AppSettings.THINKING_MEDIUM -> "Medium"
    AppSettings.THINKING_HIGH -> "High"
    else -> "Default"
}

private fun sensitivityLabel(mode: String): String = when (mode) {
    AppSettings.SENSITIVITY_LOW -> "Low"
    AppSettings.SENSITIVITY_HIGH -> "High"
    else -> "Medium"
}

private fun personaLabel(persona: String): String =
    AppSettings.PERSONAS.firstOrNull { it.second == persona }?.first ?: "Custom"

@Composable
private fun TabChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(50),
        color = if (selected) VioletDeep.copy(alpha = 0.85f) else Color.White.copy(alpha = 0.06f),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            text = label,
            style = androidx.compose.material3.MaterialTheme.typography.labelLarge,
            color = if (selected) Color.White else androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp)
        )
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text,
        style = androidx.compose.material3.MaterialTheme.typography.labelLarge,
        letterSpacing = 1.6.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(start = 6.dp, bottom = 8.dp)
    )
}

@Composable
private fun SettingsCard(content: @Composable ColumnScope.() -> Unit) {
    Surface(
        shape = RoundedCornerShape(22.dp),
        color = Color.White.copy(alpha = 0.045f),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            Color.White.copy(alpha = 0.08f)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), content = content)
    }
}

@Composable
private fun ProfileCard(name: String, email: String, avatarPath: String) {
    val bitmap = remember(avatarPath) {
        if (avatarPath.isBlank()) {
            null
        } else {
            runCatching { BitmapFactory.decodeFile(avatarPath)?.asImageBitmap() }.getOrNull()
        }
    }
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.linearGradient(
                    listOf(
                        VioletDeep.copy(alpha = 0.55f),
                        PinkTertiary.copy(alpha = 0.35f),
                        Color.Transparent
                    )
                )
            )
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(68.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(VioletPrimary, PinkTertiary))),
                contentAlignment = Alignment.Center
            ) {
                if (bitmap != null) {
                    Image(
                        bitmap = bitmap,
                        contentDescription = "Profile photo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Text(
                        text = name.trim().take(1).uppercase().ifBlank { "M" },
                        style = androidx.compose.material3.MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
            Spacer(Modifier.width(14.dp))
            Column {
                Text(
                    text = name,
                    style = androidx.compose.material3.MaterialTheme.typography.titleLarge,
                    color = Color.White
                )
                Text(
                    text = email,
                    style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.75f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun RowField(
    emoji: String,
    title: String,
    subtitle: String,
    value: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconTile(emoji)
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = androidx.compose.material3.MaterialTheme.typography.titleMedium)
            if (subtitle.isNotBlank()) {
                Text(
                    text = subtitle,
                    style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                    color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        if (value.isNotBlank()) {
            Text(
                text = value,
                style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.width(120.dp)
            )
        }
        Spacer(Modifier.width(6.dp))
        Text("›", style = androidx.compose.material3.MaterialTheme.typography.titleLarge, color = VioletPrimary)
    }
}

@Composable
private fun SwitchField(
    emoji: String,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconTile(emoji)
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = androidx.compose.material3.MaterialTheme.typography.titleMedium)
            Text(
                text = subtitle,
                style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun IconTile(emoji: String) {
    Box(
        modifier = Modifier
            .size(42.dp)
            .clip(RoundedCornerShape(13.dp))
            .background(VioletDeep.copy(alpha = 0.28f)),
        contentAlignment = Alignment.Center
    ) {
        Text(text = emoji, fontSize = 20.sp)
    }
}

@Composable
private fun DialogHeader(text: String) {
    Text(
        text = text,
        style = androidx.compose.material3.MaterialTheme.typography.labelLarge,
        color = VioletPrimary,
        modifier = Modifier.padding(top = 14.dp, bottom = 4.dp)
    )
}

@Composable
private fun LanguageRow(language: Language, selected: Language, onPick: (Language) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onPick(language) }
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = language.label,
            style = androidx.compose.material3.MaterialTheme.typography.bodyLarge,
            modifier = Modifier.weight(1f)
        )
        if (selected == language) {
            Text(
                text = "Selected",
                style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                color = VioletPrimary
            )
        }
    }
}

private data class PermissionItem(
    val title: String,
    val permission: String,
    val subtitle: String,
    val emoji: String
)

@Composable
private fun PermissionsTab() {
    val context = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { refresh++ }

    val items = remember {
        listOf(
            PermissionItem(
                "Microphone",
                Manifest.permission.RECORD_AUDIO,
                "Voice input and spoken replies",
                "\uD83C\uDFA4"
            ),
            PermissionItem(
                "Contacts",
                Manifest.permission.READ_CONTACTS,
                "Look up \"call Mom\" by name",
                "\uD83D\uDCD7"
            ),
            PermissionItem(
                "Phone calls",
                Manifest.permission.CALL_PHONE,
                "Place a call after you confirm",
                "\uD83D\uDCDE"
            ),
            PermissionItem(
                "Messages",
                Manifest.permission.SEND_SMS,
                "Prepare an SMS draft for you",
                "\u2709\uFE0F"
            ),
            PermissionItem(
                "Location",
                Manifest.permission.ACCESS_COARSE_LOCATION,
                "Approximate location, only for local weather",
                "\uD83D\uDCCD"
            )
        )
    }

    val granted = remember(refresh) {
        items.map {
            ContextCompat.checkSelfPermission(context, it.permission) ==
                PackageManager.PERMISSION_GRANTED
        }
    }
    val allowed = granted.count { it }
    val missing = items.filterIndexed { index, _ -> !granted[index] }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.linearGradient(
                    listOf(VioletDeep.copy(alpha = 0.55f), PinkTertiary.copy(alpha = 0.30f))
                )
            )
            .padding(16.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconTile("\uD83D\uDEE1\uFE0F")
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(
                        text = "$allowed of ${items.size} allowed",
                        style = androidx.compose.material3.MaterialTheme.typography.titleLarge,
                        color = Color.White
                    )
                    Text(
                        text = if (missing.isEmpty()) {
                            "Everything Madhuri needs is switched on."
                        } else {
                            "Some features will not work until you allow these."
                        },
                        style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.8f)
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator(
                progress = { allowed.toFloat() / items.size },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = PinkTertiary,
                trackColor = Color.White.copy(alpha = 0.2f)
            )
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = {
                    if (missing.isEmpty()) refresh++ else launcher.launch(
                        missing.map { it.permission }.toTypedArray()
                    )
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (missing.isEmpty()) "All permissions allowed" else "Allow missing permissions")
            }
        }
    }

    Spacer(Modifier.height(18.dp))
    SectionLabel("CORE")
    SettingsCard {
        items.forEachIndexed { index, item ->
            PermissionRow(
                item = item,
                granted = granted[index],
                onClick = {
                    if (granted[index]) {
                        openAppSettings(context)
                    } else {
                        launcher.launch(arrayOf(item.permission))
                    }
                }
            )
        }
    }

    Spacer(Modifier.height(18.dp))
    SectionLabel("SYSTEM")
    SettingsCard {
        RowField(
            emoji = "\uD83C\uDFA7",
            title = "Voice input service",
            subtitle = "Which service turns your speech into text",
            value = "",
            onClick = {
                val opened = runCatching {
                    context.startActivity(
                        Intent("android.settings.VOICE_INPUT_SETTINGS")
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }.isSuccess
                if (!opened) openAppSettings(context)
            }
        )
        RowField(
            emoji = "\u2699\uFE0F",
            title = "App settings",
            subtitle = "All Android permissions for Madhuri",
            value = "",
            onClick = { openAppSettings(context) }
        )
        RowField(
            emoji = "\uD83D\uDC41\uFE0F",
            title = "Screen look",
            subtitle = "Asks for your permission every single time, captures one frame",
            value = "On demand",
            onClick = {}
        )
    }

    Spacer(Modifier.height(12.dp))
    Text(
        text = "Camera, gallery, alarms and web links use the phone's own screens, so they need " +
            "no permission from Madhuri. The app never asks for location and never reads other apps.",
        style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(horizontal = 6.dp)
    )
}

@Composable
private fun PermissionRow(item: PermissionItem, granted: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconTile(item.emoji)
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(item.title, style = androidx.compose.material3.MaterialTheme.typography.titleMedium)
            Text(
                text = item.subtitle,
                style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(6.dp))
            StatusChip(
                text = if (granted) "Allowed" else "Not allowed",
                color = if (granted) SuccessGreen else Color(0xFFFFC857)
            )
        }
        Text("›", style = androidx.compose.material3.MaterialTheme.typography.titleLarge, color = VioletPrimary)
    }
}

@Composable
private fun StatusChip(text: String, color: Color) {
    Surface(
        shape = RoundedCornerShape(50),
        color = color.copy(alpha = 0.18f)
    ) {
        Text(
            text = text,
            style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
            color = color,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

private fun openAppSettings(context: android.content.Context) {
    runCatching {
        context.startActivity(
            Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.fromParts("package", context.packageName, null)
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
