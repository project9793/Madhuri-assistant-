package com.codemaster.madhuri.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.codemaster.madhuri.appContainer
import com.codemaster.madhuri.model.AppSettings
import com.codemaster.madhuri.model.Language
import com.codemaster.madhuri.ui.components.GlassCard

@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel = viewModel(
        factory = SettingsViewModel.factory(LocalContext.current.appContainer)
    )
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val settings = state.settings

    var showLanguageDialog by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }
    var showDeleteAllDialog by remember { mutableStateOf(false) }
    var showKey by remember { mutableStateOf(false) }
    var personaDraft by remember(settings.persona) { mutableStateOf(settings.persona) }
    var rateDraft by remember(settings.speechRate) { mutableFloatStateOf(settings.speechRate) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
    ) {
        Spacer(Modifier.height(16.dp))
        Text("Settings", style = MaterialTheme.typography.headlineSmall)
        Text(
            text = "Everything stays on this phone unless you send it to Gemini.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(16.dp))

        // ---------- Gemini API ----------
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            SectionTitle("Gemini API")
            Text(
                text = "Create a key in Google AI Studio. It is stored in this app's private storage and sent only to generativelanguage.googleapis.com.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = state.keyDraft,
                onValueChange = viewModel::onKeyDraftChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("API key") },
                singleLine = true,
                visualTransformation = if (showKey) {
                    VisualTransformation.None
                } else {
                    PasswordVisualTransformation()
                },
                trailingIcon = {
                    TextButton(onClick = { showKey = !showKey }) {
                        Text(if (showKey) "Hide" else "Show")
                    }
                }
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = viewModel::testKey, enabled = !state.testing) {
                    Text(if (state.testing) "Testing…" else "Test")
                }
                OutlinedButton(onClick = viewModel::saveKey) { Text("Save") }
                TextButton(onClick = viewModel::deleteKey) { Text("Delete") }
            }
            state.keyStatus?.let { status ->
                Spacer(Modifier.height(8.dp))
                Text(
                    text = status,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
            Spacer(Modifier.height(12.dp))
            Text("Model", style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AppSettings.MODELS.forEach { model ->
                    ChoiceChip(
                        label = model,
                        selected = settings.model == model,
                        onClick = { viewModel.setModel(model) }
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // ---------- Language ----------
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            SectionTitle("Language")
            SettingRow(
                title = "Response language",
                subtitle = if (settings.language == Language.AUTO) {
                    "Automatic — replies in the language you use"
                } else {
                    "${settings.language.englishName} · ${settings.language.nativeName}"
                },
                onClick = { showLanguageDialog = true }
            )
            Text(
                text = "Speech recognition and text-to-speech use the same language. If the phone has no voice for it, Madhuri falls back to Hindi, then English.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(Modifier.height(12.dp))

        // ---------- Voice ----------
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            SectionTitle("Voice")
            SwitchRow(
                title = "Speak replies aloud",
                subtitle = "Uses the phone's text-to-speech engine",
                checked = settings.voiceEnabled,
                onCheckedChange = viewModel::setVoiceEnabled
            )
            SwitchRow(
                title = "Continuous conversation",
                subtitle = "Starts listening again after each reply. You can stop it any time.",
                checked = settings.continuousConversation,
                onCheckedChange = viewModel::setContinuousConversation
            )
            Spacer(Modifier.height(10.dp))
            Text("Voice input engine", style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(6.dp))
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                ChoiceChip(
                    label = "Gemini (recommended)",
                    selected = settings.voiceEngine == AppSettings.ENGINE_GEMINI,
                    onClick = { viewModel.setVoiceEngine(AppSettings.ENGINE_GEMINI) }
                )
                ChoiceChip(
                    label = "Phone speech service",
                    selected = settings.voiceEngine == AppSettings.ENGINE_ANDROID,
                    onClick = { viewModel.setVoiceEngine(AppSettings.ENGINE_ANDROID) }
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(
                text = "Gemini records a short clip and transcribes it, so voice input works even when the phone's speech service is broken or missing.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            Text(
                text = "Speech speed · ${"%.1f".format(rateDraft)}×",
                style = MaterialTheme.typography.labelLarge
            )
            Slider(
                value = rateDraft,
                onValueChange = { rateDraft = it },
                onValueChangeFinished = { viewModel.setSpeechRate(rateDraft) },
                valueRange = 0.5f..2.0f,
                steps = 5
            )
            OutlinedButton(onClick = viewModel::testVoice) { Text("Test voice") }
        }

        Spacer(Modifier.height(12.dp))

        // ---------- Personality ----------
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            SectionTitle("Assistant personality")
            OutlinedTextField(
                value = personaDraft,
                onValueChange = { personaDraft = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("How should Madhuri sound?") },
                minLines = 2,
                maxLines = 4
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = { viewModel.setPersona(personaDraft) }) { Text("Save personality") }
        }

        Spacer(Modifier.height(12.dp))

        // ---------- Memory ----------
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            SectionTitle("Memory")
            SwitchRow(
                title = "Remember things about me",
                subtitle = "Notes Madhuri saves are listed here and can be deleted one by one",
                checked = settings.memoryEnabled,
                onCheckedChange = viewModel::setMemoryEnabled
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = state.memoryDraft,
                onValueChange = viewModel::onMemoryDraftChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Add a note, e.g. \"I live in Patna\"") },
                singleLine = true
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = viewModel::addMemory) { Text("Add") }
                if (state.memoryEntries.isNotEmpty()) {
                    TextButton(onClick = viewModel::clearMemory) { Text("Clear all") }
                }
            }
            Spacer(Modifier.height(8.dp))
            if (state.memoryEntries.isEmpty()) {
                Text(
                    text = "Nothing remembered yet.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                state.memoryEntries.forEach { entry ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = entry.content,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = { viewModel.deleteMemory(entry.id) }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Delete note")
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // ---------- Appearance ----------
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            SectionTitle("Appearance")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ChoiceChip(
                    label = "System",
                    selected = settings.themeMode == AppSettings.THEME_SYSTEM,
                    onClick = { viewModel.setThemeMode(AppSettings.THEME_SYSTEM) }
                )
                ChoiceChip(
                    label = "Dark",
                    selected = settings.themeMode == AppSettings.THEME_DARK,
                    onClick = { viewModel.setThemeMode(AppSettings.THEME_DARK) }
                )
                ChoiceChip(
                    label = "Light",
                    selected = settings.themeMode == AppSettings.THEME_LIGHT,
                    onClick = { viewModel.setThemeMode(AppSettings.THEME_LIGHT) }
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        // ---------- Privacy ----------
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            SectionTitle("Privacy and data")
            SettingRow("Privacy policy", "What is stored and what leaves the phone", { showPrivacyDialog = true })
            SettingRow("About Madhuri AI", "Version, stack, credits", { showAboutDialog = true })
            SettingRow("Delete all conversations", "Removes every saved chat", { viewModel.deleteAllChats() })
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { showDeleteAllDialog = true }) {
                Text("Delete everything")
            }
        }

        Spacer(Modifier.height(28.dp))
    }

    if (showLanguageDialog) {
        AlertDialog(
            onDismissRequest = { showLanguageDialog = false },
            title = { Text("Response language") },
            text = {
                LazyColumn(modifier = Modifier.heightIn(max = 420.dp)) {
                    items(Language.selectable()) { language ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.setLanguage(language)
                                    showLanguageDialog = false
                                }
                                .padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (language == Language.AUTO) {
                                    "Automatic"
                                } else {
                                    "${language.englishName} · ${language.nativeName}"
                                },
                                style = MaterialTheme.typography.bodyLarge,
                                modifier = Modifier.weight(1f)
                            )
                            if (settings.language == language) {
                                Text(
                                    text = "Selected",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showLanguageDialog = false }) { Text("Close") }
            }
        )
    }

    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            title = { Text("Privacy") },
            text = {
                Text(
                    "Chats, memory notes and settings are stored only in this app's private storage on this phone. " +
                        "Nothing is uploaded anywhere except the text, and any image you attach, which is sent to " +
                        "Google's Gemini API to generate a reply. Microphone audio is handled by your phone's speech " +
                        "recognition service and only while you have started listening. Madhuri never records in the " +
                        "background, never reads other apps, and asks before calling or messaging anyone. " +
                        "You can delete every note, chat and key from this screen."
                )
            },
            confirmButton = {
                TextButton(onClick = { showPrivacyDialog = false }) { Text("Close") }
            }
        )
    }

    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            title = { Text("Madhuri AI") },
            text = {
                Text(
                    "Version 1.0.0\n\nYour Voice. Your World. Your Intelligent Companion.\n\n" +
                        "Kotlin and Jetpack Compose, Material 3. Answers come from Google Gemini. " +
                        "Speech recognition and text-to-speech use the Android platform services."
                )
            },
            confirmButton = {
                TextButton(onClick = { showAboutDialog = false }) { Text("Close") }
            }
        )
    }

    if (showDeleteAllDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteAllDialog = false },
            title = { Text("Delete everything?") },
            text = {
                Text("Chats, memory notes and your API key will be removed from this phone. This cannot be undone.")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteEverything()
                        showDeleteAllDialog = false
                    }
                ) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteAllDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text = text, style = MaterialTheme.typography.titleMedium)
    Spacer(Modifier.height(8.dp))
}

@Composable
private fun SettingRow(title: String, subtitle: String, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp)
    ) {
        Text(title, style = MaterialTheme.typography.bodyLarge)
        Text(
            subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun SwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.width(8.dp))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun ChoiceChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(50),
        color = if (selected) {
            MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)
        } else {
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        },
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            color = if (selected) {
                MaterialTheme.colorScheme.primary
            } else {
                MaterialTheme.colorScheme.onSurfaceVariant
            }
        )
    }
}
