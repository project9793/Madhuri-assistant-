package com.codemaster.madhuri.data

import com.codemaster.madhuri.model.AppSettings
import com.codemaster.madhuri.model.AssistantError
import com.codemaster.madhuri.model.ChatMessage
import com.codemaster.madhuri.model.DeviceAction
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

sealed interface EngineEvent {
    data class Token(val text: String) : EngineEvent
    data class Completed(
        val text: String,
        val actions: List<DeviceAction>,
        val memoryNotes: List<String>
    ) : EngineEvent

    data class Failed(val error: AssistantError, val detail: String? = null) : EngineEvent
}

/**
 * One request/response cycle. Whichever services the user has keys for are tried
 * in order, so a quota wall on one provider silently rolls over to the next
 * instead of stopping the conversation.
 */
class ConversationEngine(
    private val gemini: GeminiClient,
    private val openRouter: OpenRouterClient,
    private val settingsRepository: SettingsRepository,
    private val memoryRepository: MemoryRepository
) {

    private enum class Provider { GEMINI, XAI, GROQ, OPENROUTER }

    fun stream(
        history: List<ChatMessage>,
        userText: String,
        imageBase64: String? = null,
        imageMimeType: String? = null
    ): Flow<EngineEvent> = flow {
        val settings = settingsRepository.current()
        val hasGemini = settings.apiKey.isNotBlank()
        val hasOpenRouter = settings.openRouterKey.isNotBlank()
        val groqKeyPresent = settings.grokKey.isNotBlank()
        val hasGroq = groqKeyPresent && GroqClient.isGroqKey(settings.grokKey)
        val hasXai = groqKeyPresent && !GroqClient.isGroqKey(settings.grokKey)
        val wantsImage = imageBase64 != null && imageMimeType != null

        val providers = buildList {
            when (settings.chatProvider) {
                AppSettings.PROVIDER_OPENROUTER -> {
                    if (hasOpenRouter) add(Provider.OPENROUTER)
                    if (hasGroq) add(Provider.GROQ)
                    if (hasXai) add(Provider.XAI)
                    if (hasGemini) add(Provider.GEMINI)
                }

                AppSettings.PROVIDER_XAI -> {
                    if (hasGroq) add(Provider.GROQ)
                    if (hasXai) add(Provider.XAI)
                    if (hasGemini) add(Provider.GEMINI)
                    if (hasOpenRouter) add(Provider.OPENROUTER)
                }

                AppSettings.PROVIDER_GEMINI -> {
                    if (hasGemini) add(Provider.GEMINI)
                    if (hasGroq) add(Provider.GROQ)
                    if (hasXai) add(Provider.XAI)
                    if (hasOpenRouter) add(Provider.OPENROUTER)
                }

                else -> {
                    // Groq's free tier is roomier than Gemini's, so when Gemini is
                    // known to be out of quota it goes first.
                    val geminiBurned = settingsRepository.geminiQuotaDeadRecently()
                    if (hasGroq && geminiBurned) add(Provider.GROQ)
                    if (hasGemini) add(Provider.GEMINI)
                    if (hasGroq && !geminiBurned) add(Provider.GROQ)
                    if (hasXai) add(Provider.XAI)
                    if (hasOpenRouter) add(Provider.OPENROUTER)
                }
            }
        }

        if (providers.isEmpty()) {
            emit(
                EngineEvent.Failed(
                    AssistantError.MISSING_API_KEY,
                    "gemini: ${if (hasGemini) "set" else "no key"}\n" +
                        "groq/xai: ${if (hasGroq || hasXai) "set" else "no key"}\n" +
                        "openrouter: ${if (hasOpenRouter) "set" else "no key"}"
                )
            )
            return@flow
        }

        val memory = if (settings.memoryEnabled) memoryRepository.all() else emptyList()
        val systemInstruction = PromptBuilder.systemInstruction(settings, memory, wantsImage)

        val recentHistory = history.takeLast(settings.memoryTurns.coerceIn(2, 60))
        val buffer = StringBuilder()
        var emittedAnything = false
        var lastFailure: GeminiException? = null
        val trail = mutableListOf<String>()

        for ((index, provider) in providers.withIndex()) {
            // Pictures only travel through Gemini for now.
            if (wantsImage && provider != Provider.GEMINI) {
                trail.add("${provider.name.lowercase()}: skipped (pictures need Gemini)")
                lastFailure = GeminiException(
                    AssistantError.UNKNOWN,
                    "openrouter cannot read images",
                    "openrouter: pictures need Gemini — add a Gemini key for photo questions"
                )
                continue
            }
            try {
                when (provider) {
                    Provider.GEMINI -> streamFromGemini(
                        settings = settings,
                        systemInstruction = systemInstruction,
                        history = recentHistory,
                        userText = userText,
                        imageBase64 = imageBase64,
                        imageMimeType = imageMimeType
                    ).collect { chunk ->
                        emittedAnything = true
                        buffer.append(chunk)
                        emit(EngineEvent.Token(chunk))
                    }

                    Provider.XAI -> streamFromCompatible(
                        settings = settings,
                        systemInstruction = systemInstruction,
                        history = recentHistory,
                        userText = userText,
                        endpoint = OpenRouterClient.XAI_ENDPOINT,
                        apiKey = settings.grokKey,
                        model = settings.grokModel.ifBlank { "grok-4.7" }
                    ).collect { chunk ->
                        emittedAnything = true
                        buffer.append(chunk)
                        emit(EngineEvent.Token(chunk))
                    }

                    Provider.GROQ -> streamFromCompatible(
                        settings = settings,
                        systemInstruction = systemInstruction,
                        history = recentHistory,
                        userText = userText,
                        endpoint = GroqClient.CHAT_ENDPOINT,
                        apiKey = settings.grokKey,
                        model = settings.grokModel.ifBlank { GroqClient.DEFAULT_MODEL }
                            .let { if (it.startsWith("grok-")) GroqClient.DEFAULT_MODEL else it }
                    ).collect { chunk ->
                        emittedAnything = true
                        buffer.append(chunk)
                        emit(EngineEvent.Token(chunk))
                    }

                    Provider.OPENROUTER -> streamFromOpenRouter(
                        settings = settings,
                        systemInstruction = systemInstruction,
                        history = recentHistory,
                        userText = userText
                    ).collect { chunk ->
                        emittedAnything = true
                        buffer.append(chunk)
                        emit(EngineEvent.Token(chunk))
                    }
                }
                lastFailure = null
                break
            } catch (e: GeminiException) {
                lastFailure = e
                trail.add("${provider.name.lowercase()}: ${e.detail ?: e.error.name}")
                if (provider == Provider.GEMINI && e.error == AssistantError.QUOTA_EXCEEDED) {
                    runCatching { settingsRepository.markGeminiQuotaDead() }
                }
                val retryable = e.error == AssistantError.QUOTA_EXCEEDED ||
                    e.error == AssistantError.RATE_LIMITED ||
                    e.error == AssistantError.SERVER ||
                    e.error == AssistantError.INVALID_API_KEY ||
                    e.error == AssistantError.MODEL_NOT_FOUND ||
                    e.error == AssistantError.TIMEOUT
                if (emittedAnything || !retryable || index == providers.lastIndex) {
                    emit(EngineEvent.Failed(e.error, trail.joinToString("\n")))
                    return@flow
                }
                delay(500)
            }
        }

        lastFailure?.let {
            emit(EngineEvent.Failed(it.error, trail.joinToString("\n")))
            return@flow
        }

        val raw = buffer.toString()
        val clean = ActionParser.strip(raw).trim()
        val actions = ActionParser.parseActions(raw)
        val notes = ActionParser.parseMemory(raw)
        if (settings.memoryEnabled) {
            notes.forEach { note -> runCatching { memoryRepository.add(note) } }
        }
        emit(EngineEvent.Completed(text = clean, actions = actions, memoryNotes = notes))
    }

    private fun streamFromGemini(
        settings: AppSettings,
        systemInstruction: String,
        history: List<ChatMessage>,
        userText: String,
        imageBase64: String?,
        imageMimeType: String?
    ): Flow<String> = flow {
        val contents = buildList {
            history.forEach { message ->
                add(
                    GeminiContent(
                        role = if (message.role == ChatMessage.Role.USER) "user" else "model",
                        parts = listOf(GeminiPart(text = message.text))
                    )
                )
            }
            val parts = buildList {
                add(GeminiPart(text = userText.ifBlank { "Describe this image in detail." }))
                if (imageBase64 != null && imageMimeType != null) {
                    add(GeminiPart(inlineMimeType = imageMimeType, inlineData = imageBase64))
                }
            }
            add(GeminiContent(role = "user", parts = parts))
        }

        val body = gemini.buildRequest(
            systemInstruction = systemInstruction,
            contents = contents,
            temperature = settings.temperature.toDouble(),
            maxTokens = settings.maxTokens,
            thinkingBudget = AppSettings.thinkingBudget(settings.thinking),
            webSearch = settings.webSearchEnabled
        )

        // A busy model is retried once on the lighter one before giving up.
        val models = listOf(settings.model, AppSettings.FALLBACK_MODEL).distinct()
        var emitted = false
        for ((index, model) in models.withIndex()) {
            try {
                gemini.streamGenerate(model, settings.apiKey, body).collect { chunk ->
                    emitted = true
                    emit(chunk)
                }
                return@flow
            } catch (e: GeminiException) {
                val retryable = e.error == AssistantError.SERVER ||
                    e.error == AssistantError.RATE_LIMITED ||
                    e.error == AssistantError.MODEL_NOT_FOUND
                if (emitted || !retryable || index == models.lastIndex) throw e
            }
        }
    }

    private fun streamFromOpenRouter(
        settings: AppSettings,
        systemInstruction: String,
        history: List<ChatMessage>,
        userText: String
    ): Flow<String> = streamFromCompatible(
        settings = settings,
        systemInstruction = systemInstruction,
        history = history,
        userText = userText,
        endpoint = OpenRouterClient.ENDPOINT,
        apiKey = settings.openRouterKey,
        model = settings.openRouterModel.ifBlank { OpenRouterClient.DEFAULT_MODEL }
    )

    private fun streamFromCompatible(
        settings: AppSettings,
        systemInstruction: String,
        history: List<ChatMessage>,
        userText: String,
        endpoint: String,
        apiKey: String,
        model: String
    ): Flow<String> = flow {
        val turns = history.map { message ->
            OpenRouterClient.Turn(
                role = if (message.role == ChatMessage.Role.USER) "user" else "assistant",
                text = message.text
            )
        }
        openRouter.streamChat(
            model = model,
            apiKey = apiKey,
            endpoint = endpoint,
            systemInstruction = systemInstruction,
            history = turns,
            userText = userText.ifBlank { "Hello" },
            temperature = settings.temperature.toDouble(),
            maxTokens = settings.maxTokens
        ).collect { emit(it) }
    }
}
