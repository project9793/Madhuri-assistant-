package com.codemaster.madhuri.data

import com.codemaster.madhuri.model.AppSettings
import com.codemaster.madhuri.model.AssistantError
import com.codemaster.madhuri.model.ChatMessage
import com.codemaster.madhuri.model.DeviceAction
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

sealed interface EngineEvent {
    data class Token(val text: String) : EngineEvent
    data class Completed(
        val text: String,
        val actions: List<DeviceAction>,
        val memoryNotes: List<String>
    ) : EngineEvent

    data class Failed(val error: AssistantError, val detail: String? = null) : EngineEvent
}

/**
 * One request/response cycle against Gemini: reads settings, adds memory and the
 * action protocol, streams tokens, then hands back the cleaned reply plus any
 * action or memory blocks the model produced.
 */
class ConversationEngine(
    private val gemini: GeminiClient,
    private val settingsRepository: SettingsRepository,
    private val memoryRepository: MemoryRepository
) {

    fun stream(
        history: List<ChatMessage>,
        userText: String,
        imageBase64: String? = null,
        imageMimeType: String? = null
    ): Flow<EngineEvent> = flow {
        val settings = settingsRepository.current()
        if (settings.apiKey.isBlank()) {
            emit(EngineEvent.Failed(AssistantError.MISSING_API_KEY))
            return@flow
        }

        val memory = if (settings.memoryEnabled) memoryRepository.all() else emptyList()
        val systemInstruction = PromptBuilder.systemInstruction(settings, memory, imageBase64 != null)

        val contents = buildList {
            history.takeLast(MAX_HISTORY).forEach { message ->
                add(
                    GeminiContent(
                        role = if (message.role == ChatMessage.Role.USER) "user" else "model",
                        parts = listOf(GeminiPart(text = message.text))
                    )
                )
            }
            val parts = buildList {
                add(GeminiPart(text = userText.ifBlank { "Describe this image in detail." }))
                if (imageBase64 != null && imageMimeType != null) {
                    add(GeminiPart(inlineMimeType = imageMimeType, inlineData = imageBase64))
                }
            }
            add(GeminiContent(role = "user", parts = parts))
        }

        val body = gemini.buildRequest(systemInstruction, contents)
        val buffer = StringBuilder()

        // If the chosen model is overloaded (HTTP 503) the same request is
        // retried once on the lighter model instead of failing the whole turn.
        val models = listOf(settings.model, AppSettings.FALLBACK_MODEL).distinct()
        var emittedAnything = false
        var failure: GeminiException? = null
        for ((index, model) in models.withIndex()) {
            try {
                gemini.streamGenerate(model, settings.apiKey, body).collect { chunk ->
                    emittedAnything = true
                    buffer.append(chunk)
                    emit(EngineEvent.Token(chunk))
                }
                failure = null
                break
            } catch (e: GeminiException) {
                failure = e
                val retryable = e.error == AssistantError.SERVER ||
                    e.error == AssistantError.RATE_LIMITED ||
                    e.error == AssistantError.MODEL_NOT_FOUND
                if (emittedAnything || !retryable || index == models.lastIndex) {
                    emit(EngineEvent.Failed(e.error, e.detail))
                    return@flow
                }
                delay(900)
            }
        }
        failure?.let {
            emit(EngineEvent.Failed(it.error, it.detail))
            return@flow
        }

        val raw = buffer.toString()
        val notes = if (settings.memoryEnabled) ActionParser.parseMemory(raw) else emptyList()
        notes.forEach { note -> runCatching { memoryRepository.add(note) } }

        emit(
            EngineEvent.Completed(
                text = ActionParser.strip(raw),
                actions = ActionParser.parseActions(raw),
                memoryNotes = notes
            )
        )
    }

    companion object {
        private const val MAX_HISTORY = 20
    }
}
