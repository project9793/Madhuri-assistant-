package com.codemaster.madhuri.capture

/** Hands the captured frame back to whichever screen asked for it. */
object ScreenCaptureBus {
    @Volatile
    var onCaptured: ((String?) -> Unit)? = null
}
