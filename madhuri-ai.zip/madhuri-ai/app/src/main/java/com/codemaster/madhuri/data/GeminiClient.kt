package com.codemaster.madhuri.data

import com.codemaster.madhuri.model.AssistantError
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

/** One turn of conversation sent to Gemini. */
data class GeminiContent(val role: String, val parts: List<GeminiPart>) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("role", role)
        put("parts", JSONArray().apply { parts.forEach { put(it.toJson()) } })
    }
}

data class GeminiPart(
    val text: String? = null,
    val inlineMimeType: String? = null,
    val inlineData: String? = null
) {
    fun toJson(): JSONObject = JSONObject().apply {
        if (text != null) put("text", text)
        if (inlineData != null && inlineMimeType != null) {
            put(
                "inlineData",
                JSONObject().apply {
                    put("mimeType", inlineMimeType)
                    put("data", inlineData)
                }
            )
        }
    }
}

class GeminiException(
    val error: AssistantError,
    message: String,
    val detail: String? = null
) : Exception(message)

/**
 * Thin REST client for the Gemini Developer API. Uses HttpURLConnection and
 * org.json so the project carries no networking library version to keep in sync.
 *
 * Endpoints used:
 *  - POST {base}/models/{model}:streamGenerateContent?alt=sse   (chat + voice)
 *  - GET  {base}/models?pageSize=1                              (key check)
 */
class GeminiClient {

    fun buildRequest(
        systemInstruction: String,
        contents: List<GeminiContent>,
        temperature: Double = 0.85
    ): JSONObject = JSONObject().apply {
        put(
            "systemInstruction",
            JSONObject().put(
                "parts",
                JSONArray().put(JSONObject().put("text", systemInstruction))
            )
        )
        put("contents", JSONArray().apply { contents.forEach { put(it.toJson()) } })
        put(
            "generationConfig",
            JSONObject().apply {
                put("temperature", temperature)
                put("topP", 0.95)
                put("maxOutputTokens", 2048)
            }
        )
    }

    /**
     * Streams reply text chunks. Throws [GeminiException] on any failure.
     * A transient 5xx or rate-limit response is retried once, but only if the
     * model had not started answering yet, so text is never duplicated.
     */
    fun streamGenerate(
        model: String,
        apiKey: String,
        body: JSONObject
    ): Flow<String> = flow {
        var attempt = 0
        var emittedAnything = false
        while (true) {
            attempt++
            try {
                requestOnce(model, apiKey, body).collect { chunk ->
                    emittedAnything = true
                    emit(chunk)
                }
                return@flow
            } catch (e: GeminiException) {
                val retryable = e.error == AssistantError.SERVER ||
                    e.error == AssistantError.RATE_LIMITED
                if (!emittedAnything && retryable && attempt < 2) {
                    delay(1500)
                    continue
                }
                throw e
            }
        }
    }.flowOn(Dispatchers.IO)

    private fun requestOnce(
        model: String,
        apiKey: String,
        body: JSONObject
    ): Flow<String> = flow {
        val connection = openConnection(
            "$BASE_URL/models/$model:streamGenerateContent?alt=sse",
            apiKey
        )
        try {
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            if (code !in 200..299) {
                val payload = connection.errorStream
                    ?.bufferedReader()
                    ?.use { it.readText() }
                    .orEmpty()
                throw GeminiException(
                    error = errorForHttp(code, payload),
                    message = "HTTP $code: $payload",
                    detail = describeFailure(code, payload)
                )
            }
            connection.inputStream.bufferedReader(Charsets.UTF_8).use { reader ->
                while (true) {
                    val line = reader.readLine() ?: break
                    if (!line.startsWith("data:")) continue
                    val payload = line.substring(5).trim()
                    if (payload.isEmpty() || payload == "[DONE]") continue
                    val text = extractText(payload)
                    if (text.isNotEmpty()) emit(text)
                }
            }
        } catch (e: GeminiException) {
            throw e
        } catch (e: SocketTimeoutException) {
            throw GeminiException(AssistantError.TIMEOUT, e.message ?: "timeout", "timeout")
        } catch (e: UnknownHostException) {
            throw GeminiException(AssistantError.NETWORK, e.message ?: "network", "no route to host")
        } catch (e: IOException) {
            throw GeminiException(AssistantError.NETWORK, e.message ?: "network", e.message)
        } finally {
            connection.disconnect()
        }
    }.flowOn(Dispatchers.IO)

    /** Human-readable one-liner: HTTP status plus Google's own message. */
    private fun describeFailure(code: Int, payload: String): String {
        val googleMessage = runCatching {
            JSONObject(payload).optJSONObject("error")?.optString("message")
        }.getOrNull()
        return if (googleMessage.isNullOrBlank()) {
            "HTTP $code"
        } else {
            "HTTP $code · " + googleMessage.take(240)
        }
    }

    /**
     * Turns a recorded WAV clip into text using Gemini itself, so voice input
     * works even on phones whose speech-recognition service is broken.
     */
    suspend fun transcribe(
        model: String,
        apiKey: String,
        wavBase64: String
    ): Result<String> = withContext(Dispatchers.IO) {
        var lastResult: Result<String> =
            Result.failure(GeminiException(AssistantError.UNKNOWN, "no attempt", null))
        repeat(2) { attempt ->
            val current = transcribeOnce(model, apiKey, wavBase64)
            lastResult = current
            if (current.isSuccess) return@withContext current
            val reason = (current.exceptionOrNull() as? GeminiException)?.error
            // A timeout already cost the user a minute; retrying doubles the
            // wait, so only quick failures are retried.
            val retryable = reason == AssistantError.NETWORK ||
                reason == AssistantError.SERVER
            if (!retryable || attempt == 1) return@withContext current
            delay(1_500)
        }
        lastResult
    }

    private suspend fun transcribeOnce(
        model: String,
        apiKey: String,
        wavBase64: String
    ): Result<String> = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put(
                "contents",
                JSONArray().put(
                    JSONObject().apply {
                        put("role", "user")
                        put(
                            "parts",
                            JSONArray().apply {
                                put(JSONObject().put("text", TRANSCRIBE_PROMPT))
                                put(
                                    JSONObject().apply {
                                        put(
                                            "inlineData",
                                            JSONObject().apply {
                                                put("mimeType", "audio/wav")
                                                put("data", wavBase64)
                                            }
                                        )
                                    }
                                )
                            }
                        )
                    }
                )
            )
            put(
                "generationConfig",
                JSONObject().apply {
                    put("temperature", 0.0)
                    put("maxOutputTokens", 512)
                }
            )
        }

        var connection: HttpURLConnection? = null
        try {
            connection = openConnection(
                "$BASE_URL/models/$model:generateContent",
                apiKey,
                readTimeoutMillis = AUDIO_TIMEOUT_MS
            )
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val payload = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                return@withContext Result.failure(
                    GeminiException(
                        error = errorForHttp(code, payload),
                        message = "HTTP $code: $payload",
                        detail = describeFailure(code, payload)
                    )
                )
            }
            val json = JSONObject(payload)
            val candidates = json.optJSONArray("candidates")
            val parts = candidates
                ?.optJSONObject(0)
                ?.optJSONObject("content")
                ?.optJSONArray("parts")
            val text = buildString {
                if (parts != null) {
                    for (index in 0 until parts.length()) {
                        append(parts.optJSONObject(index)?.optString("text").orEmpty())
                    }
                }
            }.trim()
            Result.success(text)
        } catch (e: GeminiException) {
            Result.failure(e)
        } catch (e: SocketTimeoutException) {
            Result.failure(GeminiException(AssistantError.TIMEOUT, "timeout", "timeout"))
        } catch (e: IOException) {
            Result.failure(GeminiException(AssistantError.NETWORK, e.message ?: "network", e.message))
        } catch (e: Exception) {
            Result.failure(GeminiException(AssistantError.UNKNOWN, e.message ?: "parse", e.message))
        } finally {
            connection?.disconnect()
        }
    }

    /**
     * Audio returned by Gemini's speech models. The bytes are handed over as-is
     * together with their MIME type: the model may send raw PCM or a finished
     * WAV/MP3 container, and guessing wrong is what turns speech into noise.
     */
    data class SpokenAudio(val data: ByteArray, val mimeType: String)

    /**
     * Renders [text] with one of Gemini's natural voices. The model returns raw
     * 16-bit PCM, which [com.codemaster.madhuri.voice.GeminiSpeaker] wraps in a
     * WAV container and plays.
     */
    suspend fun synthesize(
        model: String,
        apiKey: String,
        text: String,
        voiceName: String,
        language: com.codemaster.madhuri.model.Language
    ): Result<SpokenAudio> = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put(
                "contents",
                JSONArray().put(
                    JSONObject().apply {
                        put("role", "user")
                        put(
                            "parts",
                            JSONArray().put(
                                JSONObject().put("text", speechPrompt(text, language))
                            )
                        )
                    }
                )
            )
            put(
                "generationConfig",
                JSONObject().apply {
                    put("responseModalities", JSONArray().put("AUDIO"))
                    put(
                        "speechConfig",
                        JSONObject().apply {
                            put(
                                "voiceConfig",
                                JSONObject().apply {
                                    put(
                                        "prebuiltVoiceConfig",
                                        JSONObject().apply { put("voiceName", voiceName) }
                                    )
                                }
                            )
                        }
                    )
                }
            )
        }

        var connection: HttpURLConnection? = null
        try {
            connection = openConnection(
                "$BASE_URL/models/$model:generateContent",
                apiKey,
                readTimeoutMillis = SPEECH_TIMEOUT_MS
            )
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val payload = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                return@withContext Result.failure(
                    GeminiException(
                        error = errorForHttp(code, payload),
                        message = "HTTP $code: $payload",
                        detail = describeFailure(code, payload)
                    )
                )
            }
            val json = JSONObject(payload)
            val parts = json.optJSONArray("candidates")
                ?.optJSONObject(0)
                ?.optJSONObject("content")
                ?.optJSONArray("parts")
            var audio: String? = null
            var mime = "audio/L16;codec=pcm;rate=24000"
            if (parts != null) {
                for (index in 0 until parts.length()) {
                    val inline = parts.optJSONObject(index)?.optJSONObject("inlineData")
                    if (inline != null) {
                        audio = inline.optString("data")
                        mime = inline.optString("mimeType", mime)
                        break
                    }
                }
            }
            if (audio.isNullOrBlank()) {
                return@withContext Result.failure(
                    GeminiException(AssistantError.UNKNOWN, "no audio", "the speech model returned no audio")
                )
            }
            val bytes = android.util.Base64.decode(audio, android.util.Base64.NO_WRAP)
            Result.success(SpokenAudio(bytes, mime))
        } catch (e: GeminiException) {
            Result.failure(e)
        } catch (e: IOException) {
            Result.failure(GeminiException(AssistantError.NETWORK, e.message ?: "network", e.message))
        } catch (e: Exception) {
            Result.failure(GeminiException(AssistantError.UNKNOWN, e.message ?: "speech", e.message))
        } finally {
            connection?.disconnect()
        }
    }

    /**
     * Cheap validity check: lists one model. Returns null when the key works,
     * or the mapped error when it does not.
     */
    suspend fun testKey(apiKey: String): AssistantError? = withContext(Dispatchers.IO) {
        var connection: HttpURLConnection? = null
        try {
            connection = openConnection("$BASE_URL/models?pageSize=1", apiKey, method = "GET")
            val code = connection.responseCode
            if (code in 200..299) {
                null
            } else {
                val payload = connection.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                errorForHttp(code, payload)
            }
        } catch (e: SocketTimeoutException) {
            AssistantError.TIMEOUT
        } catch (e: IOException) {
            AssistantError.NETWORK
        } finally {
            connection?.disconnect()
        }
    }

    private fun openConnection(
        url: String,
        apiKey: String,
        method: String = "POST",
        readTimeoutMillis: Int = 90_000
    ): HttpURLConnection = (URL(url).openConnection() as HttpURLConnection).apply {
        requestMethod = method
        connectTimeout = 30_000
        readTimeout = readTimeoutMillis
        doInput = true
        doOutput = method == "POST"
        setRequestProperty("x-goog-api-key", apiKey)
        setRequestProperty("Content-Type", "application/json")
        setRequestProperty("Accept", "text/event-stream")
    }

    private fun extractText(payload: String): String {
        val json = runCatching { JSONObject(payload) }.getOrNull() ?: return ""
        val candidates = json.optJSONArray("candidates") ?: return ""
        if (candidates.length() == 0) return ""
        val content = candidates.optJSONObject(0)?.optJSONObject("content") ?: return ""
        val parts = content.optJSONArray("parts") ?: return ""
        val builder = StringBuilder()
        for (index in 0 until parts.length()) {
            val part = parts.optJSONObject(index) ?: continue
            if (part.has("text")) builder.append(part.optString("text"))
        }
        return builder.toString()
    }

    private fun errorForHttp(code: Int, payload: String): AssistantError {
        val lower = payload.lowercase()
        return when {
            code == 400 && lower.contains("api key") -> AssistantError.INVALID_API_KEY
            code == 400 -> AssistantError.UNKNOWN
            code == 403 -> AssistantError.INVALID_API_KEY
            code == 404 -> AssistantError.MODEL_NOT_FOUND
            code == 429 && lower.contains("quota") -> AssistantError.QUOTA_EXCEEDED
            code == 429 -> AssistantError.RATE_LIMITED
            code in 500..599 -> AssistantError.SERVER
            else -> AssistantError.UNKNOWN
        }
    }

    companion object {
        private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta"

        /** Transcription: long enough for a 12 s clip, short enough to fail fast. */
        private const val AUDIO_TIMEOUT_MS = 60_000

        /** Speech synthesis: a short line should never take a minute. */
        private const val SPEECH_TIMEOUT_MS = 15_000

        /**
         * The instruction is written in the target language on purpose: an
         * English instruction makes the model read Hindi lines with an English
         * accent, which is exactly what users complained about.
         */
        private fun speechPrompt(
            text: String,
            language: com.codemaster.madhuri.model.Language
        ): String = when (language) {
            com.codemaster.madhuri.model.Language.HINDI ->
                "इस पंक्ति को स्वाभाविक, मधुर हिंदी आवाज़ में पढ़ें, जैसे कोई अपना दोस्त बात कर रहा हो। " +
                    "भाषा वैसी ही रहे जैसी लिखी है, अंग्रेज़ी लहजा न आए, कोई शब्द जोड़ें या छोड़ें नहीं, " +
                    "और यह निर्देश न पढ़ें।\nपंक्ति: "

            else ->
                "Speak the following line aloud in ${language.englishName}, with a warm, natural voice, " +
                    "like a close friend talking. Use ${language.englishName} pronunciation only, keep the " +
                    "words exactly as written, do not read this instruction out.\nLine: "
        }

        private const val TRANSCRIBE_PROMPT =
            "Transcribe the speech in this audio exactly as spoken, keeping its original " +
                "language, script and any Hindi/English mixing. Reply with the transcript only, " +
                "no quotes and no commentary. If there is no understandable speech, reply with " +
                "the single word NONE."
    }
}
