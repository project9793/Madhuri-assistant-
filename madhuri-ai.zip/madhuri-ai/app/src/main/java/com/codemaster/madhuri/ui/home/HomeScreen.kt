package com.codemaster.madhuri.ui.home

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.codemaster.madhuri.appContainer
import com.codemaster.madhuri.model.VoiceState
import com.codemaster.madhuri.ui.components.AiOrb
import com.codemaster.madhuri.ui.components.GlassCard
import com.codemaster.madhuri.ui.components.MicGlyph

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onOpenChat: (String) -> Unit,
    onOpenSettings: () -> Unit,
    viewModel: HomeViewModel = viewModel(
        factory = HomeViewModel.factory(LocalContext.current.appContainer)
    )
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var typedInput by remember { mutableStateOf("") }

    val micLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) viewModel.startListening() else viewModel.reportMicPermissionDenied()
    }

    val systemVoiceLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val spoken = result.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()
            ?.trim()
            .orEmpty()
        if (spoken.isNotEmpty()) viewModel.submitVoiceText(spoken)
    }

    val launchSystemVoice: () -> Unit = {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to Madhuri")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        try {
            systemVoiceLauncher.launch(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(context, "No speech recognition app on this phone", Toast.LENGTH_LONG).show()
        }
    }

    // If the in-app recogniser fails in a way we cannot fix (a device without
    // Google's speech service, for example), open the phone's own voice dialog.
    LaunchedEffect(state.autoFallbackPending) {
        if (state.autoFallbackPending) {
            viewModel.consumeAutoFallback()
            launchSystemVoice()
        }
    }

    val requestListen: () -> Unit = {
        val granted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) viewModel.startListening() else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    val onOrbTap: () -> Unit = {
        when (state.voiceState) {
            VoiceState.LISTENING -> viewModel.stopListening()
            VoiceState.SPEAKING -> viewModel.stopSpeaking()
            VoiceState.PROCESSING -> Unit
            else -> requestListen()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        MaterialTheme.colorScheme.background,
                        MaterialTheme.colorScheme.surface,
                        MaterialTheme.colorScheme.background
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            HomeHeader(onOpenSettings = onOpenSettings)

            if (!state.hasApiKey) {
                Spacer(Modifier.height(12.dp))
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Add your Gemini API key to start",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "Madhuri needs a key from Google AI Studio. It stays on this device.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = onOpenSettings) { Text("Open Settings") }
                }
            }

            Spacer(Modifier.height(20.dp))

            AiOrb(state = state.voiceState, level = state.micLevel, onClick = onOrbTap)

            Spacer(Modifier.height(12.dp))

            Text(
                text = state.partialTranscript.ifBlank { state.statusLine },
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onBackground
            )

            Spacer(Modifier.height(6.dp))

            Text(
                text = state.language.let {
                    if (it.tag == "auto") "Auto language · replies in your language"
                    else "Replying in ${it.englishName}"
                },
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(Modifier.height(18.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                FilledIconButton(
                    onClick = {
                        if (state.voiceState == VoiceState.LISTENING) viewModel.stopListening()
                        else requestListen()
                    },
                    modifier = Modifier.size(64.dp)
                ) {
                    MicGlyph(
                        tint = MaterialTheme.colorScheme.onPrimary,
                        isListening = state.voiceState == VoiceState.LISTENING
                    )
                }
                IconButton(onClick = viewModel::repeatLastReply) {
                    Icon(Icons.Filled.Refresh, contentDescription = "Repeat last reply")
                }
                IconButton(onClick = viewModel::stopEverything) {
                    Icon(Icons.Filled.Close, contentDescription = "Stop")
                }
            }

            Spacer(Modifier.height(20.dp))

            val latestReply = state.streamingReply.ifBlank {
                state.conversation.lastOrNull()?.text.orEmpty()
            }
            if (state.isStreaming && state.streamingReply.isBlank()) {
                // Do not show the previous reply under a "typing" badge: show
                // that Madhuri is working on the current question.
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(10.dp))
                        Text(
                            text = "Madhuri is thinking…",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    TextButton(onClick = viewModel::stopEverything) { Text("Stop") }
                }
                Spacer(Modifier.height(16.dp))
            } else if (latestReply.isNotBlank()) {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Madhuri",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.width(8.dp))
                        if (state.isStreaming) {
                            AssistChip(onClick = {}, label = { Text("typing…") })
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = latestReply,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(Modifier.height(10.dp))
                    TextButton(onClick = { onOpenChat("new") }) { Text("Open full chat") }
                }
                Spacer(Modifier.height(16.dp))
            }

            OutlinedTextField(
                value = typedInput,
                onValueChange = { typedInput = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Or type to Madhuri…") },
                shape = RoundedCornerShape(20.dp),
                trailingIcon = {
                    IconButton(
                        onClick = {
                            viewModel.sendTypedMessage(typedInput)
                            typedInput = ""
                        }
                    ) {
                        Icon(Icons.Filled.Send, contentDescription = "Send")
                    }
                },
                maxLines = 4
            )

            Spacer(Modifier.height(24.dp))

            Text(
                text = "Quick actions",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))

            QuickActionRow(
                left = "Ask Madhuri" to "Speak any question",
                right = "AI Chat" to "Text, images, code",
                onLeft = { requestListen() },
                onRight = { onOpenChat("new") }
            )
            Spacer(Modifier.height(10.dp))
            QuickActionRow(
                left = "Phone Control" to "Apps, alarms, calls",
                right = "AI Coding" to "Complete, runnable code",
                onLeft = { onOpenChat("phone") },
                onRight = { onOpenChat("coding") }
            )
            Spacer(Modifier.height(10.dp))
            QuickActionRow(
                left = "Website Creator" to "HTML, CSS, JS",
                right = "Image Understanding" to "Attach a photo in chat",
                onLeft = { onOpenChat("website") },
                onRight = { onOpenChat("image") }
            )

            Spacer(Modifier.height(28.dp))

            Text(
                text = "Your Voice. Your World. Your Intelligent Companion.",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(12.dp))
        }
    }

    state.error?.let { error ->
        AlertDialog(
            onDismissRequest = viewModel::dismissError,
            title = { Text("Madhuri needs a moment") },
            text = {
                Column {
                    Text(error.bilingual)
                    state.errorDetail?.let { detail ->
                        Spacer(Modifier.height(10.dp))
                        Text(
                            text = detail,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            },
            confirmButton = {
                Row {
                    TextButton(
                        onClick = {
                            viewModel.dismissError()
                            launchSystemVoice()
                        }
                    ) { Text("System voice input") }
                    TextButton(onClick = viewModel::dismissError) { Text("OK") }
                }
            }
        )
    }

    state.notice?.let { notice ->
        AlertDialog(
            onDismissRequest = viewModel::dismissNotice,
            title = { Text("Voice notice") },
            text = { Text(notice) },
            confirmButton = {
                TextButton(onClick = viewModel::dismissNotice) { Text("Got it") }
            }
        )
    }

    state.pendingAction?.let { action ->
        AlertDialog(
            onDismissRequest = viewModel::dismissPendingAction,
            title = { Text("Confirm") },
            text = { Text("${action.describe()}\n\nThis action contacts someone, so I need your go-ahead.") },
            confirmButton = {
                TextButton(onClick = viewModel::confirmPendingAction) { Text("Do it") }
            },
            dismissButton = {
                TextButton(onClick = viewModel::dismissPendingAction) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun HomeHeader(onOpenSettings: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text(
                text = "MADHURI AI",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Welcome back",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onOpenSettings) {
                Icon(Icons.Filled.Person, contentDescription = "Profile and settings")
            }
        }
    }
}

@Composable
private fun QuickActionRow(
    left: Pair<String, String>,
    right: Pair<String, String>,
    onLeft: () -> Unit,
    onRight: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        QuickActionCard(left.first, left.second, onLeft, Modifier.weight(1f))
        QuickActionCard(right.first, right.second, onRight, Modifier.weight(1f))
    }
}

@Composable
private fun QuickActionCard(
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    GlassCard(modifier = modifier, onClick = onClick) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
