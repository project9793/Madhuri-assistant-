package com.codemaster.madhuri.ui.home

import android.Manifest
import android.app.Activity
import android.media.projection.MediaProjectionManager
import android.content.Intent
import android.content.pm.PackageManager
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.codemaster.madhuri.appContainer
import com.codemaster.madhuri.capture.ScreenCaptureBus
import com.codemaster.madhuri.capture.ScreenCaptureService
import com.codemaster.madhuri.model.VoiceState
import com.codemaster.madhuri.ui.components.AiOrb
import com.codemaster.madhuri.ui.components.GlassCard
import com.codemaster.madhuri.ui.components.MicGlyph
import com.codemaster.madhuri.ui.theme.AccentPink
import com.codemaster.madhuri.ui.theme.AccentPinkDeep
import com.codemaster.madhuri.ui.theme.AccentViolet
import com.codemaster.madhuri.ui.theme.CyanSecondary
import com.codemaster.madhuri.ui.theme.PinkTertiary
import com.codemaster.madhuri.ui.theme.SuccessGreen
import com.codemaster.madhuri.ui.theme.VioletDeep
import com.codemaster.madhuri.ui.theme.VioletPrimary
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@Composable
fun HomeScreen(
    onOpenChat: (String) -> Unit,
    onOpenSettings: (Int) -> Unit,
    listenOnStart: Boolean = false,
    viewModel: HomeViewModel = viewModel(
        factory = HomeViewModel.factory(LocalContext.current.appContainer)
    )
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var typed by remember { mutableStateOf("") }
    var showTypedField by remember { mutableStateOf(false) }

    val micLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) viewModel.startListening() else viewModel.reportMicPermissionDenied() }

    val systemVoiceLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val spoken = result.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()
            ?.trim()
        if (!spoken.isNullOrEmpty()) viewModel.submitVoiceText(spoken)
    }

    val requestListen: () -> Unit = {
        val granted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) {
            viewModel.startListening()
        } else {
            micLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    val launchSystemVoice: () -> Unit = {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to Madhuri")
        }
        val opened = runCatching { systemVoiceLauncher.launch(intent) }.isSuccess
        if (!opened) {
            Toast.makeText(context, "This phone has no voice input screen", Toast.LENGTH_SHORT).show()
        }
    }

    LaunchedEffect(listenOnStart) {
        if (listenOnStart) requestListen()
    }

    LaunchedEffect(state.autoFallbackPending) {
        if (state.autoFallbackPending) {
            viewModel.consumeAutoFallback()
            launchSystemVoice()
        }
    }

    val locationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> viewModel.onLocationPermissionResult(granted) }

    val projectionManager = remember {
        context.getSystemService(MediaProjectionManager::class.java)
    }

    val captureLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        if (result.resultCode == Activity.RESULT_OK && data != null) {
            ScreenCaptureBus.onCaptured = { base64 ->
                if (base64.isNullOrEmpty()) {
                    Toast.makeText(
                        context,
                        "Could not read the screen. Try again.",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    viewModel.sendScreenLook(base64)
                }
            }
            ScreenCaptureService.start(context, result.resultCode, data)
        }
    }

    val lookAtScreen: () -> Unit = {
        val opened = runCatching {
            captureLauncher.launch(projectionManager.createScreenCaptureIntent())
        }.isSuccess
        if (!opened) {
            Toast.makeText(context, "Screen capture is not available here", Toast.LENGTH_SHORT).show()
        }
    }

    val micGranted = ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.RECORD_AUDIO
    ) == PackageManager.PERMISSION_GRANTED

    val onOrbTap: () -> Unit = {
        when (state.voiceState) {
            VoiceState.LISTENING -> viewModel.stopListening()
            VoiceState.SPEAKING -> viewModel.stopSpeaking()
            VoiceState.PROCESSING -> viewModel.stopEverything()
            else -> requestListen()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        Spacer(Modifier.height(10.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = greeting(),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = if (state.userName.isBlank()) "Hi there" else "Hi ${state.userName}",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.SemiBold
                )
            }
            IconButton(onClick = { onOpenSettings(0) }) {
                Icon(
                    Icons.Filled.Notifications,
                    contentDescription = "Settings",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(Modifier.height(10.dp))

        // ---- hero card: the orb, the status, and the two ways in ----
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = Color.White.copy(alpha = 0.045f),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(vertical = 18.dp, horizontal = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                AiOrb(state = state.voiceState, level = state.micLevel, onClick = onOrbTap)
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "Madhuri",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(8.dp))
                StatusPill(state.voiceState, state.statusLine)
                if (state.voiceState == VoiceState.LISTENING) {
                    Text(
                        text = "mic ${"%.2f".format(state.micLevel)} — bolte raho, phir orb dabao",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (state.micLevel > 0.05f) AccentPink
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = { onOrbTap() },
                    shape = RoundedCornerShape(50),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (state.voiceState == VoiceState.LISTENING) {
                        MicGlyph(tint = Color.White, modifier = Modifier.size(18.dp))
                    } else {
                        Text("🎤", fontSize = 16.sp)
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = when (state.voiceState) {
                            VoiceState.LISTENING -> "Stop listening"
                            VoiceState.SPEAKING -> "Stop speaking"
                            VoiceState.PROCESSING -> "Stop"
                            else -> "Talk to Madhuri"
                        },
                        style = MaterialTheme.typography.titleMedium
                    )
                }
                Spacer(Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(50),
                    color = Color.White.copy(alpha = 0.06f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showTypedField = !showTypedField }
                ) {
                    Text(
                        text = "⌨  Type a message instead",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 12.dp),
                        textAlign = TextAlign.Center
                    )
                }
                Spacer(Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(50),
                    color = AccentPink.copy(alpha = 0.14f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.autoRepair() }
                ) {
                    Text(
                        text = "⚡ Fix it for me — pick whichever key works",
                        style = MaterialTheme.typography.titleSmall,
                        color = AccentPink,
                        modifier = Modifier.padding(vertical = 10.dp),
                        textAlign = TextAlign.Center
                    )
                }
                Spacer(Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(50),
                    color = Color.White.copy(alpha = 0.06f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { lookAtScreen() }
                ) {
                    Text(
                        text = "👁  Look at my screen",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 12.dp),
                        textAlign = TextAlign.Center
                    )
                }
                if (showTypedField) {
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = typed,
                            onValueChange = { typed = it },
                            modifier = Modifier.weight(1f),
                            placeholder = { Text("Ask Madhuri anything") },
                            singleLine = true,
                            shape = RoundedCornerShape(18.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        IconButton(
                            onClick = {
                                if (typed.isNotBlank()) {
                                    viewModel.sendTypedMessage(typed)
                                    typed = ""
                                }
                            }
                        ) { Icon(Icons.Filled.Send, contentDescription = "Send") }
                    }
                }
                if (state.partialTranscript.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = state.partialTranscript,
                        style = MaterialTheme.typography.bodyMedium,
                        color = CyanSecondary,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // ---- today's suggestion ----
        val suggestion = todaySuggestion()
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color.White.copy(alpha = 0.04f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Today for you",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(VioletDeep.copy(alpha = 0.30f)),
                        contentAlignment = Alignment.Center
                    ) { Text(suggestion.emoji, fontSize = 20.sp) }
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(suggestion.title, style = MaterialTheme.typography.titleMedium)
                        Text(
                            text = suggestion.subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = PinkTertiary.copy(alpha = 0.18f),
                        modifier = Modifier.clickable {
                            showTypedField = true
                            typed = suggestion.prompt
                        }
                    ) {
                        Text(
                            text = "Start",
                            style = MaterialTheme.typography.titleMedium,
                            color = PinkTertiary,
                            modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        // ---- setup progress ----
        val checks = listOf(
            "Add your Gemini key" to state.hasApiKey,
            "Allow the microphone" to micGranted,
            "Tell Madhuri your name" to state.userName.isNotBlank()
        )
        val done = checks.count { it.second }
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color.White.copy(alpha = 0.04f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Finish setting up",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = "$done of ${checks.size} done",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(Color.White.copy(alpha = 0.10f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(done.toFloat() / checks.size)
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(PinkTertiary)
                    )
                }
                Spacer(Modifier.height(12.dp))
                checks.filterNot { it.second }.forEach { (label, _) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.weight(1f)
                        )
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = Color.White.copy(alpha = 0.06f),
                            modifier = Modifier.clickable {
                                when (label) {
                                    "Allow the microphone" -> micLauncher.launch(
                                        Manifest.permission.RECORD_AUDIO
                                    )
                                    "Tell Madhuri your name" -> onOpenSettings(0)
                                    else -> onOpenSettings(6)
                                }
                            }
                        ) {
                            Text(
                                text = "Fix",
                                style = MaterialTheme.typography.titleSmall,
                                color = PinkTertiary,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                            )
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                }
                if (done == checks.size) {
                    Text(
                        text = "All set. Just talk to her.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SuccessGreen
                    )
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        // ---- banner ----
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color.Transparent,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(
                    Brush.linearGradient(
                        listOf(AccentPinkDeep.copy(alpha = 0.55f), AccentViolet.copy(alpha = 0.35f))
                    )
                )
                .clickable { onOpenSettings(4) }
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.White.copy(alpha = 0.16f)),
                    contentAlignment = Alignment.Center
                ) { Text("✨", fontSize = 20.sp) }
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "New: 62 languages, natural voice, memory",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White
                    )
                    Text(
                        text = "Tap to pick the language Madhuri talks in",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                }
                Text("›", style = MaterialTheme.typography.headlineSmall, color = Color.White)
            }
        }

        Spacer(Modifier.height(18.dp))

        // ---- what Madhuri can do ----
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "WHAT MADHURI CAN DO",
                style = MaterialTheme.typography.labelLarge,
                letterSpacing = 1.4.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = "Try one",
                style = MaterialTheme.typography.labelLarge,
                color = AccentPink,
                modifier = Modifier.clickable { viewModel.sendTypedMessage("Tum kya kya kar sakti ho? Chhota jawab do.") }
            )
        }
        Spacer(Modifier.height(8.dp))

        val abilities = listOf(
            Triple("📞", "Calls & messages", "Mummy ko call karo"),
            Triple("🎵", "Music & video", "Kesariya chalao"),
            Triple("⏰", "Alarms & reminders", "7 baje ka alarm"),
            Triple("📱", "Apps & settings", "Open YouTube"),
            Triple("📖", "Explain & translate", "Isko Hindi me samjhao"),
            Triple("🧠", "Remember things", "Mera naam Siya hai")
        )
        abilities.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { (emoji, title, phrase) ->
                    AbilityTile(emoji, title, phrase, Modifier.weight(1f)) {
                        viewModel.sendTypedMessage(phrase)
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
        }

        Spacer(Modifier.height(8.dp))

        // ---- around you ----
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color.White.copy(alpha = 0.04f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(AccentPinkDeep.copy(alpha = 0.30f)),
                        contentAlignment = Alignment.Center
                    ) { Text("📍", fontSize = 20.sp) }
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = when {
                                !state.locationAllowed -> "Location permission needed"
                                state.weatherLoading -> "Fetching the weather…"
                                state.weather == null -> "Weather unavailable"
                                else -> "${state.weather?.emoji} ${state.weather?.description}"
                            },
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = when {
                                !state.locationAllowed -> "Allow it once to see local weather"
                                state.weatherLoading -> "One small request, no tracking"
                                state.weather == null -> "Tap refresh to try again"
                                else -> "Approximate location, used once"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (!state.locationAllowed) {
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = AccentPink.copy(alpha = 0.18f),
                            modifier = Modifier.clickable {
                                locationLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
                            }
                        ) {
                            Text(
                                text = "Allow",
                                style = MaterialTheme.typography.titleSmall,
                                color = AccentPink,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 7.dp)
                            )
                        }
                    } else {
                        Text(
                            text = "⟳",
                            style = MaterialTheme.typography.headlineSmall,
                            color = AccentPink,
                            modifier = Modifier
                                .clickable { viewModel.refreshWeather() }
                                .padding(horizontal = 6.dp)
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                    Column {
                        Text(
                            text = "WEATHER",
                            style = MaterialTheme.typography.labelSmall,
                            letterSpacing = 1.2.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = when {
                                state.weatherLoading -> "…"
                                state.weather == null -> "-- °C"
                                else -> "${state.weather?.temperature}°C"
                            },
                            style = MaterialTheme.typography.titleLarge
                        )
                    }
                    Column {
                        Text(
                            text = "TIME ZONE",
                            style = MaterialTheme.typography.labelSmall,
                            letterSpacing = 1.2.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = state.timeZoneLabel.ifBlank { "…" },
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                        )
                    }
                    Column {
                        Text(
                            text = "TIME",
                            style = MaterialTheme.typography.labelSmall,
                            letterSpacing = 1.2.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = SimpleDateFormat("h:mm a", Locale.getDefault())
                                .format(java.util.Date()),
                            style = MaterialTheme.typography.titleLarge
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // ---- things to say ----
        Text(
            text = "TRY SAYING",
            style = MaterialTheme.typography.labelLarge,
            letterSpacing = 1.4.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(
                "🎵 Open YouTube",
                "📞 Call Mom",
                "⏰ Alarm 7 baje",
                "🔊 Volume 40%",
                "🌤️ Aaj ka mausam"
            ).forEach { phrase ->
                Surface(
                    shape = RoundedCornerShape(50),
                    color = Color.White.copy(alpha = 0.06f),
                    modifier = Modifier.clickable {
                        viewModel.sendTypedMessage(phrase.drop(3).trim())
                    }
                ) {
                    Text(
                        text = phrase,
                        style = MaterialTheme.typography.titleSmall,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                    )
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // ---- shortcuts ----
        Text(
            text = "SHORTCUTS",
            style = MaterialTheme.typography.labelLarge,
            letterSpacing = 1.4.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ShortcutTile("🧠", "Memory", Modifier.weight(1f)) { onOpenSettings(5) }
            ShortcutTile("❤️", "Personality", Modifier.weight(1f)) { onOpenSettings(1) }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ShortcutTile("💬", "Chats", Modifier.weight(1f)) { onOpenChat("") }
            ShortcutTile("🤖", "AI settings", Modifier.weight(1f)) { onOpenSettings(1) }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ShortcutTile("🌐", "Languages", Modifier.weight(1f)) { onOpenSettings(4) }
            ShortcutTile("🔑", "API keys", Modifier.weight(1f)) { onOpenSettings(6) }
        }

        Spacer(Modifier.height(16.dp))

        // ---- last reply ----
        val latestReply = state.streamingReply.ifBlank {
            state.conversation.lastOrNull()?.text.orEmpty()
        }
        if (state.isStreaming && state.streamingReply.isBlank()) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = "Madhuri is thinking…",
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
                Spacer(Modifier.height(6.dp))
                TextButton(onClick = viewModel::stopEverything) { Text("Stop") }
            }
        } else if (latestReply.isNotBlank()) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Madhuri",
                        style = MaterialTheme.typography.labelLarge,
                        color = VioletPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    if (state.isStreaming) {
                        Text(
                            text = "typing…",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(text = latestReply, style = MaterialTheme.typography.bodyLarge)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    CardAction("Repeat", viewModel::repeatLastReply)
                    CardAction("Stop voice", viewModel::stopSpeaking)
                    CardAction("Full chat") { onOpenChat("") }
                }
            }
        }

        Spacer(Modifier.height(24.dp))
    }

    state.error?.let { error ->
        AlertDialog(
            onDismissRequest = viewModel::dismissError,
            title = { Text("Something went wrong") },
            text = {
                Column {
                    Text(error.english)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = error.hindi,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    state.errorDetail?.let { detail ->
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = detail,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            },
            confirmButton = {
                Row {
                    TextButton(onClick = {
                        viewModel.dismissError()
                        viewModel.autoRepair()
                    }) { Text("Fix it for me") }
                    TextButton(onClick = viewModel::dismissError) { Text("OK") }
                }
            }
        )
    }

    state.notice?.let { notice ->
        AlertDialog(
            onDismissRequest = viewModel::dismissNotice,
            title = { Text("Note") },
            text = { Text(notice) },
            confirmButton = {
                TextButton(onClick = viewModel::dismissNotice) { Text("OK") }
            }
        )
    }

    state.pendingAction?.let { action ->
        AlertDialog(
            onDismissRequest = viewModel::dismissPendingAction,
            title = { Text("Confirm") },
            text = { Text(action.describe()) },
            confirmButton = {
                TextButton(onClick = viewModel::confirmPendingAction) { Text("Do it") }
            },
            dismissButton = {
                TextButton(onClick = viewModel::dismissPendingAction) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun StatusPill(state: VoiceState, statusLine: String) {
    val (label, color) = when (state) {
        VoiceState.LISTENING -> "Listening" to CyanSecondary
        VoiceState.PROCESSING -> "Thinking" to VioletPrimary
        VoiceState.SPEAKING -> "Speaking" to SuccessGreen
        VoiceState.ERROR -> "Needs attention" to Color(0xFFFFC857)
        VoiceState.INTERRUPTED -> "Stopped" to Color(0xFFFFC857)
        else -> "Ready to talk" to SuccessGreen
    }
    Surface(shape = RoundedCornerShape(50), color = color.copy(alpha = 0.16f)) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(RoundedCornerShape(50))
                    .background(color)
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                color = color
            )
        }
    }
}

@Composable
private fun CardAction(label: String, onClick: () -> Unit) {
    Text(
        text = label,
        style = MaterialTheme.typography.labelLarge,
        color = AccentPink,
        maxLines = 1,
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp)
    )
}

@Composable
private fun AbilityTile(
    emoji: String,
    title: String,
    phrase: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = Color.White.copy(alpha = 0.04f),
        modifier = modifier.clickable(onClick = onClick)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(13.dp))
                    .background(AccentPinkDeep.copy(alpha = 0.30f)),
                contentAlignment = Alignment.Center
            ) { Text(emoji, fontSize = 18.sp) }
            Spacer(Modifier.height(10.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
            )
            Text(
                text = "\"$phrase\"",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun ShortcutTile(
    emoji: String,
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = Color.White.copy(alpha = 0.04f),
        modifier = modifier.clickable(onClick = onClick)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(13.dp))
                    .background(VioletDeep.copy(alpha = 0.30f)),
                contentAlignment = Alignment.Center
            ) { Text(emoji, fontSize = 18.sp) }
            Spacer(Modifier.height(10.dp))
            Text(label, style = MaterialTheme.typography.titleMedium)
        }
    }
}

private fun greeting(): String {
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return when (hour) {
        in 4..11 -> "Good morning ☀️"
        in 12..16 -> "Good afternoon"
        in 17..20 -> "Good evening 🌇"
        else -> "Late night 🌙"
    }
}

private data class Suggestion(
    val emoji: String,
    val title: String,
    val subtitle: String,
    val prompt: String
)

private fun todaySuggestion(): Suggestion {
    val day = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
    val options = listOf(
        Suggestion(
            "🗣️",
            "Practise Hindi with me",
            "Speak, and I will gently correct you",
            "Mujhse Hindi me baat karo aur meri galtiyan narmi se theek karo."
        ),
        Suggestion(
            "🌤️",
            "Ask about the weather",
            "Live weather for your city",
            "Aaj mausam kaisa rahega?"
        ),
        Suggestion(
            "⏰",
            "Set a reminder",
            "Say it once and forget it",
            "Kal subah 7 baje ka alarm laga do."
        ),
        Suggestion(
            "📖",
            "Learn something new",
            "A five line answer, in your language",
            "Mujhe ek dilchasp baat batao jo aaj se pehle nahi pata thi."
        )
    )
    return options[day % options.size]
}
