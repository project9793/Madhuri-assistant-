package com.codemaster.madhuri.live

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import android.util.Base64
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/**
 * One Gemini Live session: microphone PCM up over a WebSocket, spoken PCM back
 * down, with interruption handled by the server.
 *
 * Input is raw 16 kHz PCM, output raw 24 kHz PCM, both 16-bit little-endian, as
 * the Live API requires.
 */
class LiveVoiceSession(private val context: Context) {

    interface Listener {
        fun onReady()
        fun onUserTranscript(text: String)
        fun onModelTranscript(text: String)
        fun onTurnComplete()
        fun onInterrupted()
        fun onClosed(reason: String?)
        fun onError(message: String)
    }

    var listener: Listener? = null

    private val mainHandler = Handler(Looper.getMainLooper())
    private var client: OkHttpClient? = null
    private var socket: WebSocket? = null
    private var recorder: AudioRecord? = null
    private var player: AudioTrack? = null
    private var micThread: Thread? = null

    @Volatile private var running = false
    @Volatile private var ready = false

    val isRunning: Boolean get() = running

    fun start(apiKey: String, model: String, systemPrompt: String, voiceName: String) {
        stop()
        running = true
        ready = false

        val httpClient = OkHttpClient.Builder()
            .pingInterval(20, TimeUnit.SECONDS)
            .readTimeout(0, TimeUnit.MILLISECONDS)
            .build()
        client = httpClient

        val url = "$ENDPOINT?key=$apiKey"
        val request = Request.Builder().url(url).build()

        socket = httpClient.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(setupMessage(model, systemPrompt, voiceName).toString())
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                handleServerMessage(text)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (!running) return
                running = false
                stopAudio()
                mainHandler.post { listener?.onError(t.message ?: "live connection failed") }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (!running) return
                running = false
                stopAudio()
                mainHandler.post { listener?.onClosed(reason.ifBlank { "closed" }) }
            }
        })
    }

    fun stop() {
        running = false
        ready = false
        runCatching { socket?.send("{\"realtimeInput\":{\"audioStreamEnd\":true}}") }
        runCatching { socket?.close(1000, "bye") }
        socket = null
        client?.dispatcher?.executorService?.shutdown()
        client = null
        stopAudio()
    }

    private fun setupMessage(model: String, systemPrompt: String, voiceName: String): JSONObject {
        val generationConfig = JSONObject().apply {
            put("responseModalities", JSONArray().put("AUDIO"))
            put(
                "speechConfig",
                JSONObject().apply {
                    put(
                        "voiceConfig",
                        JSONObject().apply {
                            put(
                                "prebuiltVoiceConfig",
                                JSONObject().apply { put("voiceName", voiceName) }
                            )
                        }
                    )
                }
            )
        }
        val setup = JSONObject().apply {
            put("model", "models/$model")
            put("generationConfig", generationConfig)
            put(
                "systemInstruction",
                JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))
                }
            )
            // Ask for both transcripts so the chat screen can show the words.
            put("inputAudioTranscription", JSONObject())
            put("outputAudioTranscription", JSONObject())
        }
        return JSONObject().put("setup", setup)
    }

    private fun handleServerMessage(text: String) {
        val json = runCatching { JSONObject(text) }.getOrNull() ?: return

        if (json.has("setupComplete")) {
            ready = true
            startMicrophone()
            mainHandler.post { listener?.onReady() }
            return
        }

        json.optJSONObject("error")?.let { error ->
            val message = error.optString("message", "live error")
            running = false
            stopAudio()
            mainHandler.post { listener?.onError(message) }
            return
        }

        val content = json.optJSONObject("serverContent") ?: return

        if (content.optBoolean("interrupted")) {
            clearPlayback()
            mainHandler.post { listener?.onInterrupted() }
        }

        content.optJSONObject("inputTranscription")
            ?.optString("text")
            ?.takeIf { it.isNotBlank() }
            ?.let { spoken -> mainHandler.post { listener?.onUserTranscript(spoken) } }

        content.optJSONObject("outputTranscription")
            ?.optString("text")
            ?.takeIf { it.isNotBlank() }
            ?.let { spoken -> mainHandler.post { listener?.onModelTranscript(spoken) } }

        content.optJSONObject("modelTurn")?.optJSONArray("parts")?.let { parts ->
            for (index in 0 until parts.length()) {
                val part = parts.optJSONObject(index) ?: continue
                part.optJSONObject("inlineData")?.let { inline ->
                    val mime = inline.optString("mimeType", "")
                    if (mime.contains("audio", ignoreCase = true)) {
                        val payload = inline.optString("data")
                        if (payload.isNotBlank()) {
                            runCatching {
                                playPcm(Base64.decode(payload, Base64.NO_WRAP))
                            }
                        }
                    }
                }
                part.optString("text")
                    ?.takeIf { it.isNotBlank() }
                    ?.let { spoken -> mainHandler.post { listener?.onModelTranscript(spoken) } }
            }
        }

        if (content.optBoolean("turnComplete")) {
            mainHandler.post { listener?.onTurnComplete() }
        }
    }

    // ---- microphone ----
    private fun startMicrophone() {
        if (!running) return
        val minBuffer = AudioRecord.getMinBufferSize(
            INPUT_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuffer <= 0) {
            mainHandler.post { listener?.onError("microphone is not available") }
            return
        }
        val record = runCatching {
            AudioRecord(
                MediaRecorder.AudioSource.MIC,
                INPUT_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuffer, CHUNK_BYTES * 4)
            )
        }.getOrNull()
        if (record == null || record.state != AudioRecord.STATE_INITIALIZED) {
            mainHandler.post { listener?.onError("microphone is not available") }
            return
        }
        recorder = record
        record.startRecording()

        micThread = thread(name = "madhuri-live-mic", isDaemon = true) {
            val buffer = ByteArray(CHUNK_BYTES)
            while (running && ready) {
                val read = record.read(buffer, 0, buffer.size)
                if (read > 0) {
                    val chunk = if (read == buffer.size) buffer else buffer.copyOf(read)
                    val encoded = Base64.encodeToString(chunk, Base64.NO_WRAP)
                    val message = JSONObject().apply {
                        put(
                            "realtimeInput",
                            JSONObject().apply {
                                put(
                                    "audio",
                                    JSONObject().apply {
                                        put("data", encoded)
                                        put("mimeType", "audio/pcm;rate=$INPUT_RATE")
                                    }
                                )
                            }
                        )
                    }
                    runCatching { socket?.send(message.toString()) }
                }
            }
            runCatching { record.stop() }
            runCatching { record.release() }
        }
    }

    // ---- playback ----
    private fun playPcm(pcm: ByteArray) {
        if (!running) return
        val track = player ?: createPlayer() ?: return
        runCatching { track.write(pcm, 0, pcm.size) }
    }

    private fun createPlayer(): AudioTrack? {
        val minBuffer = AudioTrack.getMinBufferSize(
            OUTPUT_RATE,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val track = runCatching {
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(OUTPUT_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minBuffer, OUTPUT_RATE / 2))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
        }.getOrNull()
        if (track == null) {
            mainHandler.post { listener?.onError("audio output is not available") }
            return null
        }
        track.play()
        player = track
        return track
    }

    private fun clearPlayback() {
        val track = player ?: return
        runCatching { track.pause() }
        runCatching { track.flush() }
        runCatching { track.play() }
    }

    private fun stopAudio() {
        running = false
        ready = false
        runCatching { recorder?.stop() }
        runCatching { recorder?.release() }
        recorder = null
        micThread = null
        runCatching { player?.pause() }
        runCatching { player?.flush() }
        runCatching { player?.release() }
        player = null
    }

    companion object {
        const val MODEL = "gemini-3.8-live"
        private const val ENDPOINT =
            "wss://generativelanguage.googleapis.com/ws/" +
                "google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"
        private const val INPUT_RATE = 16_000
        private const val OUTPUT_RATE = 24_000
        /** 100 ms of 16 kHz mono 16-bit audio. */
        private const val CHUNK_BYTES = INPUT_RATE / 10 * 2
    }
}
