# Madhuri AI — release shrinker rules.
# The app has no reflection-based model layer, so the defaults are enough.
# Keep the entry points that the platform instantiates by name.
-keep class com.codemaster.madhuri.MainActivity { *; }
-keep class com.codemaster.madhuri.MadhuriApp { *; }

# org.json is part of the platform, nothing to keep.
-dontwarn org.json.**
