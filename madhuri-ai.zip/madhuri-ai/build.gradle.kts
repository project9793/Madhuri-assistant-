// AGP 9 ships built-in Kotlin support, so the `org.jetbrains.kotlin.android`
// plugin is intentionally absent. AGP 9.3 depends on KGP 2.3.x by default;
// pinning KGP here raises the Kotlin compiler (and therefore the Compose
// compiler plugin below) to 2.4.21.
buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:2.4.21")
    }
}

plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.compose) apply false
}
